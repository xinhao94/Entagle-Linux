import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/*
 * Created on Nov 26, 2003
 */

/**
 * @author Jim Allers
 *
 */
public class GoogleChecker {

    public static void main(String[] args) {
        while(true){
            try{
                URL url = new URL("http://www.google.com/");
                InputStream inputStream = url.openStream();
                byte[] buf = new byte[1024*16];
                System.out.println("Started Reading");
                while(inputStream.read(buf) != -1){
                }
                //do nothing
                System.out.println("Done reading");
            }catch(IOException ioe){
                ioe.printStackTrace();
            }
            
            try{
                Thread.sleep(180000 + (long)Math.random()*120000);
            }catch(InterruptedException ie){
                ie.printStackTrace();
            }
            
        }
    }
}
