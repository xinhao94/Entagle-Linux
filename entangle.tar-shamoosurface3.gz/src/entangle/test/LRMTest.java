package entangle.test;


/**
 * @author Lowell Meyer
 *
 * Test class for new functionality
 */
public class LRMTest
{
	public static void main(String[] args){
		double x = Math.PI;
		double y = Math.PI;
		double z = x-y;
		
		System.out.println(x + " " + y + " " + z);
	}	
}
