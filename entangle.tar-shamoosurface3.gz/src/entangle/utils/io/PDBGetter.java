/*
 * PDBGetter.java
 *
 * Created on October 11, 2000, 1:15 AM
 */

package entangle.utils.io;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.MessageFormat;
import java.util.zip.GZIPInputStream;


/**
 * PDBGetter grabs a PDB from the PDB databank, www.rcsb.org/pdb/, given a pdb 
 * ID. This file could get deprecated because it assumes that the PDB 
 * will keep how to get PDB files constant.
 * @author  Jim Allers
 * @version 
 */
public class PDBGetter
{
	// available mirrors
	String[] mirrors = new String[]{"www.rcsb.org","rutgers.rcsb.org","nist.rcsb.org"};
	
    MessageFormat pdbURLFormat =
        new MessageFormat("http://{0}/pdb/cgi/export.cgi/{1}.pdb?format=PDB&pdbId={1}&compression=gz");
	URL pdbURL; 
	
	
	
    /** Creates new PDBGetter */
    public PDBGetter(String pdbID) 
    {
		pdbID = pdbID.toUpperCase();
		String url = pdbURLFormat.format(new Object[]{mirrors[0],pdbID});

		try
		{
			pdbURL = new URL(url);
		}
		catch(MalformedURLException e)
		{
			e.printStackTrace(System.out);
		}
    }


    public InputStream openPDBStream() throws IOException
    {	
    	InputStream compressedPDBStream = pdbURL.openStream();
		return new GZIPInputStream(compressedPDBStream);
    }
}