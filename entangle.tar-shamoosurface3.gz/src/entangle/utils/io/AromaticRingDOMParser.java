/*
 * AromaticRingDOMParser.java
 *
 * Created on October 14, 2000, 4:45 PM
 */

package entangle.utils.io;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


/**
 * AromaticRingDOMParser parses a document according to the 
 * dtd given for the aromatic ring xml file.
 * @author  Jim Allers
 * @version
 */
public class AromaticRingDOMParser
{
    // the atoms participating in the aromatic ring keyed
	// by the residue those atoms are part of
	Hashtable aromaticRings; 
	
	org.w3c.dom.Element rootAromaticRings;
	DocumentBuilder documentBuilder;
	
	
	
	/** Creates new AromaticRingDOMParser
	 * The parser does everything when it is constructed
	 */
	public AromaticRingDOMParser(File aromaticRingXMLFile) throws ParserConfigurationException, IOException, SAXException
	{
		documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document aromaticRingsDocument = documentBuilder.parse(aromaticRingXMLFile);
		aromaticRings = new Hashtable();
		rootAromaticRings = aromaticRingsDocument.getDocumentElement();
		createAromaticRings(rootAromaticRings);
	}
	
	
	
	
	
    /**
     * Gives the atoms that participate in the aromatic keyed
     * by the residues they are a part of.
     */
	public Hashtable getAromaticRings()
	{
		return aromaticRings;
	}


	/**
	* This method traverses the document
	*/
	private void createAromaticRings(Element root)
	{
		NodeList aromaticRingElementList = root.getElementsByTagName("aromaticRing");
		
		for(int i=0;i<aromaticRingElementList.getLength();i++)
		{
			Element aromaticRingElement = (Element)aromaticRingElementList.item(i);
			String residueName = ((Element)aromaticRingElement.getElementsByTagName("residue").item(0)).getFirstChild().getNodeValue(); 
			Vector ringMembers = getRingMembers(aromaticRingElement);
			aromaticRings.put(residueName,ringMembers);
		}
	}
	
    
    /**
     * Goes through the ring members that compose this document
     */ 
	private Vector getRingMembers(Element aromaticRingElement)
	{
		Vector ringMembers = new Vector();
		NodeList atomNameElementList = aromaticRingElement.getElementsByTagName("atomName");
		
		for(int i=0;i<atomNameElementList.getLength();i++)
		{
			Element atomNameElement = (Element)atomNameElementList.item(i);
			String atomName = atomNameElement.getFirstChild().getNodeValue();
			ringMembers.add(atomName);
		}
		
		return ringMembers;
	}
}