/*
 * DonorGroupGeometriesDOMParser.java
 *
 * Created on August 23, 2000, 9:40 PM
 */

package entangle.utils.io;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import entangle.datastructures.AtomLabel;
import entangle.datastructures.DonorGroupGeometry;
import entangle.datastructures.HydrogenInfo;


/**
 * DonorGroupGeometriesDOMParser parses an xml file that represents the donor
 * geometries possible inside a macromolecule given a PDB file.
 * the parser uses the java xml parser that creates a document that conforms 
 * the w3c
 * @author  Jim Allers
 * @version 
 */
public class DonorGroupGeometriesDOMParser
{
	Hashtable donorGroupGeometries;
	org.w3c.dom.Element rootDonorGroupGeometries;
	DocumentBuilder documentBuilder;
	
	
    /** Creates new DonorGroupGeometriesXMLParser 
	 *  The parser does everything when it is constructed
	 */
    public DonorGroupGeometriesDOMParser(File donorGroupGeometriesXMLFile) 
				throws ParserConfigurationException, IOException, SAXException
	{
		documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document donorGeometriesDocument = documentBuilder.parse(donorGroupGeometriesXMLFile);
		donorGroupGeometries = new Hashtable();
		rootDonorGroupGeometries = donorGeometriesDocument.getDocumentElement();
		createDonorGroupGeometries(rootDonorGroupGeometries);
    }
	
	
	
	public Hashtable getDonorGroupGeometries()
	{
		return donorGroupGeometries;
	}
	
	/**
	 * This is when it actually traverses the document and builds the donor 
	 * group geometries from the data file
	 */
	public void createDonorGroupGeometries(Element root)
	{
		NodeList donorGroupGeometryElementList = root.getElementsByTagName("donorGroupGeometry");
		
		for(int i=0;i<donorGroupGeometryElementList.getLength();i++)
		{
			Element donorGroupGeometryElement = (Element)donorGroupGeometryElementList.item(i);
			DonorGroupGeometry tempDonorGroupGeometry = createDonorGroupGeometry(donorGroupGeometryElement);
			donorGroupGeometries.put(tempDonorGroupGeometry.getResidueName() + 
							tempDonorGroupGeometry.getAtomName(), tempDonorGroupGeometry);
		}
	}
	
	
	public DonorGroupGeometry createDonorGroupGeometry(Element donorGroupGeometryElement)
	{
		// get the attributes from the donor
		Element donorElement = (Element)donorGroupGeometryElement.getElementsByTagName("donor").item(0);
		String areHydrogensFixedString = donorElement.getAttribute("areHydrogensFixedString");
		boolean areHydrogensFixed = Boolean.valueOf(areHydrogensFixedString).booleanValue();
		String numberOfBondedAtomsString = donorElement.getAttribute("numberOfBondedAtoms");
		int numberOfBondedAtoms = Integer.parseInt(numberOfBondedAtomsString);
		String numberOfHydrogensString = donorElement.getAttribute("numberOfHydrogens");
		int numberOfHydrogens = Integer.parseInt(numberOfHydrogensString);
		
		// donor label
		Element donorLabelElement = (Element)donorElement.getElementsByTagName("atomLabel").item(0);
		AtomLabel donorLabel = createAtomLabel(donorLabelElement);
		
		// hybridization
		Element hybridizationElement = (Element)donorElement.getElementsByTagName("hybridization").item(0);
		String hybridization = hybridizationElement.getFirstChild().getNodeValue();
		
		// antecedent
		Element antecedentElement = (Element)donorElement.getElementsByTagName("antecedent").item(0);
		AtomLabel antecedentLabel = createAtomLabel((Element)antecedentElement.getElementsByTagName("atomLabel").item(0));
		
		// antecedentAntecedent
		Element antecedentAntecedentElement = (Element)donorElement.getElementsByTagName("antecedentAntecedent").item(0);
		AtomLabel antecedentAntecedentLabel = createAtomLabel((Element)antecedentAntecedentElement.getElementsByTagName("atomLabel").item(0));
		
		// initialize donorGroupGeometry
		DonorGroupGeometry donorGroupGeometry = new DonorGroupGeometry(donorLabel.getResidueName(),donorLabel.getAtomName(),
						hybridization, numberOfHydrogens, numberOfBondedAtoms, areHydrogensFixed);
		donorGroupGeometry.setAntecedent(antecedentLabel.getResidueName(),antecedentLabel.getAtomName());
		donorGroupGeometry.setAntecedentAntecedent(antecedentAntecedentLabel.getResidueName(),
							   antecedentAntecedentLabel.getAtomName());
							   
		// bondedAtoms
		NodeList bondedAtomsList = donorElement.getElementsByTagName("bondedAtom");
		for(int j=0;j<bondedAtomsList.getLength();j++)
		{
			Element bondedAtomElement = (Element)bondedAtomsList.item(j);
			AtomLabel bondedAtomLabel = createAtomLabel((Element)bondedAtomElement.getElementsByTagName("atomLabel").item(0));
			donorGroupGeometry.addBondedAtom(bondedAtomLabel);
		}
		
		
		// hydrogenInfos
		NodeList hydrogenList = donorGroupGeometryElement.getElementsByTagName("hydrogen");
		for(int k=0;k<hydrogenList.getLength();k++)
		{
			Element hydrogenElement = (Element)hydrogenList.item(k);
			double angle = Double.parseDouble(hydrogenElement.getAttribute("angle"));
			double distance = Double.parseDouble(hydrogenElement.getAttribute("distance"));
			double torsionAngle = Double.parseDouble(hydrogenElement.getAttribute("torsionAngle"));
			String hydrogenName = hydrogenElement.getFirstChild().getNodeValue();
			HydrogenInfo hydrogenInfo = new HydrogenInfo(hydrogenName, torsionAngle, angle, distance);
			donorGroupGeometry.addHydrogenInfo(hydrogenInfo);
		}
		
		return donorGroupGeometry;
	}
	
	
	
	
	public AtomLabel createAtomLabel(Element atomLabelElement)
	{
		Element residueNameElement = (Element)atomLabelElement.getElementsByTagName("residueName").item(0);
		Element atomNameElement = (Element)atomLabelElement.getElementsByTagName("atomName").item(0);
		String residueName = residueNameElement.getFirstChild().getNodeValue();
		String atomName = atomNameElement.getFirstChild().getNodeValue();
		AtomLabel atomLabel = new AtomLabel(residueName,atomName);
		
		return atomLabel;
	}
}