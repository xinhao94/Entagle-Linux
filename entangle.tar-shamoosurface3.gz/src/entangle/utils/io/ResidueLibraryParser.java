/**
 * ResidueLibraryParser a residue library from the AMBER forcefield definitions
 *
 */
package entangle.utils.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import entangle.datastructures.Bond;
import entangle.datastructures.ResidueStructure;



public class ResidueLibraryParser
{
    File residueLibraryFile;
    File atomTypesFile;
    Hashtable atomTypes;
    Hashtable broaderVanderWaalsRadii; 	// keyed by their atom type 
				       					// from their amber forcefield 
				       					
    Hashtable VanderWaalsRadii; 		// keyed by their atom label
    String currentLine;
    
    
    
    
    
    public ResidueLibraryParser(File residueLibraryFile,File atomTypesFile)
    {
        this.residueLibraryFile = residueLibraryFile;
        this.atomTypesFile = atomTypesFile;
        atomTypes = new Hashtable();
		broaderVanderWaalsRadii = new Hashtable();
		VanderWaalsRadii = new Hashtable();
        getAtomTypes();
    }
    
    
    
 
    /**
     * This method goes through the atom types file and adds hybridizations to the 
     * the hashtable, these atom types follow the convention in the amber forcefied
     * parameter file
     */
    private void getAtomTypes()
    {
        try
        {
            LineNumberReader reader = new LineNumberReader(new FileReader(atomTypesFile));
            String currentLine = reader.readLine();
            
            while(currentLine!=null)
            {
                if(reader.getLineNumber()>2)
                {
                    StringTokenizer tokenizer = new StringTokenizer(currentLine);
                    atomTypes.put(tokenizer.nextToken(),tokenizer.nextToken());
                }
                
                currentLine = reader.readLine();
            }
        }
        catch(IOException e)
        {
        	System.err.println("Could not get the atom types");
        	e.printStackTrace();
        }
    }
    
    

    public Hashtable getVanderWaalsRadii()
    {
		return VanderWaalsRadii;
    }
    
    
    
    
    public Hashtable getResidueStructures()
    {
        Hashtable newResidueStructures = new Hashtable();
        
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(residueLibraryFile));
            currentLine = br.readLine();
            
            while(currentLine!=null)
            {
				if(currentLine.indexOf("ATOMTYPES")!=-1)
				{
					try
					{
						currentLine = br.readLine();
					}
					catch(IOException e)
					{
					}
					
					getVanderWaalsRadii(currentLine,br);
				}
				
                if(currentLine.indexOf("RESIDUE")!=-1)
                {
                    StringTokenizer st = new StringTokenizer(currentLine);
                    st.nextToken();
                    String residueName = st.nextToken();
                    currentLine = br.readLine();
                    ResidueStructure tempResidueStructure =
                    getResidueStructure(residueName,currentLine,br);
                    newResidueStructures.put(tempResidueStructure.getResName(), tempResidueStructure);
                }
                
                currentLine = br.readLine();
            }
            
            br.close();
        }
        catch(IOException e)
        {
            System.out.println("IO error when attempting to " + "parse the residue library file");
            System.out.println(e);
        }
        
        return newResidueStructures;
    }
    
    
    
    
    
    private void getVanderWaalsRadii(String beginningLine, BufferedReader br)
    {
		int numberOfTokens = 5;
		currentLine = beginningLine;
		
		while(numberOfTokens>4)
		{
			//System.out.println(currentLine);
			//System.out.println(numberOfTokens);
			numberOfTokens = 0;
			StringTokenizer stringTokenizer = new StringTokenizer(currentLine);
			String atomType = "";
			String radiusString = "";
			Double radius = null;
			
			while(stringTokenizer.hasMoreTokens())
			{
				String tempString = stringTokenizer.nextToken();
				
				if(numberOfTokens==1)
					atomType = tempString;
				
				if(numberOfTokens==2)
					radiusString = tempString;
				
				numberOfTokens++;
			}
			
			if(numberOfTokens>4)
			{
				try
				{
					radius = Double.valueOf(radiusString);
				}
				catch(NumberFormatException e)
				{
					System.out.println("Error when getting Van der " + "Waals radius value");
					System.out.println(e);
				}
				
				broaderVanderWaalsRadii.put(atomType,radius);
			}
			
			try
			{
				currentLine = br.readLine();
			}
			catch(IOException exc)
			{
				System.out.println(exc);
			}
		}
    }





    private ResidueStructure getResidueStructure(
        String name,
        String beginningLine,
        BufferedReader br) {
        ResidueStructure residueStructure = new ResidueStructure(name);
        currentLine = beginningLine;

        // parse through the atoms in the data library
        Vector atomNames = new Vector();
        Hashtable connections = new Hashtable();
        // the index of the atom is the key
        // the index of the connected atom is the value

        while (currentLine.trim().length() > 15) {
            StringTokenizer st2 = new StringTokenizer(currentLine);

            // atom number
            Integer atomNumber = new Integer(st2.nextToken());

            // atom name
            String atomName = st2.nextToken();
            atomNames.add(atomName);

            // atom type
            String atomType = st2.nextToken();

            if (atomTypes.contains(atomType)) {
                residueStructure.addAtomHybridization(
                    atomName,
                    (String) atomTypes.get(atomType));
            }

            // main chain, side chain, branch, something else
            st2.nextToken();

            // number of connected atom
            Integer connectedAtomNumber = new Integer(st2.nextToken());

            // next connected atoms
            st2.nextToken();
            st2.nextToken();

            // four floats 
            st2.nextToken();
            st2.nextToken();
            st2.nextToken();
            st2.nextToken();

            // check to see if atom is not just a pseudo atom
            // if it's not put it into the residue structure
            // also, place the proper VanderWaalsRadii in too
            if (!atomType.equals("DU")) {
                connections.put(atomNumber, connectedAtomNumber);

                if (!VanderWaalsRadii.containsKey(atomName)) {
                    VanderWaalsRadii.put(
                        atomName,
                        (Double) broaderVanderWaalsRadii.get(atomType));
                }
            }

            try {
                currentLine = br.readLine();
            } catch (IOException g) {
                g.printStackTrace();
            }

            if (currentLine == null)
                break;
        }

        // go through the connections and build bonds
        for (Enumeration e = connections.keys(); e.hasMoreElements();) {
            Integer firstAtomIntegerIndex = (Integer) e.nextElement();
            Integer secondAtomIntegerIndex =
                (Integer) connections.get(firstAtomIntegerIndex);
            
            String currentAtom =
                (String) atomNames.get(firstAtomIntegerIndex.intValue() - 1);

            String bondedAtom =
                (String) atomNames.get(secondAtomIntegerIndex.intValue() - 1);
            
            Bond bond = new Bond(currentAtom, bondedAtom);
            
            if (!residueStructure.containsBond(bond)) {
                residueStructure.addBond(bond);
            }
        }

        return residueStructure;
    }
}