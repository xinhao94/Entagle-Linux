package entangle.utils.io;

import java.io.File;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import entangle.classification.InteractingGroup;
import entangle.classification.NBInteractionContainer;
import entangle.classification.electrostatic.ElectrostaticInteraction;
import entangle.classification.hbonds.HydrogenBond;
import entangle.classification.hydrophobic.HydrophobicInteraction;
import entangle.classification.stacking.StackingInteraction;
import entangle.classification.vanderwaals.VanderWaalsInteraction;
import entangle.datastructures.Atom;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.PDBInformation;
import entangle.datastructures.Residue;


/**
 * This is a class that creates HTML documents that contain information about the 
 * protein-nucleic acid interactions.These documents can be saved, transported, 
 * and/or viewed by the JEditorPane inside of AnalyzerPanel. 
 * InteractionDocumentCreator sends the html through a PipedOutputStream
 */
public class InteractionDocumentCreator extends Thread
{
    NBInteractionContainer nbInteractionContainer;
    File htmlDocument;
    
	final String BLACK = "#000000";
    final String BLUE = "#00008B";
    final String RED = "#8B0000";
	final String WHITE = "#FFFFFF";
    final String DARKMAUVE = "#CCCCFF";
    final String LIGHTMAUVE = "#EEEEFF";
    final String DARKCELLCOLOR = "#999999";
    final String LIGHTCELLCOLOR = "#CCCCCC";
    final public static int HYDROGEN_BONDS = 77;
    final public static int ELECTROSTATIC_INTERACTIONS = 80;
    final public static int STACKING_INTERACTIONS = 82;
	final public static int HYDROPHOBIC_INTERACTIONS = 83;
	final public static int VANDERWAALS_INTERACTIONS = 84;
	final public static int ALL_INTERACTIONS = 85;
    final public static String HYDROGEN_BONDS_STRING = "Hydrogen Bonds";
    final public static String ELECTROSTATIC_INTERACTIONS_STRING = "Electrostatic Interactions";
    final public static String STACKING_INTERACTIONS_STRING = "Stacking Interactions";
	final public static String HYDROPHOBIC_INTERACTIONS_STRING = "Hydrophobic Interactions";
	final public static String VANDERWAALS_INTERACTIONS_STRING = "van der Waals Interactions";
        
    int documentType;
    Macromolecule protein;
    Macromolecule rna;
    PDBInformation pdbInformation;
    OutputStream out;
    boolean isFinished = false;
        
    
    
    public InteractionDocumentCreator()
    {
    }
        
        
        
        
    public InteractionDocumentCreator(NBInteractionContainer container,PDBInformation pdbInformation, OutputStream out)
    {
        nbInteractionContainer = container;
        this.protein = container.getMacromoleculeA();
        this.rna = container.getMacromoleculeB();
        this.pdbInformation = pdbInformation;
        this.out = out;
    }
        
        
    public File getHTMLFile()
    {
        return htmlDocument;
    }
        
        
    public void setPDBInformation(PDBInformation pdbInformation)
    {
        this.pdbInformation = pdbInformation;
    }
        
        
    public PDBInformation getPDBInformation()
    {
        return pdbInformation;
    }
        
        
    public void setProtein(Macromolecule macromolecule)
    {
        protein = macromolecule;
    }
        
        
    public void setRNA(Macromolecule macromolecule)
    {
        rna = macromolecule;
    }
        
        
    public void startSending(int documentType)
    {
        this.documentType = documentType;
        start();
    }
        
    
    public void run()
    {
		sendInteractionDocument(out,documentType);
		System.out.println("Done writing file");
        isFinished = true;
    }
        
    
    public boolean isFinished()
    {
        return isFinished;
    }
     
        
	private void sendInteractionDocument(OutputStream out,int documentType)
	{
		if(protein!=null && rna!= null && pdbInformation != null)
		{
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(out));
			startHTML(pdbInformation.getPDBName(),pw);
			
			switch(documentType)
			{
				case HYDROGEN_BONDS:
					writeHydrogenBonds(nbInteractionContainer.getHydrogenBonds(), pw);
					pw.println("<BR>Total number of hydrogen bonds " + Integer.toString(nbInteractionContainer.getHydrogenBonds().size()));
					pw.flush();
					break;
				case ELECTROSTATIC_INTERACTIONS:
					writeElectrostaticInteractions(nbInteractionContainer.getElectrostaticInteractions(),pw);
					break;
				case STACKING_INTERACTIONS:
					writeStackingInteractions(nbInteractionContainer.getStackingInteractions(), pw);
					break;
				case HYDROPHOBIC_INTERACTIONS:
					writeHydrophobicInteractions(nbInteractionContainer.getHydrophobicInteractions(), pw);
					break;
				case VANDERWAALS_INTERACTIONS:
					writeVanderWaalsInteractions(nbInteractionContainer.getVanderWaalsInteractions(), pw);
					break;
				case ALL_INTERACTIONS:
					/*writeAllInteractions(nbInteractionContainer.getInteractingGroups(),pw); */
					writeHydrogenBonds				(nbInteractionContainer.getHydrogenBonds(), 			pw);
					writeElectrostaticInteractions	(nbInteractionContainer.getElectrostaticInteractions(), pw);
					writeStackingInteractions		(nbInteractionContainer.getStackingInteractions(), 		pw);
					writeHydrophobicInteractions	(nbInteractionContainer.getHydrophobicInteractions(), 	pw);
					writeVanderWaalsInteractions	(nbInteractionContainer.getVanderWaalsInteractions(), 	pw);
					break;
				default:
					break;
			}
			
			endHTML(pw);
			pw.close();
		}
		else
		{
			if(protein==null) 
				System.out.println("Protein isn't set");
			if(rna==null) 
				System.out.println("RNA isn't set");
			if(pdbInformation==null) 
				System.out.println("PDB information isn't set");
			System.out.println("You haven't set the protein or rna or pdbInformation yet");
        }
	}
        
        
        
	private void writeAllInteractions(Hashtable interactingGroups, PrintWriter pw)
	{
		for(Enumeration e = interactingGroups.elements(); e.hasMoreElements();)
		{
			InteractingGroup interactingGroup = (InteractingGroup)e.nextElement();
			Vector hydrogenBonds = interactingGroup.getHydrogenBonds();
			Vector electrostaticInteractions = interactingGroup.getElectrostaticInteractions();
			Vector vanderWaalsInteractions = interactingGroup.getVanderWaalsInteractions();
			Vector hydrophobicInteractions = interactingGroup.getHydrophobicInteractions();
			Vector stackingInteractions = interactingGroup.getStackingInteractions();
			boolean hasHydrogenBonds = hydrogenBonds.size()!=0;
			boolean hasElectrostaticInteractions = electrostaticInteractions.size()!=0;
			boolean hasVanderWaalsInteractions = vanderWaalsInteractions.size()!=0;
			boolean hasHydrophobicInteractions = hydrophobicInteractions.size()!=0;
			boolean hasStackingInteractions = stackingInteractions.size()!=0;
			boolean hasSomeInteractions = false;
			
			if(hasHydrogenBonds || hasElectrostaticInteractions || hasVanderWaalsInteractions || hasHydrophobicInteractions)
			{
				hasSomeInteractions = true;
				pw.println("<TABLE BORDER=\"1\"><TR>" + "<TD><H1>" + interactingGroup.getNucleicAcidResidue() + "</H1></TD></TR>");
				pw.flush();
			}
			
			if(hasHydrogenBonds)
			{
				pw.println("<TR><TD>");
				pw.flush();
				writeHydrogenBonds(hydrogenBonds,pw);
				pw.println("</TD></TR>");
				pw.flush();
			}
			
			if(hasElectrostaticInteractions)
			{
				pw.println("<TR><TD>");
				pw.flush();
				writeElectrostaticInteractions(electrostaticInteractions, pw);
				pw.println("</TD></TR>");
				pw.flush();
			}
			
			if(hasVanderWaalsInteractions)
			{
				pw.println("<TR><TD>");
				pw.flush();
				writeVanderWaalsInteractions(vanderWaalsInteractions, pw);
				pw.println("</TD></TR>");
				pw.flush();
			}
			
			if(hasHydrophobicInteractions)
			{
				pw.println("<TR><TD>");
				pw.flush();
				writeHydrophobicInteractions(hydrophobicInteractions,pw);
				pw.println("</TD></TR>");
				pw.flush();
			}
			
			if(hasStackingInteractions)
			{
				pw.println("<TR><TD>");
				pw.flush();
				writeStackingInteractions(
					stackingInteractions,pw);
				pw.println("</TD></TR>");
				pw.flush();
			}
			
			if(hasSomeInteractions)
			{
				pw.println("</TABLE>");
				pw.flush();
			}
		}
	}
			
        
        
    /**
     * writeInteractions writes an html table that outputs the specified interaction
     */
    private void writeInteractions(Vector interactions, String interactionTypeString, String[] parameters,PrintWriter pw)
    {
        pw.println("<font size=\"5\">" + interactionTypeString + "</font><br>");
        pw.flush();
		
		if(interactionTypeString.equals(STACKING_INTERACTIONS_STRING))
		{
            pw.println("<TABLE CELLSPACING=\"0\" BORDER=\"1\"><TR BGCOLOR=" + WHITE + "><TD WIDTH=\"150\">Protein Residue</TD>" +
				"<TD WIDTH=\"150\">Protein ResSeq</TD>" + "<TD WIDTH = \"150\">Nucleic Acid Residue</TD>" + 
				"<TD WIDTH = \"150\">Nucleic Acid ResSeq</TD>");
		}
		else
		{
			pw.println("<TABLE CELLSPACING=\"0\" BORDER=\"1\"><TR BGCOLOR=" + WHITE + "><TD WIDTH=\"150\">Protein Residue</TD>" +
				"<TD WIDTH=\"150\">Protein ResSeq</TD>" + "<TD WIDTH=\"150\">Protein Atom</TD>" + 
				"<TD WIDTH = \"150\">Nucleic Acid Residue</TD>" + "<TD WIDTH = \"150\">Nucleic Acid ResSeq</TD>" + 
				"<TD WIDTH = \"150\">Nucleic Acid Atom</TD>");
		}
        
        
        pw.flush();
        
        for(int i=0;i<parameters.length;i++)
        {
            pw.println("<TD WIDTH = \"150\">" + parameters[i] + "</TD>");
            pw.flush();
        }
        
		pw.println("</TR>");
		pw.flush();
        
        // write the interactions to the current output stream
        for(int i = 0;i<interactions.size();i++)
        {
			writeInteraction(interactions.get(i),pw);
        }
        
        pw.println("</TABLE>");
        pw.flush();
    }//ends writeInteractions
        
        
        
	/*
	 * Writes an HTML table for displaying the vector of stacking interactions
	 */
    private void writeStackingInteractions(Vector stackingInteractions,PrintWriter pw)
    {
        String[] parameters = {"Dihedral Angle (degrees)","Center-to-Center Distance"};
        writeInteractions(stackingInteractions,STACKING_INTERACTIONS_STRING,parameters,pw);
    }
      
      
      
        
	/*
	 * Writes an HTML table for displaying the electrostatic interactions
	 */
    private void writeElectrostaticInteractions(Vector electrostaticInteractions,PrintWriter pw)
    {
        String[] parameters = {"Distance"};
        writeInteractions(electrostaticInteractions,ELECTROSTATIC_INTERACTIONS_STRING,parameters,pw);
    }
    
    
    
	/*
	 * Writes an HTML table for displaying the vector of hydrogen bonds
	 */
    private void writeHydrogenBonds(Vector hydrogenBonds,PrintWriter pw)
    {
        String[] parameters = {"Distance","H-A Distance"};
        writeInteractions(hydrogenBonds,HYDROGEN_BONDS_STRING,parameters,pw);
    }   
        
        
        
	/*
	 * Writes an HTML table for displaying the vector of hydrophobic interactions
	 */
	private void writeHydrophobicInteractions(Vector hydrophobicInteractions, PrintWriter pw)
	{
	 	String[] parameters = {"Distance"};
		writeInteractions(hydrophobicInteractions, HYDROPHOBIC_INTERACTIONS_STRING,parameters,pw);
	}
	
	
	
	/*
	 * Writes an HTML table for displaying the vector of Van der Waals interactions
	 */
	private void writeVanderWaalsInteractions(Vector vanderWaalsInteractions, PrintWriter pw)
	{
		String[] parameters = {"Distance","Effective Distance"};
		writeInteractions(vanderWaalsInteractions, VANDERWAALS_INTERACTIONS_STRING,parameters,pw);
	}
	
	
	
	/*
	 * writes an interaction as a HTML row with each element in the row
	 * being a string
	 * to recognize another interaction this method needs to be changed along 
	 * with the writeInteractions method
	 * For interactions involving two residues
	 *  	protein residue name, protein residue number, 
	 *	nucleic acid residue name, nucleic acid residue number
	 * For interactions involving two atoms
	 * 	protein residue name, protein residue number, protein atom name
	 *       nucleic acid residue name, nucleic acid residue number, 
	 *       nucleic acid atom name
	 */
	private void writeInteraction(Object interaction,PrintWriter pw)
	{
		Vector parameterStrings = new Vector();
		
		// protein atom
		if(interaction instanceof HydrogenBond)
		{
			HydrogenBond hydrogenBond = (HydrogenBond)interaction;
			Atom donor = hydrogenBond.getDonor();
			Atom acceptor = hydrogenBond.getAcceptor();
			
			if(protein.containsResidue(donor.getParentResidue()))
			{
				parameterStrings.add(BLACK);
				parameterStrings.add(donor.getResName());
				parameterStrings.add(BLACK);
				parameterStrings.add(Integer.toString(donor.getResSeq()));
				parameterStrings.add(BLUE);
				parameterStrings.add(donor.getName());
				parameterStrings.add(BLACK);
				parameterStrings.add(acceptor.getResName());
				parameterStrings.add(BLACK);
				parameterStrings.add(Integer.toString(acceptor.getResSeq()));
				parameterStrings.add(RED);
				parameterStrings.add(acceptor.getName());
			}
			else
			{
				parameterStrings.add(BLACK);
				parameterStrings.add(acceptor.getResName());
				parameterStrings.add(BLACK);
				parameterStrings.add(Integer.toString(acceptor.getResSeq()));
				parameterStrings.add(RED);
				parameterStrings.add(acceptor.getName());
				parameterStrings.add(BLACK);
				parameterStrings.add(donor.getResName());
				parameterStrings.add(BLACK);
				parameterStrings.add(Integer.toString(donor.getResSeq()));
				parameterStrings.add(BLUE);
				parameterStrings.add(donor.getName());
			}
			
			parameterStrings.add(BLACK);
			parameterStrings.add(Double.toString(hydrogenBond.getDonorToAcceptorDistance()).substring(0,3));
			parameterStrings.add(BLACK);
			parameterStrings.add(Double.toString(hydrogenBond.getHydrogenToAcceptorDistance()).substring(0,3));
		}
		
		
		if(interaction instanceof HydrophobicInteraction)
		{
			HydrophobicInteraction hydrophobicInteraction = (HydrophobicInteraction)interaction;
			Atom atomA = hydrophobicInteraction.getNonPolarAtomA();
			Atom atomB = hydrophobicInteraction.getNonPolarAtomB();
			Atom proteinAtom = null;
			Atom nucleicAcidAtom = null;
			
			if(protein.containsResidue(atomA.getParentResidue()))
			{
				proteinAtom = atomA;
				nucleicAcidAtom = atomB;
			}
			else
			{
				proteinAtom = atomB;
				nucleicAcidAtom = atomA;
			}
			
			parameterStrings.add(BLACK);
			parameterStrings.add(proteinAtom.getResName());
			parameterStrings.add(BLACK);
			parameterStrings.add(Integer.toString(proteinAtom.getResSeq()));
			parameterStrings.add(BLACK);
			parameterStrings.add(proteinAtom.getName());
			parameterStrings.add(BLACK);
			parameterStrings.add(nucleicAcidAtom.getResName());
			parameterStrings.add(BLACK);
			parameterStrings.add(Integer.toString(nucleicAcidAtom.getResSeq()));
			parameterStrings.add(BLACK);
			parameterStrings.add(nucleicAcidAtom.getName());
			parameterStrings.add(BLACK);
			parameterStrings.add(Double.toString(hydrophobicInteraction.distance).substring(0,4));
		}
		
		if(interaction instanceof StackingInteraction)
		{
			StackingInteraction stackingInteraction = (StackingInteraction)interaction;
			Residue rA = stackingInteraction.getResidueA();
            Residue rB = stackingInteraction.getResidueB();
			Residue proteinResidue = null;
			Residue nucleicAcidResidue = null;
			
			if(protein.containsResidue(rA))
			{
				proteinResidue = rA;
				nucleicAcidResidue = rB;
			}
			else
			{
				proteinResidue = rB;
				nucleicAcidResidue = rA;
			}
			
			parameterStrings.add(BLACK);
			parameterStrings.add(proteinResidue.getResName());
			parameterStrings.add(BLACK);
			parameterStrings.add(Integer.toString(proteinResidue.getResidueSequenceNumber()));
			parameterStrings.add(BLACK);
			parameterStrings.add(nucleicAcidResidue.getResName());
			parameterStrings.add(BLACK);
			parameterStrings.add(Integer.toString(proteinResidue.getResidueSequenceNumber()));
			parameterStrings.add(BLACK);
			parameterStrings.add(Double.toString(stackingInteraction.getDihedralAngle()).substring(0,4));
			parameterStrings.add(BLACK);
			parameterStrings.add(Double.toString(stackingInteraction.getCenterToCenterDistance()).substring(0,4));
		}
		
		if(interaction instanceof VanderWaalsInteraction)
		{
			VanderWaalsInteraction vanderWaalsInteraction = (VanderWaalsInteraction)interaction;
			Atom atomA = vanderWaalsInteraction.getAtomA();
			Atom atomB = vanderWaalsInteraction.getAtomB();
			Atom proteinAtom = null;
			Atom nucleicAcidAtom = null;
			
			if(protein.containsResidue(atomA.getParentResidue()))
			{
				proteinAtom = atomA;
				nucleicAcidAtom = atomB;
			}
			else
			{
				proteinAtom = atomB;
				nucleicAcidAtom = atomA;
			}
			
			parameterStrings.add(BLACK);
			parameterStrings.add(proteinAtom.getResName());
			parameterStrings.add(BLACK);
			parameterStrings.add(Integer.toString(proteinAtom.getResSeq()));
			parameterStrings.add(BLACK);
			parameterStrings.add(proteinAtom.getName());
			parameterStrings.add(BLACK);
			parameterStrings.add(nucleicAcidAtom.getResName());
			parameterStrings.add(BLACK);
			parameterStrings.add(Integer.toString(nucleicAcidAtom.getResSeq()));
			parameterStrings.add(BLACK);
			parameterStrings.add(nucleicAcidAtom.getName());
			parameterStrings.add(BLACK);
			parameterStrings.add(Double.toString(vanderWaalsInteraction.distanceBetweenAtoms).substring(0,4));
			parameterStrings.add(BLACK);
			parameterStrings.add(Double.toString(vanderWaalsInteraction.effectiveDistance).substring(0,4));
		}
		
		if(interaction instanceof ElectrostaticInteraction)
		{
			ElectrostaticInteraction ei = (ElectrostaticInteraction)interaction;
			Atom positive = ei.getPositiveAtom();
			Atom negative= ei.getNegativeAtom();
			
			if(protein.containsResidue(positive.getParentResidue()))
			{
				parameterStrings.add(BLACK);
				parameterStrings.add(positive.getResName());
				parameterStrings.add(BLACK);
				parameterStrings.add(Integer.toString(positive.getResSeq()));
				parameterStrings.add(BLUE);
				parameterStrings.add(positive.getName());
				parameterStrings.add(BLACK);
				parameterStrings.add(negative.getResName());
				parameterStrings.add(BLACK);
				parameterStrings.add(Integer.toString(negative.getResSeq()));
				parameterStrings.add(RED);
				parameterStrings.add(negative.getName());
			}
			else
			{
				parameterStrings.add(BLACK);
				parameterStrings.add(negative.getResName());
				parameterStrings.add(BLACK);
				parameterStrings.add(Integer.toString(negative.getResSeq()));
				parameterStrings.add(BLUE);
				parameterStrings.add(negative.getName());
				parameterStrings.add(BLACK);
				parameterStrings.add(positive.getResName());
				parameterStrings.add(BLACK);
				parameterStrings.add(Integer.toString(positive.getResSeq()));
				parameterStrings.add(RED);
				parameterStrings.add(positive.getName());
			}
			
			parameterStrings.add(BLACK);
			parameterStrings.add(Double.toString(ei.getDistance()).substring(0,4));
		}
		
		writeInteraction(parameterStrings,pw);
    }
    
    
	
	private void writeInteraction(Vector parameterAndColorStrings,PrintWriter pw)
	{
		pw.println("<TR>");
		pw.flush();
		
		for(Iterator iterator = parameterAndColorStrings.iterator(); iterator.hasNext();)
		{
			pw.print("<TD><FONT COLOR=\"" + (String)iterator.next() + "\">" + (String)iterator.next()+ "</FONT></TD>");
			pw.flush();
		}
		
		pw.println("</TR>");
		pw.flush();
	}
        
        
        
    private void startHTML(String title,PrintWriter pw)
    {
        pw.println("<HTML>");
        pw.flush();
        pw.println("<HEAD><TITLE>" + title + "</TITLE>");
        pw.flush();
        
        //pw.println("<BASE HREF=\"\"></BASE>");
        //pw.flush();
        //pw.println("<LINK REL =\"stylesheet\" TYPE=\"text/css\" HREF=\"stylesheet.css\" TITLE=\"Style\">");
        //pw.flush();
        pw.println("</HEAD>");
        pw.flush();
        pw.println("<BODY BGCOLOR=#FFFFFF>");
        pw.flush();
    }
        
        
    private void endHTML(PrintWriter pw)
    {
        pw.println("</BODY></HTML>");
        pw.flush();
    }
}