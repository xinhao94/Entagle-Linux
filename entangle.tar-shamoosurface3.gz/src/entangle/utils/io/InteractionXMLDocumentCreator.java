/*
 * ClassName.java
 *
 * Created on November 12, 2000, 4:45 PM
 */

package entangle.utils.io;
import java.util.Iterator;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.crimson.tree.XmlDocument;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import entangle.classification.NBInteractionContainer;
import entangle.classification.electrostatic.ElectrostaticInteraction;
import entangle.classification.hbonds.HydrogenBond;
import entangle.classification.hydrophobic.HydrophobicInteraction;
import entangle.classification.stacking.StackingInteraction;
import entangle.classification.vanderwaals.VanderWaalsInteraction;
import entangle.datastructures.Atom;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.Residue;



/**
 *
 * @author  Jim Allers
 * @version 
 */
public class InteractionXMLDocumentCreator extends Object
{
	NBInteractionContainer container;
    
    
    
    /** Creates new InteractionXMLDocumentCreator */
    public InteractionXMLDocumentCreator(NBInteractionContainer container)
    {
		this.container = container;
   	}
	
	
	
	
	
	public XmlDocument createXMLDocument() throws ParserConfigurationException, DOMException
	{
		Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		Element root = document.createElement("interactionsDocument");
		document.appendChild(root);
		Element pdbIDElement = document.createElement("pdbID");
		root.appendChild(pdbIDElement);
		Node pdbIDText = document.createTextNode(container.getPDBInformation().getPDBName());
		pdbIDElement.appendChild(pdbIDText);
		
		Macromolecule macromoleculeA = container.getMacromoleculeA();
		Macromolecule macromoleculeB = container.getMacromoleculeB();
		
		Element macromoleculeAElement = document.createElement("macromoleculeA");
		Element macromoleculeBElement = document.createElement("macromoleculeB");
		
		macromoleculeAElement.setAttribute("chainID", macromoleculeA.getChainIdentifier());
		macromoleculeAElement.setAttribute("macromoleculeType", macromoleculeA.getType());
		macromoleculeBElement.setAttribute("chainID", macromoleculeB.getChainIdentifier());
		macromoleculeBElement.setAttribute("macromoleculeType", macromoleculeB.getType());
		
		Node macromoleculeAName = document.createTextNode(macromoleculeA.getName());
		Node macromoleculeBName = document.createTextNode(macromoleculeB.getName());
		macromoleculeAElement.appendChild(macromoleculeAName);
		macromoleculeBElement.appendChild(macromoleculeBName);
		
		root.appendChild(macromoleculeAElement);
		root.appendChild(macromoleculeBElement);
		root.appendChild(createClassificationParametersElement(document));
		root.appendChild(createHydrophobicInteractionsElement(document));
		root.appendChild(createStackingInteractionsElement(document));
		root.appendChild(createElectrostaticInteractionsElement(document));
		root.appendChild(createHydrogenBondsElement(document));
		root.appendChild(createVanderWaalsInteractionsElement(document));
		
		return (XmlDocument)document;
	}
	
	
	
	public Element createHydrophobicInteractionsElement(Document document) throws DOMException
	{
		Element hydrophobicInteractionsElement = document.createElement("hydrophobicInteractions");
		Vector hydrophobicInteractions = container.getHydrophobicInteractions();
		
		for(Iterator hydrophobicInteractionsIterator = hydrophobicInteractions.iterator(); hydrophobicInteractionsIterator.hasNext();)
		{
			HydrophobicInteraction hydrophobicInteraction = (HydrophobicInteraction) hydrophobicInteractionsIterator.next();
			Element hydrophobicInteractionElement = document.createElement("hydrophobicInteraction");
			hydrophobicInteractionElement.setAttribute("distance", Double.toString(hydrophobicInteraction.distance));
			hydrophobicInteractionElement.appendChild(createAtomElement(hydrophobicInteraction.getNonPolarAtomA(), document));
			hydrophobicInteractionElement.appendChild(createAtomElement(hydrophobicInteraction.getNonPolarAtomB(), document));
			hydrophobicInteractionsElement.appendChild(hydrophobicInteractionElement);
		}
		
		return hydrophobicInteractionsElement;
	}
	
	
	
	public Element createElectrostaticInteractionsElement(Document document) throws DOMException
	{
		Element electrostaticInteractionsElement = document.createElement("electrostaticInteractions");
		Vector electrostaticInteractions = container.getElectrostaticInteractions();
		
		for(Iterator electrostaticInteractionsIterator = electrostaticInteractions.iterator(); electrostaticInteractionsIterator.hasNext();)
		{
			ElectrostaticInteraction electrostaticInteraction = (ElectrostaticInteraction)electrostaticInteractionsIterator.next();
			Element electrostaticInteractionElement = document.createElement("electrostaticInteraction");
			electrostaticInteractionElement.setAttribute("distance", Double.toString(electrostaticInteraction.getDistance()));
			Element positiveElement = document.createElement("positive");
			Element negativeElement = document.createElement("negative");
			positiveElement.appendChild(createAtomElement(electrostaticInteraction.getPositiveAtom(), document));
			negativeElement.appendChild(createAtomElement(electrostaticInteraction.getNegativeAtom(), document));
			electrostaticInteractionElement.appendChild(positiveElement);
			electrostaticInteractionElement.appendChild(negativeElement);
			electrostaticInteractionsElement.appendChild(electrostaticInteractionElement);
		}
		
		return electrostaticInteractionsElement;
	}
	
	
	
	public Element createVanderWaalsInteractionsElement(Document document) throws DOMException
	{
		Element vanderWaalsInteractionsElement = document.createElement("vanderWaalsInteractions");
		Vector vanderWaalsInteractions = container.getVanderWaalsInteractions();
		
		for(Iterator vanderWaalsInteractionIterator = vanderWaalsInteractions.iterator(); vanderWaalsInteractionIterator.hasNext();)
		{
			VanderWaalsInteraction vanderWaalsInteraction = (VanderWaalsInteraction) vanderWaalsInteractionIterator.next();
			Element vanderWaalsInteractionElement = document.createElement("vanderWaalsInteraction");
			vanderWaalsInteractionElement.setAttribute("distance", Double.toString(vanderWaalsInteraction.distanceBetweenAtoms));
			vanderWaalsInteractionElement.setAttribute("effectiveDistance", Double.toString(vanderWaalsInteraction.effectiveDistance));
			vanderWaalsInteractionElement.appendChild(createAtomElement(vanderWaalsInteraction.getAtomA(), document));
			vanderWaalsInteractionElement.appendChild(createAtomElement(vanderWaalsInteraction.getAtomB(), document));
			vanderWaalsInteractionsElement.appendChild(vanderWaalsInteractionElement);
		}
		
		return vanderWaalsInteractionsElement;
	}
	
	
	
	public Element createHydrogenBondsElement(Document document) throws DOMException
	{
		Element hydrogenBondsElement = document.createElement("hydrogenBonds");
		Vector hydrogenBonds = container.getHydrogenBonds();
		
		for(Iterator hydrogenBondsIterator = hydrogenBonds.iterator(); hydrogenBondsIterator.hasNext();)
		{
			HydrogenBond hydrogenBond = (HydrogenBond)hydrogenBondsIterator.next();
			Element hydrogenBondElement = document.createElement("hydrogenBond");
			hydrogenBondElement.setAttribute("donorToAcceptorDistance", Double.toString(hydrogenBond.getDonorToAcceptorDistance()));
			hydrogenBondElement.setAttribute("D_H_A_Angle", Double.toString(hydrogenBond.getD_H_A_Angle()));
			hydrogenBondElement.setAttribute("hydrogenToAcceptorDistance", Double.toString(hydrogenBond.getHydrogenToAcceptorDistance()));
			hydrogenBondElement.setAttribute("H_A_AA_Angle", Double.toString(hydrogenBond.getH_A_AA_Angle()));
			Element donorElement = document.createElement("donor");
			Element acceptorElement = document.createElement("acceptor");
			Element hydrogenElement = document.createElement("hydrogen");
			donorElement.appendChild(createAtomElement(hydrogenBond.getDonor(),document));
			acceptorElement.appendChild(createAtomElement(hydrogenBond.getAcceptor(),document));
			hydrogenElement.appendChild(createAtomElement(hydrogenBond.getHydrogen(),document));
			hydrogenBondElement.appendChild(donorElement);
			hydrogenBondElement.appendChild(acceptorElement);
			hydrogenBondElement.appendChild(hydrogenElement);
			hydrogenBondsElement.appendChild(hydrogenBondElement);
		}
		
		return hydrogenBondsElement;
	}
	
	
	
	public Element createStackingInteractionsElement(Document document) throws DOMException
	{
		Element stackingInteractionsElement = document.createElement("stackingInteractions");
		Vector stackingInteractions = container.getStackingInteractions();
		
		for(Iterator stackingInteractionsIterator = stackingInteractions.iterator(); stackingInteractionsIterator.hasNext();)
		{
			StackingInteraction stackingInteraction = (StackingInteraction)stackingInteractionsIterator.next();
			Element stackingInteractionElement = document.createElement("stackingInteraction");
			stackingInteractionElement.setAttribute("centerToCenterDistance", Double.toString(stackingInteraction.getCenterToCenterDistance()));
			stackingInteractionElement.setAttribute("degreeOfStaggeredness", Double.toString(stackingInteraction.getDegreeOfStaggeredness()));
			stackingInteractionElement.setAttribute("dihedralAngle", Double.toString(stackingInteraction.getDihedralAngle()));
			stackingInteractionElement.appendChild(createResidueElement(stackingInteraction.getResidueA(), document));
			stackingInteractionElement.appendChild(createResidueElement(stackingInteraction.getResidueB(), document));
			stackingInteractionsElement.appendChild(stackingInteractionElement);
		}
		
		return stackingInteractionsElement;
	}
	
	
	
	public Element createAtomElement(Atom atom,Document document) throws DOMException
	{
		Element atomElement = document.createElement("atom");
		atomElement.setAttribute("chainID",atom.getChainID());
		atomElement.setAttribute("resName",atom.getResName());
		atomElement.setAttribute("resSeq", Integer.toString(atom.getResSeq()));
		atomElement.setAttribute("serial", Integer.toString(atom.getSerial()));
		atomElement.setAttribute("x", Double.toString(atom.getX()));
		atomElement.setAttribute("y", Double.toString(atom.getY()));
		atomElement.setAttribute("z", Double.toString(atom.getZ()));
		Node atomTextNode = document.createTextNode(atom.getName());
		atomElement.appendChild(atomTextNode);
		
		return atomElement;
	}
	
	
	
	public Element createResidueElement(Residue residue,Document document) throws DOMException
	{
		Element residueElement = document.createElement("residue");
		residueElement.setAttribute("chainID",residue.getChainID());
		residueElement.setAttribute("resSeq", Integer.toString(residue.getResidueSequenceNumber()));
		Node residueTextNode = document.createTextNode(residue.getResName());
		residueElement.appendChild(residueTextNode);
		
		return residueElement;
	}
	
	
	
	public Element createClassificationParametersElement(Document document) throws DOMException
	{
		Element classificationParameters = document.createElement("classificationParameters");
		
		// maximumDistanceForHydrogenBond
		Element maximumDistanceForHydrogenBondElement = document.createElement("maximumDistanceForHydrogenBond");
		Node maximumDistanceForHydrogenBond = document.createTextNode(Double.toString(container.maximumDistanceForHydrogenBond));
		maximumDistanceForHydrogenBondElement.appendChild(maximumDistanceForHydrogenBond);
		classificationParameters.appendChild(maximumDistanceForHydrogenBondElement);
		
		// maximumAcceptorToHydrogenDistance
		Element maximumAcceptorToHydrogenElement = document.createElement("maximumAcceptorToHydrogen");
		Node maximumAcceptorToHydrogen = document.createTextNode(Double.toString(container.maximumAcceptorToHydrogenDistance));
		maximumAcceptorToHydrogenElement.appendChild(maximumAcceptorToHydrogen);
		classificationParameters.appendChild(maximumAcceptorToHydrogenElement);
		
		// maximumDistanceForElectrostaticInteraction
		Element maximumDistanceForElectrostaticInteractionElement = document.createElement("maximumDistanceForElectrostaticInteraction");
		Node maximumDistanceForElectrostaticInteraction = document.createTextNode(Double.toString(container.maximumDistanceForElectrostaticInteraction));
		maximumDistanceForElectrostaticInteractionElement.appendChild(maximumDistanceForElectrostaticInteraction);
		classificationParameters.appendChild(maximumDistanceForElectrostaticInteractionElement);
		
		// maximumDistanceForHydrophobicInteraction
		Element maximumDistanceForHydrophobicInteractionElement = document.createElement("maximumDistanceForHydrophobicInteraction");
		Node maximumDistanceForHydrophobicInteraction = document.createTextNode(Double.toString(container.maximumDistanceForHydrophobicInteraction));
		maximumDistanceForHydrophobicInteractionElement.appendChild(maximumDistanceForHydrophobicInteraction);
		classificationParameters.appendChild(maximumDistanceForHydrophobicInteractionElement);
		
		// minimumD_H_A_Angle
		Element minimumD_H_A_AngleElement = document.createElement("minimumD_H_A_Angle");
		Node minimumD_H_A_Angle = document.createTextNode(Double.toString(container.minimumD_H_A_Angle));
		minimumD_H_A_AngleElement.appendChild(minimumD_H_A_Angle);
		classificationParameters.appendChild(minimumD_H_A_AngleElement);
		
		// minimumH_A_AA_Angle
		Element minimumH_A_AA_AngleElement = document.createElement("minimumH_A_AA_Angle");
		Node minimumH_A_AA_Angle = document.createTextNode(Double.toString(container.minimumH_A_AA_Angle));
		minimumH_A_AA_AngleElement.appendChild(minimumH_A_AA_Angle);
		classificationParameters.appendChild(minimumH_A_AA_AngleElement);
		
		// maximumInteractionDistance
		Element maximumInteractionDistanceElement = document.createElement("maximumInteractionDistance");
		Node maximumInteractionDistance = document.createTextNode(Double.toString(container.maximumInteractionDistance));
		maximumInteractionDistanceElement.appendChild(maximumInteractionDistance);
		classificationParameters.appendChild(maximumInteractionDistanceElement);
		
		// maximumStackingDistance
		Element maximumStackingDistanceElement = document.createElement("maximumStackingDistance");
		Node maximumStackingDistance = document.createTextNode(Double.toString(container.maximumStackingDistance));
		maximumStackingDistanceElement.appendChild(maximumStackingDistance);
		classificationParameters.appendChild(maximumDistanceForHydrogenBondElement);
		
		// maximumStackingAngle
		Element maximumStackingAngleElement = document.createElement("maximumStackingAngle");
		Node maximumStackingAngle = document.createTextNode(Double.toString(container.maximumStackingAngle));
		maximumStackingAngleElement.appendChild(maximumStackingAngle);
		classificationParameters.appendChild(maximumStackingAngleElement);
		
		// maximumVanderWaalsDistance
		Element maximumVanderWaalsDistanceElement = document.createElement("maximumVanderWaalsDistance");
		Node maximumVanderWaalsDistance = document.createTextNode(Double.toString(container.maximumVanderWaalsDistance));
		maximumVanderWaalsDistanceElement.appendChild(maximumVanderWaalsDistance);
		classificationParameters.appendChild(maximumVanderWaalsDistanceElement);
		
		return classificationParameters;
	}
}