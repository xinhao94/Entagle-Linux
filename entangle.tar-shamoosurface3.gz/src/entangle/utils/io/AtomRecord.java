/*
 * Created on Jun 3, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package entangle.utils.io;

import java.text.DecimalFormat;

/**
 * @author unknown
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class AtomRecord {	
	/**
	 * Columns 1-6
	 */
	private String recordName = "ATOM  ";
	
	/**
	 * Columns 7-11
	 * Atom serial number
	 */
	private int serialNumber = -1; 
	private static DecimalFormat serialNumberFormat = new DecimalFormat("#####");
	
	/**
	 * 13-16
	 */
	private String atomName = "";
	
	// 17
	// alternate location
	private char altLoc = ' ';
	
	// 18-20
	// Residue name
	private String resName = "";
	
	// 22
	// Chain identifier
	private char chainID = 'A';
	
	// 23-26
	// Residue Sequence Number
	private int resSeq = -1;
	private static DecimalFormat resSeqFormat = new DecimalFormat("####");
	
	// 27
	// Code for insertion of residues
	private char iCode = 0;
	
	// 31-38 (8.3)
	// orthogonal coordinates for X in Angstroms
	private static DecimalFormat coordinateFormat = new DecimalFormat("#####.###;-####.###");
	private double x = 0.0;
	
	// 39-46
	// orthogonal coordinates for Y in Angstroms
	private double y = 0.0;
	
	// 47-54
	// orthogonal coordinates for Z in Angstroms
	private double z = 0.0;
	
	// 55-60 (6.2)
	// occupancy 
	private static DecimalFormat occupancyFormat = new DecimalFormat("####.##");
	private double occupany = 0.0;
	
	// 61-66
	// Temperature factor
	private static DecimalFormat tempFactorFormat = new DecimalFormat("####.##");
	private double tempFactor = 0.0;
	
	// 73-76
	// Segment identifier
	private String segID = "";
	
	// 77-78
	// Element symbol
	private String element = "";
	
	// 79-80
	private String charge = "";
	
	public String generatePDBString(){
		StringBuffer pdbBuffer = new StringBuffer();
		pdbBuffer.append("ATOM  ");
		// serial number 5 columns
		String serialString = serialNumberFormat.format(serialNumber);
		for(int i=5-serialString.length();i>0;i--){
			pdbBuffer.append(' ');
		}
		pdbBuffer.append(serialString);
		
		pdbBuffer.append(' ');
		
		// append atom name 4 columns
		int atomNameLength = atomName.length();
		switch(atomNameLength){
			case 1:
				pdbBuffer.append(' ').append(' ').append(atomName).append(' ');
				break;
			case 2:
				pdbBuffer.append(' ').append(atomName).append(' ');
				break;
			case 3:
				pdbBuffer.append(' ').append(atomName);
				break;
			case 4:
				pdbBuffer.append(atomName);
				break;
		}
				
		// append the alt location
		pdbBuffer.append(' ');
		
		// append the residue name 3 letters
		pdbBuffer.append(resName);
		
		// append the chain ID
		pdbBuffer.append(' ').append(chainID);
		
		// append the resSeq format
		String resSeqString = resSeqFormat.format(resSeq);
		for(int i=4-resSeqString.length();i>0;i--){
			pdbBuffer.append(' ');
		}
		pdbBuffer.append(resSeqString);
		
		// append the iCode
		pdbBuffer.append(' ');
		
		pdbBuffer.append("   ");
		
		// append x
		String xString = coordinateFormat.format(x);
		for(int i=8-xString.length();i>0;i--){
			pdbBuffer.append(' ');
		}
		pdbBuffer.append(xString);
		
		// append y
		String yString = coordinateFormat.format(y);
		for(int i=8-yString.length();i>0;i--){
			pdbBuffer.append(' ');
		}
		pdbBuffer.append(yString);
		
		// append z
		String zString = coordinateFormat.format(z);
		for(int i=8-zString.length();i>0;i--){
			pdbBuffer.append(' ');
		}
		pdbBuffer.append(zString);

		// 6 columns for occupancy
		String occupancyString = occupancyFormat.format(occupany);
		for(int i=6-occupancyString.length();i>0;i--){
			pdbBuffer.append(' ');
		}
		pdbBuffer.append(occupancyString);
		
		// 6 columns for temp factor
		String tempFactorString = tempFactorFormat.format(tempFactor);
		for(int i=6-tempFactorString.length();i>0;i--){
			pdbBuffer.append(' ');
		}
		pdbBuffer.append(tempFactorString);
		
		// segid
		pdbBuffer.append("       ");
		pdbBuffer.append(segID);
		for(int i=4-segID.length();i>0;i--){
			pdbBuffer.append(' ');
		}
		
		// append the element name
		pdbBuffer.append(element);
		for(int i=2-element.length();i>0;i--){
			pdbBuffer.append(' ');
		}
		
		// append the charge which isn't held right now
		pdbBuffer.append("  ");
		return pdbBuffer.toString();
	}
	
	public AtomRecord(String atomName,
				      String element,
					  int serialNumber,
	                  String resName,char chainID,
	                  int resSeq,double x,
	                  double y,
	                  double z){
		this.atomName = atomName;
		this.element = element;
		this.serialNumber = serialNumber;
		this.resName = resName;
		this.chainID = chainID;
		this.resSeq = resSeq;
		this.x = x;
		this.y = y;
		this.z = z;
	}
    	
	/**
	 * @return
	 */
	public char getAltLoc() {
		return altLoc;
	}

	/**
	 * @return
	 */
	public String getAtomName() {
		return atomName;
	}

	/**
	 * @return
	 */
	public char getChainID() {
		return chainID;
	}

	/**
	 * @return
	 */
	public String getCharge() {
		return charge;
	}

	/**
	 * @return
	 */
	public String getElement() {
		return element;
	}

	/**
	 * @return
	 */
	public char getICode() {
		return iCode;
	}

	/**
	 * @return
	 */
	public double getOccupany() {
		return occupany;
	}

	/**
	 * @return
	 */
	public String getRecordName() {
		return recordName;
	}

	/**
	 * @return
	 */
	public String getResName() {
		return resName;
	}

	/**
	 * @return
	 */
	public int getResSeq() {
		return resSeq;
	}

	/**
	 * @return
	 */
	public String getSegID() {
		return segID;
	}

	/**
	 * @return
	 */
	public int getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @return
	 */
	public double getTempFactor() {
		return tempFactor;
	}

	/**
	 * @return
	 */
	public double getX() {
		return x;
	}

	/**
	 * @return
	 */
	public double getY() {
		return y;
	}

	/**
	 * @return
	 */
	public double getZ() {
		return z;
	}

	/**
	 * @param c
	 */
	public void setAltLoc(char c) {
		altLoc = c;
	}

	/**
	 * @param string
	 */
	public void setAtomName(String string) {
		atomName = string;
	}

	/**
	 * @param c
	 */
	public void setChainID(char c) {
		chainID = c;
	}

	/**
	 * @param string
	 */
	public void setCharge(String string) {
		charge = string;
	}

	/**
	 * @param string
	 */
	public void setElement(String string) {
		element = string;
	}

	/**
	 * @param c
	 */
	public void setICode(char c) {
		iCode = c;
	}

	/**
	 * @param d
	 */
	public void setOccupany(double d) {
		occupany = d;
	}

	/**
	 * @param string
	 */
	public void setRecordName(String string) {
		recordName = string;
	}

	/**
	 * @param string
	 */
	public void setResName(String string) {
		resName = string;
	}

	/**
	 * @param i
	 */
	public void setResSeq(int i) {
		resSeq = i;
	}

	/**
	 * @param string
	 */
	public void setSegID(String string) {
		segID = string;
	}

	/**
	 * @param i
	 */
	public void setSerialNumber(int i) {
		serialNumber = i;
	}

	/**
	 * @param d
	 */
	public void setTempFactor(double d) {
		tempFactor = d;
	}

	/**
	 * @param d
	 */
	public void setX(double d) {
		x = d;
	}

	/**
	 * @param d
	 */
	public void setY(double d) {
		y = d;
	}

	/**
	 * @param d
	 */
	public void setZ(double d) {
		z = d;
	}

}
