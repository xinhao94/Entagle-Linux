package entangle.utils.io;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.Vector;

import entangle.datastructures.Atom;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.MoleculeLabel;
import entangle.datastructures.PDBInformation;
import entangle.datastructures.PDBModel;
import entangle.datastructures.Residue;
import entangle.utils.EntangleProperties;



/**
 * The class takes in a pdb (Protein Data Base) file and builds proteins and nucleic acids.
 * It creates a file which contains the serialized protein and nucleic acid objects.
 */
public class PDBParser
{
    String pdbName;
    boolean isDone = false;
    boolean areMoleculeLabelsToWorkFrom = false;
    Hashtable residueStructures;
    Hashtable vanderWaalsRadii;
    MoleculeLabel defaultProteinLabel = new MoleculeLabel("Protein",1);
    MoleculeLabel defaultRNALabel = new MoleculeLabel("RNA",2);
    MoleculeLabel defaultDNALabel = new MoleculeLabel("DNA",3);
    
    // objects to be written to output file
    PDBInformation pdbInformation;
    Vector pdbModels;

    // compound specification strings
    String MOL_ID = "MOL_ID:";
    String MOLECULE = "MOLECULE:";
    String CHAIN = "CHAIN:";
    String FRAGMENT = "FRAGMENT:";
    String SYNONYM = "SYNONYM:";
    String EC = "EC:";
    String MUTATION = "MUTATION:";
    String BIOLOGICAL_UNIT = "BIOLOGICAL_UNIT:";
    Stack compoundSpecificationStrings;
    LineNumberReader lineNumberReader;
    InputStream inputStream;
    String currentLine;
    
    File residueLibraryFile = new File(System.getProperty("user.dir") + File.separator +
			EntangleProperties.getProperties().getProperty("entangle.residueDefinitions"));
    File atomTypesFile = new File(System.getProperty("user.dir") + File.separator +
			EntangleProperties.getProperties().getProperty("entangle.atomTypesFile"));





    public PDBParser(InputStream inputStream,String pdbName)
    {
		pdbInformation = new PDBInformation();
		this.pdbName = pdbName;
		pdbInformation.setPDBName(pdbName);
		pdbModels = new Vector();
		this.inputStream = inputStream;
		
		ResidueLibraryParser residueLibraryParser = new ResidueLibraryParser(residueLibraryFile,atomTypesFile);
		
		residueStructures = residueLibraryParser.getResidueStructures();
		vanderWaalsRadii = residueLibraryParser.getVanderWaalsRadii();
		
		compoundSpecificationStrings = new Stack();
		compoundSpecificationStrings.push(MOL_ID);
		compoundSpecificationStrings.push(MOLECULE);
		compoundSpecificationStrings.push(CHAIN);
		compoundSpecificationStrings.push(FRAGMENT);
		compoundSpecificationStrings.push(SYNONYM);
		compoundSpecificationStrings.push(EC);
		compoundSpecificationStrings.push(MUTATION);
		compoundSpecificationStrings.push(BIOLOGICAL_UNIT);
    }
    
    
    
    
    
    public PDBInformation getPDBInformation()
    {
		return pdbInformation;
    }
    
    
    /**
     * returns vector of PDB models
     */
    public Vector getModels()
    {
		return pdbModels;
    }
    
    
    /**
     * Method which parses the PDB file 
     */
    public void parse() throws IOException
    {
	    lineNumberReader = new LineNumberReader(new InputStreamReader(inputStream));
	    
	    try{
			while (lineNumberReader.ready())
			{
				boolean containsMODELRecords = false;
				int modelNumber = 1;
				currentLine = lineNumberReader.readLine();
			
				// get compounds
				if (isCompoundLine(currentLine))
				{
					//System.out.println("Getting the compound information");
					readCompoundInformation();
				}
                                
				if(isModelLine(currentLine))
				{
					containsMODELRecords = true;
					currentLine = lineNumberReader.readLine();
					pdbModels.add(readModel(modelNumber));
					modelNumber++;
				}
			
				// get molecules
				if (isAtomLine(currentLine)&&!containsMODELRecords)
				{
					pdbModels.add(readModel(1));
					lineNumberReader.setLineNumber(lineNumberReader.getLineNumber() - 1);
				}
			}
	    }catch(RuntimeException e){
	    	System.err.println("error while processing " + currentLine);
	    	throw e;
	    }
	    
	    
	    if(!areMoleculeLabelsToWorkFrom)
	    {
			pdbInformation.addMoleculeLabel(defaultProteinLabel);
			pdbInformation.addMoleculeLabel(defaultRNALabel);
			pdbInformation.addMoleculeLabel(defaultDNALabel);
	    }
            
            
        try
        {
            inputStream.close();
        }
        catch(IOException e)
        {
        }
    }
    
    
    
    
    /**
     * reads the compound information and places the information into PDBInformation
     */
    public void readCompoundInformation()
    {
        Stack compoundLines = new Stack();
        String allCompoundLinesString = new String();
		int currentIndex;
		
        while (isCompoundLine(currentLine))
        {
                compoundLines.push(currentLine);
                
                try
                {
                        currentLine = lineNumberReader.readLine();
                }catch(IOException e)
                {
                        e.printStackTrace(System.out);
                }
                
		}
		
        // reverse the order of the current lines so that we can remove the first ones first
        Collections.reverse(compoundLines);
        lineNumberReader.setLineNumber(lineNumberReader.getLineNumber()-1);
        
        // use the concatenated compound lines to build molecule labels
        createMoleculeLabels(compoundLines);
        pdbInformation.setCompoundLines((Stack)compoundLines.clone());
    }
    
    
    
    
    /**
    * creates molecule labels from the concatenated compound lines
    */
    public void createMoleculeLabels(Stack compoundLines)
    {
        //check to see the style of the compound lines
        //We've got old school and new school
		Vector moleculeInformationStrings = null;
		Vector moleculeLabels = new Vector();
		
		while(!compoundLines.empty())
		{
			String currentLine = (String)compoundLines.pop();
			
			if(currentLine.indexOf(MOL_ID)!=-1)
			{
				if(moleculeInformationStrings!=null)
				{
					moleculeLabels.add(createMoleculeLabel(moleculeInformationStrings, compoundSpecificationStrings));
					areMoleculeLabelsToWorkFrom = true;
				}
				
				moleculeInformationStrings = new Vector();
			}
			
			if(moleculeInformationStrings!=null) 
				moleculeInformationStrings.add(currentLine);
				
    	}
    	
		if(areMoleculeLabelsToWorkFrom)
		{
			moleculeLabels.add(createMoleculeLabel(moleculeInformationStrings, compoundSpecificationStrings));
			
			for(Iterator moleculeLabelsIterator = moleculeLabels.iterator(); moleculeLabelsIterator.hasNext();)
			{
				pdbInformation.addMoleculeLabel((MoleculeLabel)moleculeLabelsIterator.next());		
			}
		}
    }
    
    
    
    /**
    * creates a moleculeLabel from the specified string
    */
    public MoleculeLabel createMoleculeLabel(Vector moleculeInformationLines, Stack compoundSpecificationStrings)
    {
		String moleculeName = "";
		int molID = 0;
		Vector chainIDs = new Vector();
		
		for(Iterator lineIterator = moleculeInformationLines.iterator(); lineIterator.hasNext();)
		{
			String nextLine = (String)lineIterator.next();
			int toIndex = nextLine.indexOf(pdbName);
            
            if(toIndex==-1)
            	toIndex = nextLine.length()-1; String tempString = nextLine.substring(10,toIndex);
            	
			StringTokenizer st = new StringTokenizer(tempString,", ;\t\n\r\f");
			LinkedList list = new LinkedList();
			
			while(st.hasMoreTokens())
			{
				String token = st.nextToken();
				list.add(token);
			}
			
			int MOLECULEIndex = list.indexOf(MOLECULE);
			int CHAINIndex = list.indexOf(CHAIN);
			int MOL_IDIndex = list.indexOf(MOL_ID);
			
			int i = 0;
			
			if(MOL_IDIndex!=-1)
			{
				i = MOL_IDIndex + 1;
				
				try
				{
					molID = Integer.parseInt((String)list.get(i));
				}
				catch(NumberFormatException exc)
				{
					System.out.println("Could not create molecule label");
				}
			}
			
			if(MOLECULEIndex!=-1)
			{
				i = MOLECULEIndex + 1;
				
				while(i<list.size())
				{
					String tempNameAddition = (String)list.get(i);
					moleculeName += " " + tempNameAddition;
					i++;
				}
			}
			
			if(CHAINIndex!=-1)
			{
				i = CHAINIndex + 1;
				
				while(i<list.size())
				{
					String tempChainID = (String)list.get(i);
					chainIDs.add(tempChainID);
					i++;
				}
			}
		}
		
		MoleculeLabel moleculeLabel = new MoleculeLabel(moleculeName.trim(), molID);
		
		for(Iterator chainIDIterator = chainIDs.iterator(); chainIDIterator.hasNext();)
		{
			moleculeLabel.addChainID((String)chainIDIterator.next());
		}
		
		return moleculeLabel;
    }
    
    
    
    /**
     * Reading model when a model line is reached and until an end model line
     */
    public PDBModel readModel(int modelNumber)
    {
        PDBModel currentModel = new PDBModel(modelNumber);
        
        try
        {
            while(lineNumberReader.ready()&&!(isEndModelLine(currentLine)) && (isAtomLine(currentLine)||isTerminationLine(currentLine) 
            		|| isLine(currentLine,"SIGATM")||isLine(currentLine,"ANSIOU")
			  		|| isLine(currentLine,"SIGUIJ")||isLine(currentLine,"HETATM")))
			{
				if(isAtomLine(currentLine))
			    	currentModel.addMacromolecule(readMacromolecule());
			
				currentLine = lineNumberReader.readLine();
            }
            
        }
        catch(IOException e)
        {
            e.printStackTrace(System.out);
        }
            
        return currentModel;
    }
    
    
    
    
    /**
     * Read in a macromolecule when a beginning atom line is reached
     */
    public Macromolecule readMacromolecule()
    {
		Atom firstAtom;
		Atom tempAtom;
		
		firstAtom = readAtomLine();
		tempAtom = readAtomLine();
		
		String chainID = firstAtom.getChainID();
		String moleculeName = getMoleculeName(chainID);
		
		Macromolecule currentMacromolecule = new Macromolecule(residueStructures, vanderWaalsRadii, pdbName);
		currentMacromolecule.setName(moleculeName);
		currentMacromolecule.setChainIdentifier(chainID);
		
		while (!isTerminationLine(currentLine)&&isAtomLine(currentLine) && tempAtom.getChainID().equals(
					currentMacromolecule.getChainIdentifier()))
		{
		    tempAtom = readAtomLine();
		    
		    if(tempAtom.getChainID().equals(currentMacromolecule.getChainIdentifier()))
		    	currentLine = readResidue(tempAtom,currentMacromolecule);
		}
		
		// find out the macromolecule type
		currentMacromolecule.setType(getMacromoleculeType(currentMacromolecule));
		
		// build default molecule labels if none were made from before
		if(!areMoleculeLabelsToWorkFrom)
		{
		    if(currentMacromolecule.getType().equals(Macromolecule.PROTEIN))
				defaultProteinLabel.addChainID(currentMacromolecule.getChainIdentifier());
		    if(currentMacromolecule.getType().equals(Macromolecule.RNA))
				defaultRNALabel.addChainID(currentMacromolecule.getChainIdentifier());
		    if(currentMacromolecule.getType().equals(Macromolecule.DNA))
				defaultDNALabel.addChainID(currentMacromolecule.getChainIdentifier());
		}
		
		return currentMacromolecule;
    }
    
    public String getMacromoleculeType(Macromolecule macromolecule)
    {
        String macromoleculeType = "";
        String[] proteinResidueStrings = {"ASN","ASP","ARG","CYS","ASP","GLU","PHE","GLY","HIS","ILE",
                                          "LYS","LEU","MET","ASN","PRO","GLN","SER","THR","VAL","TRP",
                                          "TYR"};
        String[] nucleicAcidResidueStrings = {"A","C","U","T","G"};
        
	    int numberOfResidues = macromolecule.getResidues().size();
	    int numberOfRNAs = 0;
	    
	    boolean isNucleicAcid = false;
	    
        for(int i=0;i<proteinResidueStrings.length;i++)
        {
            if(macromolecule.containsResidueType(proteinResidueStrings[i]))
                macromoleculeType = Macromolecule.PROTEIN;
        }
        
        for(int j=0;j<nucleicAcidResidueStrings.length;j++)
        {
            if(macromolecule.containsResidueType(nucleicAcidResidueStrings[j]))
            {
				isNucleicAcid = true;
            }
        }
        
	    if(isNucleicAcid)
	    {
			for(Enumeration e = macromolecule.getResidueEnumeration(); e.hasMoreElements();)
			{
				Residue residue = (Residue)e.nextElement();
				
				if(residue.containsAtom("O2*"))
					numberOfRNAs++;
			}
            
            if(numberOfRNAs > numberOfResidues/2.0)
            {
                macromoleculeType = Macromolecule.RNA;
            }
            else
            {
                macromoleculeType = Macromolecule.DNA;
            }
	    }
        
        return macromoleculeType;
    }
    
    
    
    
    
    
    
    
    /**
     * returns the next residue from the PDB file and returns the currentLine being read from
     * the file
     */
    public String readResidue(Atom firstAtom,Macromolecule currentMacromolecule)
    {
		int residueType;
		String resName = firstAtom.getResName();
		Atom tempAtom = firstAtom;
		Residue currentResidue = new Residue(resName);
    	currentResidue.setChainID(firstAtom.getChainID());
		int currentResSeq = firstAtom.getResSeq();
		currentResidue.setResidueSequenceNumber(currentResSeq);
		
		while ((tempAtom.getResSeq() == currentResSeq) && isAtomLine(currentLine) && !(isTerminationLine(currentLine)))
		{
			currentResidue.addAtom(tempAtom);
    	    tempAtom.setParentResidue(currentResidue);
    	    
			try
			{
			    currentLine = lineNumberReader.readLine();
			}
			catch(IOException e)
			{
			    System.out.println("unable to read line while reading residue");
			}
			
			if (!(isTerminationLine(currentLine))&&isAtomLine(currentLine))
			{
				tempAtom = readAtomLine();
			} 
		}
		
		currentMacromolecule.addResidue(currentResidue);
    	currentResidue.setParentMacromolecule(currentMacromolecule);
    	
		return currentLine;
    }
    
    
    
    
    
    
    /**
     * Creates an Atom from a atom record
     */
    public Atom readAtomLine()
    {
		Atom currentAtom = new Atom();
		
		// Get the serial number
    	currentAtom.setSerial(Integer.parseInt(currentLine.substring(6,11).trim()));	
		
		// Get the atom name
		currentAtom.setName(currentLine.substring(12,16).trim());
		
		// Get the residue name
		currentAtom.setResName(currentLine.substring(17,20).trim());
		
		// Get the chain info
		currentAtom.setChainID(currentLine.substring(21,22).trim());
		
		// Get the residue number
		currentAtom.setResSeq(Integer.parseInt(
    	currentLine.substring(22,26).trim()));
    	
		// Get the coordinates
	 	String trimmedX = currentLine.substring(30,38).trim();
	 	double x = Double.parseDouble(trimmedX);
		
		String trimmedY = currentLine.substring(38,46).trim();
		double y = Double.parseDouble(trimmedY);
		
		String trimmedZ = currentLine.substring(46,54).trim();
		double z = Double.parseDouble(trimmedZ);
		
    	currentAtom.setCoordinates(x,y,z);
    	
		return currentAtom;
    }





    /**
     * Method which retrieves a molecule's name from the moleculeLabels
     */
    public String getMoleculeName(String chainID)
    {
		String moleculeName = "";
		
		// find out which one of the molecule names this chain matches
		for (Enumeration e = pdbInformation.getMoleculeLabelElements();e.hasMoreElements();)
		{
		    MoleculeLabel tempMoleculeLabel = (MoleculeLabel)e.nextElement();
		    
		    if (isChainIDInMoleculeLabel(chainID, tempMoleculeLabel))
		    {
				moleculeName = tempMoleculeLabel.getMoleculeName();
		    }
		}
		
		return moleculeName;
    }




    private boolean isChainIDInMoleculeLabel(String chainID, MoleculeLabel moleculeLabel)
    {
		boolean isChainID = false;
		int size = moleculeLabel.getChainIDs().size();
		
		for (int i = 0; i < size; i++)
		{
			if (chainID.equals( (String) (moleculeLabel.getChainIDs().elementAt(i))))
			{
				isChainID = true;
			}
		}
		    
		return isChainID;
    }





    /**
     * Asks if the current line is a record of the specified type
     * Returns true if record is of the type specified
     */
    public boolean isLine(String recordLine, String recordName)
    {
        boolean isLine = false;
        
        try
        {
            String lineIdentity = recordLine.substring(0,6).trim();
            isLine = lineIdentity.equals(recordName);
        }
        catch(Exception e)
        {
        }
        
        return isLine;
    }

        
        
        
    public boolean isEndModelLine(String recordLine)
    {
        boolean isModel;
        isModel = isLine(recordLine,"ENDMDL");
        
        return isModel;
    }
    
    
    
    
    /**
     * Asks if the string is a MODEL record
     */
    public boolean isModelLine(String recordLine)
    {
        boolean isModel;
        isModel = isLine(recordLine,"MODEL");
        
        return isModel;
    }
        
    
    
    /**
     * Asks if the current line is a compound record
     */
    public boolean isCompoundLine(String recordLine)
    {
        boolean isCompound;
        isCompound = isLine(recordLine, "COMPND");
        
        return isCompound;
    }



    /**
     * Asks if the current line is an atom record
     */
    public boolean isAtomLine(String recordLine)
    {
        boolean isAtom;
        isAtom = isLine(recordLine, "ATOM");
        
        return isAtom;
    }

    
    
    /**
     * Asks if the current line is a termination record
     */
    public boolean isTerminationLine(String recordLine)
    {
        boolean isTermination;
        isTermination = isLine(recordLine, "TER");
        
        return isTermination;
    }
}