package entangle.utils;

import java.util.Enumeration;
import java.util.Hashtable;

import javax.vecmath.Point3d;

import entangle.datastructures.Atom;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.Residue;

/**
 * A class which finds the center of mass of a residue or a macromolecule. It's not a very precise center of mass
 * because it's just useful for figuring out how a good pivot point for a residue.
 * 
 * @author Jim Allers
 */ 
public class CenterOfMassFinder
{
        Hashtable weights;
        final static String C = "C";
        final static String N = "N";
        final static String O = "O";
        final static String S = "S";
        final static String H = "H";
        final static String P = "P";
        
        
        public CenterOfMassFinder()
        {
                weights = new Hashtable();
                weights.put(C,new Double(12.01));
                weights.put(N,new Double(14.02));
                weights.put(O,new Double(16.00));
                weights.put(S,new Double(32.00));
                weights.put(H,new Double(1.008));
                weights.put(P,new Double(30.97));
        }
        
        
        
        
        public double getWeight(Atom atom)
        {
                String atomName = atom.getName();
                double weight = 0;
                if(atomName.indexOf(C)!=-1) weight = ((Double)weights.get(C)).doubleValue();
                if(atomName.indexOf(N)!=-1) weight = ((Double)weights.get(N)).doubleValue();
                if(atomName.indexOf(O)!=-1) weight = ((Double)weights.get(O)).doubleValue();
                if(atomName.indexOf(S)!=-1) weight = ((Double)weights.get(S)).doubleValue();
                if(atomName.indexOf(H)!=-1) weight = ((Double)weights.get(H)).doubleValue();
                if(atomName.indexOf(P)!=-1) weight = ((Double)weights.get(P)).doubleValue();
                return weight;
        }
        
        
        public Point3d findCenterOfMass(Macromolecule protein, Macromolecule rna)
        {
                Point3d centerOfMass = computeCenterOfMass(protein,rna).getCenterOfMass();
                return centerOfMass;
        }
        
        
        private CenterOfMassInfo computeCenterOfMass(Macromolecule protein,Macromolecule rna)
        {
                double totalMass = 0; double weightedX = 0;
                double weightedY = 0; double weightedZ = 0;
                CenterOfMassInfo proteinCenter = computeCenterOfMass(protein);
                CenterOfMassInfo rnaCenter = computeCenterOfMass(rna);
                double proteinMass = proteinCenter.getTotalMass();
                double rnaMass = rnaCenter.getTotalMass();
                totalMass = proteinMass + rnaMass;
                weightedX = proteinMass*proteinCenter.getCenterOfMass().x + rnaMass*rnaCenter.getCenterOfMass().x;
                weightedY = proteinMass*proteinCenter.getCenterOfMass().y + rnaMass*rnaCenter.getCenterOfMass().y;
                weightedZ = proteinMass*proteinCenter.getCenterOfMass().z + rnaMass*rnaCenter.getCenterOfMass().z;
                CenterOfMassInfo comi = new CenterOfMassInfo(totalMass,
                                new Point3d(weightedX/totalMass,weightedY/totalMass,weightedZ/totalMass));
                return comi;
       }      
       
       
       
       public Point3d findCenterOfMass(Macromolecule macromolecule)
       {
                Point3d centerOfMass = computeCenterOfMass(macromolecule).getCenterOfMass();
                return centerOfMass;
       }
       
       
       
       public CenterOfMassInfo computeCenterOfMass(Macromolecule macromolecule)
       {
                double totalMass = 0; double weightedX = 0;
                double weightedY = 0; double weightedZ = 0;
                
                for(Enumeration e = macromolecule.getResidueEnumeration();e.hasMoreElements();)
                {
                        Residue tempResidue = (Residue)e.nextElement();
                        CenterOfMassInfo residueCenter = computeCenterOfMass(tempResidue);
                        totalMass += residueCenter.getTotalMass();
                        weightedX += residueCenter.getTotalMass()*residueCenter.getCenterOfMass().x;
                        weightedY += residueCenter.getTotalMass()*residueCenter.getCenterOfMass().y;
                        weightedZ += residueCenter.getTotalMass()*residueCenter.getCenterOfMass().z;
                }
                
                CenterOfMassInfo comi = new CenterOfMassInfo(totalMass,
                                new Point3d(weightedX/totalMass,weightedY/totalMass,weightedZ/totalMass));
                return comi;
        }
        
        
        
        public Point3d findCenterOfMass(Residue residue)
        {
                Point3d centerOfMass = computeCenterOfMass(residue).getCenterOfMass();
                return centerOfMass;
        }        
        
        
        
        private CenterOfMassInfo computeCenterOfMass(Residue residue)
        {
                double totalMass = 0;double weightedX = 0;
                double weightedY = 0;double weightedZ = 0;
                
                for(Enumeration e = residue.getAtomEnumeration(); e.hasMoreElements();)
                {
                        Atom tempAtom = (Atom)e.nextElement();
                        double weight = getWeight(tempAtom);
                        totalMass += weight;
                        weightedX += weight*tempAtom.getX();
                        weightedY += weight*tempAtom.getY();
                        weightedZ += weight*tempAtom.getZ();
                }
                
                CenterOfMassInfo comi = new CenterOfMassInfo(totalMass,
                                new Point3d(weightedX/totalMass,weightedY/totalMass,weightedZ/totalMass));
                return comi;
        }
        
        
        /**
         * ouputs a string that specifies what type of atom the atom is 
         * O-oxygen, N-nitrogen, P-phosphorous, S-sulfur, H-hydrogen
         */
        public String atomType(String atomName)
        {
                String atomType = "C";
                if(atomName.indexOf("C")!=-1)  atomType = "C";
                if(atomName.indexOf("N") !=-1) atomType = "N";
                if(atomName.indexOf("O")!=-1)  atomType = "O";
                if(atomName.indexOf("S")!=-1)  atomType = "P";
                if(atomName.indexOf("H")!=-1)  atomType = "H";
                if(atomName.indexOf("S")!=-1)  atomType = "S";
                return atomType;
        }
        
        
        
        /**
         * inner class which has both the center of mass and total mass of a residue or macromolecule
         */
        private class CenterOfMassInfo
        {
                public double totalMass;
                public Point3d centerOfMass;
                
                
                public CenterOfMassInfo(double totalMass,Point3d centerOfMass)
                {
                        this.totalMass = totalMass;
                        this.centerOfMass = centerOfMass;
                }
                
                
                public void setTotalMass(double totalMass)
                {
                        this.totalMass = totalMass;
                }
                
                public void setCenterOfMass(Point3d centerOfMass)
                {
                        this.centerOfMass = centerOfMass;
                }
                
                public Point3d getCenterOfMass()
                {
                        return centerOfMass;
                }
                
                public double getTotalMass()
                {
                        return totalMass;
                }
        }
}        