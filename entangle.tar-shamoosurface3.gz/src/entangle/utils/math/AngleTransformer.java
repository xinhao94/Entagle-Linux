/*
 * AngleTransformer.java
 *
 * Created on August 17, 2000, 4:17 PM
 */

package entangle.utils.math;

/**
 * A convenience for converting degress to radians and radians to degrees.
 * @author  Jim Allers
 * @version 1.0
 */
public class AngleTransformer extends Object 
{
	
    /** Creates new AngleTransformer */
    public AngleTransformer() 
    {
    }



    /**
    * outputs angle in radians
    */
    public static double degreesToRadians(double degrees)
    {
       double radians = degrees*2*Math.PI/360.0;
       return radians;
    }
    
    
    
    public static double radiansToDegrees(double radians)
    {
        double degrees = radians*360.0/(2*Math.PI);
        return degrees;
    }
}