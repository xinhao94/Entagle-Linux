package entangle.utils.math;

import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector4d;

/**
 * A utility class for working with planes.
 * @author Jim Allers
 * @version 1.0
 */
public class Plane
{
    					// ax + by + cz + d = 0 defines the plane
    Vector4d plane4d;  	// a is x, b is y, c is z, d is w
    Vector3d normal;
    
    
    public Plane(Vector4d plane4d)
    {
		this.plane4d = plane4d;
		normal = new Vector3d(plane4d.x,plane4d.y,plane4d.z);
    }
    
    
    
    public Plane(Vector3d normal,Point3d pointOfIntersection)
    {
		this.normal = normal;
		double a = normal.x;
		double b = normal.y;
		double c = normal.z;
		double d = -a*pointOfIntersection.x - b*pointOfIntersection.y - c*pointOfIntersection.z; 
		plane4d = new Vector4d(a,b,c,d);
    }
    
    
    
    /**
     * Constructs a plane with a not normalized normal of AxB
     */
    public Plane(Vector3d vectorA,Vector3d vectorB,Point3d pointOfIntersection)
    {
        Vector3d normal = new Vector3d();
        normal.cross(vectorA,vectorB);
        this.normal = normal;
		double a = normal.x;
		double b = normal.y;
		double c = normal.z;
		double d = -a*pointOfIntersection.x - b*pointOfIntersection.y - c*pointOfIntersection.z; 
		plane4d = new Vector4d(a,b,c,d);
    }
    
    
    
    
    /**
     * Constructs plane with a not normalized normal of
     * (p2i - p1i) x (p3i - p1i)
     */
    public Plane(Point3d p1,Point3d p2,Point3d p3)
    {
        this(new Vector3d(p2.x-p1.x, p2.y-p1.y, p2.z-p1.z), new Vector3d(p3.x-p1.x, p3.y-p1.y, p3.z-p1.z), p3);
	}
    
    
    
    
    
    public Vector4d  getVectorRepresentation()
    {
        return plane4d;
    }
    
    
    public Vector3d getNormal()
    {
		return normal;
    }
    
    
    public double getDihedralAngle(Plane targetPlane)
    {
		double dihedralAngle = this.getNormal().angle(targetPlane.getNormal());
		return dihedralAngle;
    }
}