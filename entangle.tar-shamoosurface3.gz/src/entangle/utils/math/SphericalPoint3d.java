/*
 * SphericalPoint3d.java
 *
 * Created on August 15, 2000, 3:40 PM
 */

package entangle.utils.math;




/**
 * This class represents a point in spherical coordinates.
 * @author  Jim Allers
 * @version 1.0
 */
public class SphericalPoint3d 
{
    /** Creates new SphericalPoint3d */
    public double r;
    public double theta;
    public double phi;
    
    
    /**
     * r [0, infinity), theta [0,2PI), phi [0,PI]
     */
    public SphericalPoint3d(double r, double theta, double phi) 
    {
        this.r = r;
        this.theta = theta;
        this.phi = phi;
    }
}