package entangle.utils.math;

/**
 * @author unknown
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class XYZMatrix extends Matrix {
	/**
	 * public double[][] data;
	 * public int rows;
	 * public int cols;
	 */

	public XYZMatrix(int r, int c, double[][] m) {
		super(r, c, m);
	}

	public XYZMatrix(double x, double y, double z) {
		double[][] d = new double[1][3];
		d[0][0] = x;
		d[0][1] = y;
		d[0][2] = z;
		rows = 1;
		cols = 3;
		data = d;
	}

	public double getX() {
		return data[0][0];
	}

	public double getY() {
		return data[0][1];
	}

	public double getZ() {
		return data[0][2];
	}

	/**
	 * ROTATIONS 
	 *
	 * Spherical coordinates:
	 * x,y,z -> r,theta,phi
	 * 
	 * r = length
	 * theta = angle in x-y plane from positive x-axis, [0,2pi)
	 * phi = angle from positive z-axis, [0,pi]
	 *
	 * double r = Math.sqrt(x*x + y*y + z*z);
	 * double theta = Math.atan2(y,x);
	 * double phi = Math.acos(z/r);
	 */
	public double getR() {
		return Math.sqrt(data[0][0] * data[0][0] + data[0][1] * data[0][1] + data[0][2] * data[0][2]);
	}


	public double getXYTheta() {
		return Math.atan2(data[0][1], data[0][0]);
	}

	public double getYZTheta(){
		return Math.atan2(data[0][2], data[0][1]);
	}

	public double getZXTheta() {
		return Math.atan2(data[0][0], data[0][2]);
	}


	public double getXYPhi() {
		return Math.acos(data[0][2] / getR() );
	}
	
	public double getYZPhi(){
		return Math.acos(data[0][0] / getR() );
	}

	public double getZXPhi() {
		return Math.acos(data[0][1] / getR() );
	}

		
	/**
	 * Applies the given Theta rotation in the standard XYZ spherical
	 * coordinate system to the XYZ coordinates internally.
	 * 
	 * x = r cos T sin P
	 * y = r sin T sin P
	 * z = r cos P
	 */
	public void applyXYRotation(double rTheta){
		double r = getR();
		double theta = getXYTheta() + rTheta;
		double phi = getXYPhi();
		data[0][0] = r * Math.cos(theta) * Math.sin(phi);
		data[0][1] = r * Math.sin(theta) * Math.sin(phi);
		data[0][2] = r * Math.cos(phi);
	}

	public void applyYZRotation(double rTheta){
		double r = getR();
		double theta = getYZTheta() + rTheta;
		double phi = getYZPhi();
		data[0][1] = r * Math.cos(theta) * Math.sin(phi);
		data[0][2] = r * Math.sin(theta) * Math.sin(phi);
		data[0][0] = r * Math.cos(phi);
	}
	
	public void applyZXRotation(double rTheta){
		double r = getR();
		double theta = getZXTheta() + rTheta;
		double phi = getZXPhi();
		data[0][2] = r * Math.cos(theta) * Math.sin(phi);
		data[0][0] = r * Math.sin(theta) * Math.sin(phi);
		data[0][1] = r * Math.cos(phi);
	}


	/**
	 * Mathematical dot product
	 */
	public double dot(XYZMatrix B){
		double x = this.getX()*B.getX();
		double y = this.getY()*B.getY();
		double z = this.getZ()*B.getZ();
		
		return x + y + z;
	}

	/**
	 * INHERITED METHODS
	 */
	public Matrix copy() {
		double[][] newData = new double[rows][cols];
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				newData[i][j] = data[i][j];

		return new XYZMatrix(rows, cols, newData);
	}

	public Matrix add(Matrix B) {
		if (B.rows != this.rows || B.cols != this.cols)
			return null;

		XYZMatrix C = new XYZMatrix(rows, cols, new double[rows][cols]);

		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				C.data[i][j] = this.data[i][j] + B.data[i][j];

		return C;
	}

	public Matrix subtract(Matrix B) {
		if (B.rows != this.rows || B.cols != this.cols)
			return null;

		XYZMatrix C = new XYZMatrix(rows, cols, new double[rows][cols]);

		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				C.data[i][j] = this.data[i][j] - B.data[i][j];

		return C;
	}
	
	
	public String toString(){
		return "(" + getX() + "," + getY() + "," + getZ() + ") length=" + getR();
	}
	
	/**
	 * determines the angle ABC, with BA and BC the two vectors, and B the vertex.
	 */
	public static double getAngle(XYZMatrix A, XYZMatrix B, XYZMatrix C){
		XYZMatrix BA = (XYZMatrix)A.subtract(B);
		XYZMatrix BC = (XYZMatrix)C.subtract(B);
		
		return Math.acos(BA.dot(BC) / (BA.getR() * BC.getR() ) );
	}
	
	public static double getAngle(XYZMatrix B, XYZMatrix C){
		return Math.acos(B.dot(C) / (B.getR() * C.getR() ) );
	}
	
	
	/**
	 * Applies 4 transformations, in order:
	 * 	1) translation -t
	 * 	2) XYZ theta rotation r1
	 * 	3) ZXY theta rotation r2
	 * 	4) YZX theta rotation r3
	 */
    public void transform(XYZMatrix t, double r1, double r2, double r3){
    	XYZMatrix temp = (XYZMatrix)this.subtract(t);
    	temp.applyXYRotation(r1);
    	temp.applyZXRotation(r2);
    	temp.applyYZRotation(r3);
    	
    	this.rows = temp.rows;
    	this.cols = temp.cols;
    	this.data = temp.data;
    }
}
