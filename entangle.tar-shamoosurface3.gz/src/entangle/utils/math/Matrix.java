package entangle.utils.math;

/**
 * @author Lowell Meyer
 *
 * Basic Matrix class.  Represents a generic rowsXcolumns matrix.
 * Basic matrix operations are defined.
 */
public class Matrix
{
	public double[][] data; /* A[row][column] */
	public int rows;
	public int cols;

	Matrix(){
	}

	public Matrix(int r, int c, double[][] m)
	{
		rows = r;
		cols = c;
		data = m;
	}

	public Matrix copy(){
		double[][] newData = new double[rows][cols];
		for(int i = 0; i < rows; i++)
			for(int j = 0; j < cols; j++)
				newData[i][j] = data[i][j];
				
		return new Matrix(rows, cols, newData);
	}

	public void add(int n)
	{
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				data[i][j] += n;
	}

	public void add(double n)
	{
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				data[i][j] += n;
	}

	public void multiply(int n)
	{
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				data[i][j] *= n;
	}

	public void multiply(double n)
	{
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				data[i][j] *= n;
	}

	public Matrix add(Matrix B)
	{
		if (B.rows != this.rows || B.cols != this.cols)
			return null;

		Matrix C = new Matrix(rows, cols, new double[rows][cols]);

		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				C.data[i][j] = this.data[i][j] + B.data[i][j];

		return C;
	}

	public Matrix subtract(Matrix B)
	{
		if (B.rows != this.rows || B.cols != this.cols)
			return null;

		Matrix C = new Matrix(rows, cols, new double[rows][cols]);

		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				C.data[i][j] = this.data[i][j] - B.data[i][j];

		return C;
	}

	public Matrix multiply(Matrix B)
	{
		if (B.rows != this.cols)
			return null;

		Matrix C = new Matrix(this.rows, B.cols, new double[this.rows][B.cols]);

		for (int i = 0; i < this.rows; i++)
			for (int j = 0; j < B.cols; j++)
			{
				C.data[i][j] = 0;
				for (int n = 0; n < this.cols; n++)
					C.data[i][j] += this.data[i][n] + B.data[n][j];
			}

		return C;
	}
}
