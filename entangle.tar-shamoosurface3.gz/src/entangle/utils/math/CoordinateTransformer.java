/*
 * CoordinateTransformer.java
 *
 * Created on August 15, 2000, 3:36 PM
 */

package entangle.utils.math;

import javax.vecmath.Point3d;



/**
 * Utility class for converting spherical coordinates to cartesian coordinates, 
 * and vice versa.
 * @author  Jim Allers
 * @version 1.0
 */
public class CoordinateTransformer extends Object 
{
    /** Creates new CoordinateTransformer */
    public CoordinateTransformer() 
    {
    }



    /**
     * Converts x,y,z to r,theta,phi (r (0,infinity), theta (0,2PI), phi (0,PI))
     */
    public static SphericalPoint3d cartesianToSpherical(Point3d cartesianPoint)
    {
        double x = cartesianPoint.x; double y = cartesianPoint.y;
        double z = cartesianPoint.z;    
        double r = Math.sqrt(x*x + y*y + z*z);
        double theta = Math.atan2(y,x);
        double phi = Math.acos(z/r);
        return new SphericalPoint3d(r,theta,phi);
    }
    
    
    
    /**
     * converts r,theta,phi to x,y,z
     */
    public static Point3d sphericalToCartesian(SphericalPoint3d sphericalPoint)
    {
        double r = sphericalPoint.r;
        double theta = sphericalPoint.theta;
        double phi = sphericalPoint.phi;
        double x = r*Math.cos(theta)*Math.sin(phi);
        double y = r*Math.sin(theta)*Math.sin(phi);
        double z = r*Math.cos(phi);
        return new Point3d(x,y,z);
    }
}