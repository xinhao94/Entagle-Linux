/*
 * Created on September 7, 2000, 5:26 PM
 */

package entangle.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


/**
 * Singleton which represents the properties of entangle, this is separate from 
 * the classifier properties
 *
 * so far the properties are:
 *
 * entangle.donorGroupGeometriesFile 
 * entangle.atomTypesFile 
 * entangle.residueDefinitions 
 * entangle.hydrogenBondAcceptors 
 * entangle.hydrogenBondDonors 
 * entangle.aromaticRingsDirectory 
 * entangle.electrostaticIconImage 
 * entangle.hydrogenBondIconImage 
 * entangle.hydrophobicIconImage 
 * entangle.stackingInteractionIconImage 
 * entangle.VanderWaalsIconImage
 * entangle.lookAndFeel
 *
 * @author Jim Allers
 * @version 
 */
public class EntangleProperties extends Properties
{
	static EntangleProperties properties = null;
	static File entanglePropertiesFile = new File(System.getProperty("user.dir") + File.separator + "entangle.properties");
	
	
    /** Creates new EntangleProperties */
	private EntangleProperties() 
	{
	}
	
	
	
	
	public static EntangleProperties getProperties()
	{
		if(properties==null)
		{
			init();
		}
		return properties;
	}
	
	
    /**
     * Initialize the properties for the Entangle application. 
     */
	static void init()
	{
		properties = new EntangleProperties();
		try
		{
			properties.load(new FileInputStream(entanglePropertiesFile));
		}
		catch(IOException e)
		{
			System.out.println("Could not load properties file");
			System.out.println(e);
		}
	}
	
	
    /**
     * Gets the property that goes along with the following key.
     */
	public String getEntangleProperty(String key)
	{
		if(properties==null)
		{
			init();
		}
		
		return properties.getProperty(key);
	}
}