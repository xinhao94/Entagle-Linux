package entangle.utils;

import entangle.utils.math.XYZMatrix;

/**
 * @author unknown
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface Transformable {
	public void transform(XYZMatrix t, double r1, double r2, double r3);
}
