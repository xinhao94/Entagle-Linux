/*
 * PNDatabaseMaker.java
 *
 * Created on November 12, 2000, 10:41 PM
 */

package entangle.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


/**
 *
 * @author  Jim Allers
 * @version 
 */
public class PNDatabaseMaker extends Object
{
	Connection dbConnection;
	public static final String HYDROGEN_BONDS_TABLE = "DNAProteinhydrogenBondsTable";
	public static final String ELECTROSTATIC_INTERACTIONS_TABLE = "DNAProteinelectrostaticInteractionsTable";
	public static final String STACKING_INTERACTIONS_TABLE = "DNAProteinstackingInteractionsTable";
	
	
    /** Creates new PNDatabaseMaker */
   	public PNDatabaseMaker() 
   	{
		try
		{
        	PrintStream filePrintStream = new PrintStream(new FileOutputStream("output"));
            PrintStream errorPrintStream = new PrintStream(new FileOutputStream("error"));
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            System.setOut(filePrintStream);
            System.setErr(errorPrintStream);
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
        }
        catch(FileNotFoundException fnfe)
        {
            fnfe.printStackTrace();
        }
	}
	
	
	
	
	public static void main(String[] args)
	{
		PNDatabaseMaker maker = new PNDatabaseMaker();
		String url = "jdbc:odbc:Protein-RNA Interactions";
		Statement statement = null;
		
		try
		{
			maker.setConnection(DriverManager.getConnection(url));
			statement = maker.dbConnection.createStatement();
		}
		catch(SQLException e)
		{
			e.printStackTrace(System.out);
		}
		
		
		try
		{
            String createHydrogenBondsInteractionTableStatement = "create table " + PNDatabaseMaker.HYDROGEN_BONDS_TABLE
                + " (pdbID varchar(20), pChainID varchar(3), " + "pResName varchar(5), pResSeq integer,"
                + "pSerial integer," + "pAtomName varchar(4), pType varchar(2)," + "nChainID varchar(3), nResName varchar(5),"
                + "nResSeq integer," + "nSerial integer," + "nAtomName varchar(4), nType varchar(2)," 
                + "D_A_Distance number,A_H_Distance number," + "D_H_A_Angle number)";
            System.out.println("blah");
            System.out.println(createHydrogenBondsInteractionTableStatement);
            statement.execute(createHydrogenBondsInteractionTableStatement);
        }
        catch(SQLException sqlExc)
        {
            sqlExc.printStackTrace();
        }
             
                
		try
		{
			String createStackingInteractionTableStatement = "create table " + PNDatabaseMaker.STACKING_INTERACTIONS_TABLE +
				" (pdbID varchar(20), pChainID varchar(3)," + "pResName varchar(5), pResSeq integer," 
				+ "nChainID varchar(3), nResName varchar(5)," + "nResSeq integer, dihedralAngle number," 
				+ "centerToCenterDistance number," + "degreeOfStaggeredness number)";
            System.out.println(createStackingInteractionTableStatement);
			statement.execute(createStackingInteractionTableStatement);
		}
		catch(SQLException sqlExc)
		{
			System.out.println(sqlExc);
		}


		try
		{
			String createElectrostaticInteractionsTableStatement = "create table " + PNDatabaseMaker.ELECTROSTATIC_INTERACTIONS_TABLE 
				+ "(pdbID varchar(20),pChainID varchar(3)," + "pResName varchar(5), pResSeq integer,pSerial integer,"
				+ "pAtomName varchar(4),pType varchar(2),nChainID varchar(3)," + "nResName varchar(5), nResSeq integer,nSerial integer,"
				+ "nAtomName varchar(4), nType varchar(2),distance number)";
            System.out.println(createElectrostaticInteractionsTableStatement);
			statement.execute(createElectrostaticInteractionsTableStatement);
		}
		catch(SQLException sqlExc2)
		{
			System.out.println(sqlExc2);
		}
		
		
		File documentsDirectory = new File(System.getProperty("user.dir") + File.separator + "interactionsDocuments");
		File[] interactionDocumentFiles = documentsDirectory.listFiles(new XMLFileFilter());
		
		try
		{
			for(int i =0;i<interactionDocumentFiles.length;i++)
			{
                System.out.println("Parsing " + interactionDocumentFiles[i]);
				Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(interactionDocumentFiles[i]);
                
                System.out.println("Inserting hydrogen bonds");
				maker.insertHydrogenBonds(document);
                
                System.out.println("Inserting electrostatic interactions");
				maker.insertElectrostaticInteractions(document);
                
                System.out.println("Inserting stacking interactions");
				maker.insertStackingInteractions(document);
                
                System.out.println("Done with " + interactionDocumentFiles[i]);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace(System.out);
		}
	}
	
	
	
	/** Sets the database connection that 
	  * PNDatabaseMaker has execute SQL statements */
	public void setConnection(Connection con)
	{
		dbConnection = con;
	}
	
	
	
	public void insertElectrostaticInteractions(Document interactionsDocument) throws DOMException
	{
		Element root = interactionsDocument.getDocumentElement();
		Element pdbIDElement = (Element)root.getElementsByTagName("pdbID").item(0);
		String pdbID = pdbIDElement.getFirstChild().getNodeValue(); 
		Element macromoleculeAElement = (Element)root.getElementsByTagName("macromoleculeA").item(0);
		String macromoleculeAChainID = macromoleculeAElement.getAttribute("chainID");
		String macromoleculeAType = macromoleculeAElement.getAttribute("macromoleculeType");
		Element macromoleculeBElement = (Element)root.getElementsByTagName("macromoleculeB").item(0);
		String macromoleculeBChainID = macromoleculeBElement.getAttribute("chainID");
		String macromoleculeBType = macromoleculeBElement.getAttribute("macromoleculeType");
		Element electrostaticInteractionsElement = (Element)root.getElementsByTagName("electrostaticInteractions").item(0);
		NodeList electrostaticInteractionElements = electrostaticInteractionsElement.getElementsByTagName("electrostaticInteraction");
		Statement statement = null;
		
		
		try
		{
			statement = dbConnection.createStatement();
		}
		catch(SQLException exc)
		{
			exc.printStackTrace(System.out);
		}
		
		
		for(int i=0;i<electrostaticInteractionElements.getLength();i++)
		{
			Element electrostaticInteractionElement = (Element)electrostaticInteractionElements.item(i);
			
			Element positiveElement = (Element)((Element)electrostaticInteractionElement.getElementsByTagName("positive").
					item(0)).getElementsByTagName("atom").item(0);
			
			Element negativeElement = (Element)((Element)electrostaticInteractionElement.getElementsByTagName("negative").
					item(0)).getElementsByTagName("atom").item(0);
			
			String positiveChainID = positiveElement.getAttribute("chainID");
			String negativeChainID = negativeElement.getAttribute("chainID");
			String pChainID ="";
			String pResName = "";
			String pResSeq = "";
			String pSerial = ""; 
			String pAtomName = ""; 
			String pType = "";
			String nChainID = "";
			String nResName = "";
			String nResSeq = "";
			String nSerial = "";
			String nAtomName= "";
			String nType = "";
			
			
			// assume macromolecule A is the protein
			if(positiveChainID.equals(macromoleculeAChainID))
			{
				pChainID = positiveChainID;
				pResName = positiveElement.getAttribute("resName");
				pResSeq = positiveElement.getAttribute("resSeq");
				pSerial = positiveElement.getAttribute("serial");
				pAtomName = positiveElement.getFirstChild().getNodeValue();
				pType = "D";
				
				nChainID = negativeChainID;
				nResName = negativeElement.getAttribute("resName");
				nResSeq = negativeElement.getAttribute("resSeq");
				nSerial = negativeElement.getAttribute("serial");
				nAtomName = negativeElement.getFirstChild().getNodeValue();
				nType = "A";
			}
			else
			{
				pChainID = negativeChainID;
				pResName = negativeElement.getAttribute("resName");
				pResSeq = negativeElement.getAttribute("resSeq");
				pSerial = negativeElement.getAttribute("serial");
				pAtomName = negativeElement.getFirstChild().getNodeValue();
				pType = "A";
				
				nChainID = positiveChainID;
				nResName = positiveElement.getAttribute("resName");
				nResSeq = positiveElement.getAttribute("resSeq");
				nSerial = positiveElement.getAttribute("serial");
				nAtomName = positiveElement.getFirstChild().getNodeValue();
				nType = "D";
			}
			
			
			//pdbID, pChainID,pResName, pResSeq,pSerial,pAtomName,pType,
			//nChainID,nResName, nResSeq,nSerial,nAtomName, nType,
			//D_A_Distance,A_H_Distance, D_H_A_Angle
			String distance = electrostaticInteractionElement.getAttribute("distance");
			String sqlString = "insert into " + ELECTROSTATIC_INTERACTIONS_TABLE 
				+ "(pdbID,pChainID,pResName,pResSeq,pSerial,pAtomName,pType," 
				+ "nChainID,nResName,nResSeq,nSerial,nAtomName,nType," + "distance)" + "values (" + "'" + pdbID + "'," 
				+ "'" + pChainID + "'," + "'" + pResName + "'," + pResSeq + "," + pSerial + "," + "'" + pAtomName + "'," 
				+ "'" + pType + "',"+ "'" + nChainID + "'," + "'" + nResName + "'," + nResSeq + "," + nSerial + ","
				+ "'" + nAtomName + "'," + "'" + nType + "'," + distance +")";
			try
			{
				statement.execute(sqlString);
			}
			catch(SQLException e2)
			{
				e2.printStackTrace(System.out);
                i--;
                
                try
                {
                    statement = dbConnection.createStatement();
                }
                catch(SQLException e3)
                {
                    e3.printStackTrace();
                }
			}
		}
	}
		
		
		
	public void insertStackingInteractions(Document interactionsDocument) throws DOMException
	{
		Element root = interactionsDocument.getDocumentElement();
		Element pdbIDElement = (Element)root.getElementsByTagName("pdbID").item(0);
		String pdbID = pdbIDElement.getFirstChild().getNodeValue(); 
		Element macromoleculeAElement = (Element)root.getElementsByTagName("macromoleculeA").item(0);
		String macromoleculeAChainID = macromoleculeAElement.getAttribute("chainID");
		String macromoleculeAType = macromoleculeAElement.getAttribute("macromoleculeType");
		Element macromoleculeBElement = (Element)root.getElementsByTagName("macromoleculeB").item(0);
		String macromoleculeBChainID = macromoleculeBElement.getAttribute("chainID");
		String macromoleculeBType = macromoleculeBElement.getAttribute("macromoleculeType");
		Element stackingInteractionsElement = (Element)root.getElementsByTagName("stackingInteractions").item(0);
		NodeList stackingInteractionElements = stackingInteractionsElement.getElementsByTagName("stackingInteraction");
		Statement statement = null;
		
		
		try
		{
			statement = dbConnection.createStatement();
		}
		catch(SQLException exc)
		{
			exc.printStackTrace(System.out);
		}
		
		
		for(int i=0;i<stackingInteractionElements.getLength();i++)
		{
			Element stackingInteractionElement = (Element)stackingInteractionElements.item(i);
			Element residueAElement = (Element)((Element)stackingInteractionElement.getElementsByTagName("residue").item(0));
			Element residueBElement = (Element)((Element)stackingInteractionElement.getElementsByTagName("residue").item(1));
			
			String centerToCenterDistance = stackingInteractionElement.getAttribute("centerToCenterDistance");
			String degreeOfStaggeredness = stackingInteractionElement.getAttribute("degreeOfStaggeredness");
			String dihedralAngle = stackingInteractionElement.getAttribute("dihedralAngle");
			String residueAChainID = residueAElement.getAttribute("chainID");
			String residueBChainID = residueBElement.getAttribute("chainID");
			String pChainID ="";
			String pResName = "";
			String pResSeq = "";
			String nChainID = "";
			String nResName = "";
			String nResSeq = "";
			
			
			// assume macromolecule A is the protein
			if(residueAChainID.equals(macromoleculeAChainID))
			{
				pChainID = residueAChainID;
				pResName = residueAElement.getFirstChild().getNodeValue();
				pResSeq = residueAElement.getAttribute("resSeq");
				nChainID = residueBChainID;
				nResName = residueBElement.getFirstChild().getNodeValue();
				nResSeq = residueBElement.getAttribute("resSeq");
			}
			else
			{
				pChainID = residueBChainID;
				pResName = residueBElement.getFirstChild().getNodeValue();
				pResSeq = residueBElement.getAttribute("resSeq");
				nChainID = residueAChainID;
				nResName = residueAElement.getFirstChild().getNodeValue();
				nResSeq = residueAElement.getAttribute("resSeq");
			}
			
			
			String sqlString = "insert into " + STACKING_INTERACTIONS_TABLE + "(pdbID,pChainID,pResName,pResSeq," 
				+ "nChainID,nResName,nResSeq," + "dihedralAngle,centerToCenterDistance,degreeOfStaggeredness)" 
				+ "values (" + "'" + pdbID + "'," + "'" + pChainID + "'," + "'" + pResName + "'," + pResSeq + "," 
				+ "'" + nChainID + "'," + "'" + nResName + "'," + nResSeq + "," + dihedralAngle + "," 
				+ centerToCenterDistance + "," + degreeOfStaggeredness + ")";
			
			try
			{
				statement.execute(sqlString);
			}
			catch(SQLException e2)
			{
				e2.printStackTrace(System.out);
			}
		}
	}
	
	
	
	/**
	 *  create table hydrogenBondsTable (pdbID varchar(20),pChainID varchar(3),
	 *	pResName varchar(5), pResSeq integer,pSerial integer,
	 *       pAtomName varchar(4),pType varchar(2),nChainID varchar(3),
	 *       nResName varchar(5), nResSeq integer,nSerial integer,
	 * 	nAtomName varchar(4), nType varchar(2),D_A_Distance number,
	 *       A_H_Distance number, D_H_A_Angle number)
	 * for now assume that macromolecule A is the protein and the macromolecule B 
	 * is the nucleic acid
	 */
	public void insertHydrogenBonds(Document interactionsDocument) throws DOMException
	{
		Element root = interactionsDocument.getDocumentElement();
		Element pdbIDElement = (Element)root.getElementsByTagName("pdbID").item(0);
		String pdbID = pdbIDElement.getFirstChild().getNodeValue(); 
		Element macromoleculeAElement = (Element)root.getElementsByTagName("macromoleculeA").item(0);
		String macromoleculeAChainID = macromoleculeAElement.getAttribute("chainID");
		String macromoleculeAType = macromoleculeAElement.getAttribute("macromoleculeType");
		Element macromoleculeBElement = (Element)root.getElementsByTagName("macromoleculeB").item(0);
		String macromoleculeBChainID = macromoleculeBElement.getAttribute("chainID");
		String macromoleculeBType = macromoleculeBElement.getAttribute("macromoleculeType");
		Element hydrogenBondsElement = (Element)root.getElementsByTagName("hydrogenBonds").item(0);
		NodeList hydrogenBondElements = hydrogenBondsElement.getElementsByTagName("hydrogenBond");
		Statement statement = null;
		
		
		try
		{
			statement = dbConnection.createStatement();
		}
		catch(SQLException exc)
		{
			exc.printStackTrace(System.out);
		}
		
		
		for(int i=0;i<hydrogenBondElements.getLength();i++)
		{
			Element hydrogenBondElement = (Element)hydrogenBondElements.item(i);
			Element donorElement = (Element)((Element)hydrogenBondElement.getElementsByTagName("donor").
					item(0)).getElementsByTagName("atom").item(0);
			Element acceptorElement = (Element)((Element)hydrogenBondElement.getElementsByTagName("acceptor").
					item(0)).getElementsByTagName("atom").item(0);
					
			String donorChainID = donorElement.getAttribute("chainID");
			String acceptorChainID = acceptorElement.getAttribute("chainID");
			String pChainID ="";
			String pResName = "";
			String pResSeq = "";
			String pSerial = ""; 
			String pAtomName = ""; 
			String pType = "";
			String nChainID = "";
			String nResName = "";
			String nResSeq = "";
			String nSerial = "";
			String nAtomName= "";
			String nType = "";
			
			
			// assume macromolecule A is the protein
			if(donorChainID.equals(macromoleculeAChainID))
			{
				pChainID = donorChainID;
				pResName = donorElement.getAttribute("resName");
				pResSeq = donorElement.getAttribute("resSeq");
				pSerial = donorElement.getAttribute("serial");
				pAtomName = donorElement.getFirstChild().getNodeValue();
				pType = "D";
				
				nChainID = acceptorChainID;
				nResName = acceptorElement.getAttribute("resName");
				nResSeq = acceptorElement.getAttribute("resSeq");
				nSerial = acceptorElement.getAttribute("serial");
				nAtomName = acceptorElement.getFirstChild().getNodeValue();
				nType = "A";
			}
			else
			{
				pChainID = acceptorChainID;
				pResName = acceptorElement.getAttribute("resName");
				pResSeq = acceptorElement.getAttribute("resSeq");
				pSerial = acceptorElement.getAttribute("serial");
				pAtomName = acceptorElement.getFirstChild().getNodeValue();
				pType = "A";
				
				nChainID = donorChainID;
				nResName = donorElement.getAttribute("resName");
				nResSeq = donorElement.getAttribute("resSeq");
				nSerial = donorElement.getAttribute("serial");
				nAtomName = donorElement.getFirstChild().getNodeValue();
				nType = "D";
			}
			
			
			
			//pdbID, pChainID,pResName, pResSeq,pSerial,pAtomName,pType,
			//nChainID,nResName, nResSeq,nSerial,nAtomName, nType,
			//D_A_Distance,A_H_Distance, D_H_A_Angle
			String donorAcceptorDistance = hydrogenBondElement.getAttribute("donorToAcceptorDistance");
			String hydrogenAcceptorDistance = hydrogenBondElement.getAttribute("hydrogenToAcceptorDistance");
			String D_H_A_Angle = hydrogenBondElement.getAttribute("D_H_A_Angle");
			String sqlString = "insert into " + HYDROGEN_BONDS_TABLE + "(pdbID,pChainID,pResName,pResSeq,pSerial,pAtomName,pType," 
				+ "nChainID,nResName,nResSeq,nSerial,nAtomName,nType," + "D_A_Distance,A_H_Distance,D_H_A_Angle)" + "values (" 
				+ "'" + pdbID + "'," + "'" + pChainID + "'," + "'" + pResName + "'," + pResSeq + "," + pSerial + "," 
				+ "'" + pAtomName + "'," + "'" + pType + "'," + "'" + nChainID + "'," + "'" + nResName + "'," + nResSeq + ","
				+ nSerial + "," + "'" + nAtomName + "'," + "'" + nType + "'," + donorAcceptorDistance + ","
				+ hydrogenAcceptorDistance + "," + D_H_A_Angle +")";
			
			try
			{
				statement.execute(sqlString);
			}
			catch(SQLException e2)
			{
				e2.printStackTrace(System.out);
			}
		}
	}
}