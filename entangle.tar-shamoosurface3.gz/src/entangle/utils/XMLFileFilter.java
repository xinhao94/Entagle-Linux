/*
 * XMLFileFilter.java
 *
 * Created on May 15, 2001, 7:13 AM
 */

package entangle.utils;


/**
 * Simple <CODE>FileFilter</CODE> for filtering out files that have the extension
 * .xml
 * @author  Jim Allers
 * @version 1.0
 */
public class XMLFileFilter implements java.io.FileFilter 
{
    public boolean accept(java.io.File file) 
    {
        boolean canAccept = false;
        
        if (file.getName().lastIndexOf(".xml") == (file.getName().length() - 4)) 
        {
            canAccept = true;
        }
        
        return canAccept;
    }
    
}
