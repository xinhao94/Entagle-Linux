/*
 * SchematicPane.java
 *
 * Created on November 19, 2000, 1:33 AM
 */

package entangle.schematic;

import java.util.Vector;

import javax.swing.JLayeredPane;
import javax.swing.JPanel;

import entangle.classification.NBInteractionContainer;
import entangle.datastructures.Macromolecule;


/**
 * SchematicPane provides an interactive,two-dimensional schematis of the
 * interface between a protein and a nucleic acid. Currently, I'm debating whether
 * this class will manage a model of the relationship between the residues and
 * choose to render this relationship, or if it will  
 * @author  Jim Allers
 * @version 
 */
public class SchematicPane extends JLayeredPane 
{
	Macromolecule nucleicAcid;
	Macromolecule protein;
	NBInteractionContainer interactionContainer;
	JPanel backgroundPane;
	Vector schematicModelListeners;
	
	
    /** Creates new SchematicPane */
    public SchematicPane(Macromolecule nucleicAcid, Macromolecule protein, NBInteractionContainer interactionContainer)
    {
		this.nucleicAcid = nucleicAcid;
		this.protein = protein;
		this.interactionContainer = interactionContainer;
	}
}