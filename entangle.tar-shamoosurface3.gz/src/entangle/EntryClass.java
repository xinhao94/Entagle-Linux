/*
 * ENTANGLE PROGRAM MAIN ENTRY CLASS
 */
 
package entangle;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;

import entangle.gui.Analyzer;

/**
 * The entry class for the entangle package. 
 */
 
public class EntryClass extends JFrame
{
	Analyzer entangleMain;
	
    /**
     * Constructor.  
     */
    public EntryClass(String title, Analyzer aAnalyzer)
    {
    	entangleMain = aAnalyzer;
    	
		
		setTitle(title);  				// from java.awt.Frame
		
		JPanel panel = new JPanel();
		setContentPane(panel);
		
		
		ImageIcon icon = new ImageIcon(System.getProperty("user.dir") + File.separator + "images" + File.separator + "entangle_startup.jpg");
		JButton button = new JButton(icon);
		button.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					mouseClick();
				}
			});

		panel.add(button);
		
		
		addWindowListener(new WindowAdapter()
            {
                public void windowClosing(WindowEvent e)
                {
                    mouseClick();
                }
            });
    }
    
    
    private void mouseClick()
    {
    	setVisible(false);
    	
    	entangleMain.setVisible(true);
    }
    
    
    public static void main(String[] args) throws IOException
    {
        try
        {
            try 
            {
				UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
                //UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
				//UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } 
            catch (Exception ex) 
            {
                System.out.println("Failed loading Metal");
                System.out.println(ex);
            }
            
            
            Analyzer theAnalyzer = new Analyzer("ENTANGLE");
                    
            /**
             * Causes this Window to be sized to fit the preferred size and layouts of its 
             * subcomponents. If the window and/or its owner are not yet displayable, both 
             * are made displayable before calculating the preferred size. The Window will 
             * be validated after the preferredSize is calculated.
             *
             * Method inherited from java.awt.Window
             */
            theAnalyzer.pack();
                    
            theAnalyzer.setVisible(false);  //Inherited from java.awt.Component
                    
            /**
             * Adds the specified window listener to receive window events from this window. 
             * If input is null, no exception is thrown and no action is performed.
             *
             * Inherited from java.awt.Window
             */
            theAnalyzer.addWindowListener(new WindowAdapter()
            {
                public void windowClosing(WindowEvent e)
                {
                    System.exit(0);
                }
            });
            
            
            EntryClass theEntryClass = new EntryClass("Click to Continue", theAnalyzer);
            
            theEntryClass.pack();
            
            theEntryClass.setVisible(true);
            
        }
        catch(Exception e)
        {
           e.printStackTrace(System.out);
        }
    }
}

