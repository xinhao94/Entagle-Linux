/*
 * Created on Jun 5, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package entangle;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import entangle.classification.InteractingGroup;
import entangle.classification.NBInteractionClassifier;
import entangle.classification.NBInteractionContainer;
import entangle.classification.SimpleInteractingGroup;
import entangle.classification.cationpi.SimpleCPInteraction;
import entangle.classification.stacking.SimpleSInteraction;
import entangle.datastructures.Atom;
import entangle.datastructures.BaseInteractions;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.PDBInformation;
import entangle.datastructures.PDBModel;
import entangle.datastructures.Residue;
import entangle.datastructures.ResidueStructure;
import entangle.datastructures.SimpleAtom;
import entangle.datastructures.SimplePResidue;
import entangle.utils.io.AtomRecord;
import entangle.utils.io.PDBGetter;
import entangle.utils.io.PDBParser;
import entangle.utils.io.ResidueLibraryParser;
import entangle.utils.math.XYZMatrix;

/**
 * @author unknown
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class GeneralizedBaseInteractionProcessor {

    public static InputStream getPDBInputStream(String pdbID) {
        try {
	    File pdbDir = new File(System.getProperty("user.dir")
				   + File.separator
				   + "pdb");
	    if(!pdbDir.exists()){
		pdbDir.mkdir();
	    }
            FileInputStream inputStream =
                new FileInputStream(
                    new File(System.getProperty("user.dir"))
                        + File.separator
                        + "pdb"
                        + File.separator
                        + pdbID
                        + ".pdb");
            return inputStream;
        } catch (FileNotFoundException fnfe) {
            System.out.println("Could not find PDB in directory");
            try {
                System.out.println("trying to get " + pdbID + "from pdb.org");
                PDBGetter pdbGetter = new PDBGetter(pdbID);
                // writing pdb from pdb.org to file.
                byte[] buf = new byte[1024 * 32];
                InputStream stream = pdbGetter.openPDBStream();
                File newPDBFile =
                    new File(
                        System.getProperty("user.dir"),
                        "pdb" + File.separator + pdbID + ".pdb");
                newPDBFile.createNewFile();
                OutputStream outputStream =
                    new FileOutputStream(
                        new File(
                            System.getProperty("user.dir"),
                            "pdb" + File.separator + pdbID + ".pdb"));
                int bytesRead = 0;
                while ((bytesRead = stream.read(buf)) != -1) {
                    outputStream.write(buf, 0, bytesRead);
                }
                outputStream.close();
                stream.close();
                return new FileInputStream(newPDBFile);
            } catch (IOException ioe) {
                System.out.println("Could not get " + pdbID + " from pdb.org");
                return null;
            }
        }

    }

    public static void main(String[] args) throws IOException {
        BaseInteractions aInteractions = new BaseInteractions("A");
        BaseInteractions gInteractions = new BaseInteractions("G");
        BaseInteractions cInteractions = new BaseInteractions("C");
        BaseInteractions tInteractions = new BaseInteractions("T");
        BaseInteractions uInteractions = new BaseInteractions("U");

        // go through the list of arguments 
        // each of the arguments is expected to be a file
        // that lists a bunch of pdb IDs
        for (int i = 0; i < args.length; i++) {
            File pdbIDFile = new File(args[i]);
            BufferedReader br = new BufferedReader(new FileReader(pdbIDFile));
            
            String pdbProcessingInstruction = null;
            while ((pdbProcessingInstruction = br.readLine()) != null) {
                String pdbID = null;
                String[] chainIDs = null;
            
                String[] tokens = pdbProcessingInstruction.split("[, ]");
                pdbID = tokens[0];
            
                if(tokens.length > 1){
                    chainIDs = new String[tokens.length-1];
                    System.arraycopy(tokens,1,chainIDs,0,chainIDs.length);
                }
                addInteractionsFromPDB(
                    aInteractions,
                    gInteractions,
                    cInteractions,
                    tInteractions,
                    uInteractions,
                    pdbID,
                    chainIDs);
            }
        }

        // let's output the cation pi interactions but output them as a
        // a PDB file.
        BaseInteractions baseInteractions = aInteractions;

        outputCationPiInteractions("a_cpinteractions.pdb", baseInteractions);
        outputCationPiInteractions("g_cpinteractions.pdb", gInteractions);
        outputCationPiInteractions("c_cpinteractions.pdb", cInteractions);
        outputCationPiInteractions("t_cpinteractions.pdb", tInteractions);
        outputCationPiInteractions("u_cpInteractions.pdb", uInteractions);

        outputStackingRibbonsModels("a", aInteractions);
        outputStackingRibbonsModels("g", gInteractions);
        outputStackingRibbonsModels("c", cInteractions);
        outputStackingRibbonsModels("t", tInteractions);
        outputStackingRibbonsModels("u", uInteractions);
    }

    private static void outputCationPiInteractions(
        String fileName,
        BaseInteractions baseInteractions)
        throws IOException {
        File outputFile = new File(fileName);
        outputFile.createNewFile();
        PrintWriter pw = new PrintWriter(new FileWriter(outputFile));

        int atomNumber = 1;
        int residueNumber = 0;
        String lastResidue = "";
        for (Iterator iter = baseInteractions.CPinter.iterator();
            iter.hasNext();
            ) {
            SimpleCPInteraction cpInteraction =
                (SimpleCPInteraction) iter.next();
            SimpleAtom atom = (SimpleAtom) cpInteraction.getCation();
            if (!lastResidue.equals("") && !lastResidue.equals(atom.resName)) {
                residueNumber++;
            }
            AtomRecord atomRecord =
                new AtomRecord(
                    atom.name,
                    atom.atomType,
                    atomNumber,
                    atom.resName,
                    atom.chainID.charAt(0),
                    residueNumber,
                    atom.x,
                    atom.y,
                    atom.z);
            lastResidue = atom.resName;
            atomNumber++;
            pw.println(atomRecord.generatePDBString());
        }
        pw.close();
    }

    private static ResidueLibraryParser libraryParser =
        new ResidueLibraryParser(
            new File("data/residueDefinitions/residues"),
            new File("data/residueDefinitions/atomTypes"));

    /**
     * The list of residues structures keyed by their residue name
     */
    private static Hashtable residueStructures =
        libraryParser.getResidueStructures();

    private static String[] RESIDUE_MAIN_CHAIN_ATOMS =
        new String[] { "N", "H", "CA", "1HA", "2HA", "C", "O" };
        
        
    /**
     * Makes a simple cylinder file
     * the format for the sph file is very simple the 6th field is optional
     * i don't know the naming scheme exactly and haven't figured it out
     * completely.
     * 
     * @author Jim Allers
     *
     */
    private static class RibbonsSphereCreator{
        public String getRnaResidueName() {
            return rnaResidueName;
        }
        public String getProteinResidueName() {
            return proteinResidueName;
        }
        
        private String rnaResidueName;
        private String proteinResidueName;
        private PrintWriter pw;
        
        public RibbonsSphereCreator(
            String rnaResidueName,
            String proteinResidueName)
            throws IOException {
            this.rnaResidueName = rnaResidueName;
            this.proteinResidueName = proteinResidueName;
            File interactionsFile =
                new File(
                    rnaResidueName
                        + "-"
                        + proteinResidueName
                        + "-stacking-interactions.sph");
            interactionsFile.createNewFile();
            pw = new PrintWriter(new FileWriter(interactionsFile));
        }
        // x  y  z  radius  colorindex  name        
        private static MessageFormat format =
            new MessageFormat("{6} " +
                              "{7} " +
                              "{8} " +
                              "{0,number,###.###;-###.###} " +                              "{1,number,###.###;-###.###} " +                              "{2,number,###.###;-###.###} " +                              "{3,number,###.###;-###.###} " +                              "{4,number} " +                              "{5}");            
        public void addResidue(SimplePResidue simplePResidue){
            // just print the spheres for this protein residue
            for (Enumeration iter = simplePResidue.atoms.elements();
                iter.hasMoreElements();
                ) {
                SimpleAtom simpleAtom = (SimpleAtom) iter.nextElement();

                if (!Arrays
                    .asList(RESIDUE_MAIN_CHAIN_ATOMS)
                    .contains(simpleAtom.name)) {
                    pw.println(
                        format.format(
                            new Object[] {
                                new Double(simpleAtom.x),
                                new Double(simpleAtom.y),
                                new Double(simpleAtom.z),
                                new Double(1.60),
                                new Integer(1),
                                simpleAtom.name.toLowerCase(),
                                new Integer(simpleAtom.resSeq),
                                simpleAtom.chainID,
                                simpleAtom.pdbName}));
                    pw.flush();
                }
            }
        }
        
        public void close(){
            pw.close();
        }
    }
    
    
    /**
     * Makes a simple cylinder file
     * the format for the sph file is very simple the 6th field is optional
     * i don't know the naming scheme exactly and haven't figured it out
     * completely.
     * 
     * @author Jim Allers
     *
     */
    private static class PDBCreator{
        public String getRnaResidueName() {
            return rnaResidueName;
        }
        public String getProteinResidueName() {
            return proteinResidueName;
        }
        
        private String rnaResidueName;
        private String proteinResidueName;
        private PrintWriter pw;
        
        public PDBCreator(
            String rnaResidueName,
            String proteinResidueName)
            throws IOException {
            this.rnaResidueName = rnaResidueName;
            this.proteinResidueName = proteinResidueName;
            File interactionsFile =
                new File(
                    rnaResidueName
                        + "-"
                        + proteinResidueName
                        + "-stacking-interactions.pdb");
            interactionsFile.createNewFile();
            pw = new PrintWriter(new FileWriter(interactionsFile));
        }
            
        public void addResidue(SimplePResidue simplePResidue){
            // just print the spheres for this protein residue
            for (Enumeration iter = simplePResidue.atoms.elements();
                iter.hasMoreElements();
                ) {
                SimpleAtom simpleAtom = (SimpleAtom) iter.nextElement();
                int i = 0;
                if (!Arrays
                    .asList(RESIDUE_MAIN_CHAIN_ATOMS)
                    .contains(simpleAtom.name)) {
                    AtomRecord atomRecord =
                        new AtomRecord(
                            simpleAtom.name,
                            simpleAtom.atomType,
                            ++i,
                            simpleAtom.resName,
                            simpleAtom.chainID.charAt(0),
                            simpleAtom.resSeq,
                            simpleAtom.x,
                            simpleAtom.y,
                            simpleAtom.z);
                    pw.println(atomRecord.generatePDBString());
                    pw.flush();
                }
            }
        }
        
        public void close(){
            pw.close();
        }
    }
    
    /**
     * Makes a simple cylinder file
     * the format for the cylinder file is very simple
     * the ninth field is optional
     * radius = .16 is a pretty good radius for the cylinder
     * x1 y1 z1  x2 y2 z2  radius  colorindex  name
     */
    private static class RibbonsCylinderCreator {
        private String rnaResidueName;
        private String proteinResidueName;
        private PrintWriter pw;

        public RibbonsCylinderCreator(
            String rnaResidueName,
            String proteinResidueName)
            throws IOException {
            this.rnaResidueName = rnaResidueName;
            this.proteinResidueName = proteinResidueName;
            File interactionsFile =
                new File(
                    rnaResidueName
                        + "-"
                        + proteinResidueName
                        + "-stacking-interactions.cyl");
            interactionsFile.createNewFile();
            pw = new PrintWriter(new FileWriter(interactionsFile));
        }

        public void addResidue(SimplePResidue simplePResidue) {
            // just print the cylinders for this protein residue
            ResidueStructure residueStructure =
                (ResidueStructure) residueStructures.get(
                    simplePResidue.resName);
            // set of atoms that have already been handled
            HashSet handledAtoms = new HashSet();

            // get the starting atom (any atom should do)
            SimpleAtom simpleAtom =
                (SimpleAtom) simplePResidue.atoms.elements().nextElement();

            writeBonds(
                handledAtoms,
                residueStructure,
                simplePResidue,
                simpleAtom);
        }

        private static MessageFormat format =
            new MessageFormat("{8} {9} {10} {0,number,###.###;-###.###} {1,number,###.###;-###.###} {2,number,###.###;-###.###} {3,number,###.###;-###.###} {4,number,###.###;-###.###} {5,number,###.###;-###.###} {6,number,###.###;-###.###} {7,number,###.###;-###.###}");

        private void writeBonds(
            HashSet handledAtoms,
            ResidueStructure residueStructure,
            SimplePResidue simplePResidue,
            SimpleAtom simpleAtom) {

            handledAtoms.add(simpleAtom.name);

            Vector bondedAtomNames =
                residueStructure.getBondedAtomNames(simpleAtom.name);

            for (Iterator iter = bondedAtomNames.iterator(); iter.hasNext();) {
                String nextAtomName = (String) iter.next();
                SimpleAtom nextAtom =
                    (SimpleAtom) simplePResidue.atoms.get(nextAtomName);

                // if the next atom exists and has not been written yet
                // recurse
                if (nextAtom != null
                    && !handledAtoms.contains(nextAtom.name)) {

                    // do not write the bond out if the atoms are part of 
                    // the main chain
                    if (!Arrays
                        .asList(RESIDUE_MAIN_CHAIN_ATOMS)
                        .contains(nextAtom.name)
                        && !Arrays.asList(RESIDUE_MAIN_CHAIN_ATOMS).contains(
                            simpleAtom.name)) {
                        // write out the bond
                        // x1 y1 z1  x2 y2 z2  radius  colorindex  name
                        pw.println(
                            format.format(
                                new Object[] {
                                    new Double(simpleAtom.x),
                                    new Double(simpleAtom.y),
                                    new Double(simpleAtom.z),
                                    new Double(nextAtom.x),
                                    new Double(nextAtom.y),
                                    new Double(nextAtom.z),
                                    new Double(0.16),
                                    new Integer(1),
                                    new Integer(simpleAtom.resSeq),
                                    simpleAtom.chainID,
                                    simpleAtom.pdbName}));
                        pw.flush();

                    }
                }

		
	    }
	    for (Iterator iter = bondedAtomNames.iterator(); iter.hasNext();) {
                String nextAtomName = (String) iter.next();
                SimpleAtom nextAtom =
                    (SimpleAtom) simplePResidue.atoms.get(nextAtomName);

                // if the next atom exists and has not been written yet
                // recurse
                if (nextAtom != null
                    && !handledAtoms.contains(nextAtom.name)) {

                    writeBonds(
                        handledAtoms,
                        residueStructure,
                        simplePResidue,
                        nextAtom);
                }
	    }
	    
        }

        public String getRnaResidueName() {
            return rnaResidueName;
        }

        public String getProteinResidueName() {
            return proteinResidueName;
        }

        public void close() {
            pw.close();
        }
    }

    // outputs a ribbons cylinder file which can be used to display the 
    // distribution of stacking protein residues
    private static void outputStackingRibbonsModels(
        String residueName,
        BaseInteractions baseInteractions) {

        // go through the list of stacking interactions
        // create an array list of protein residue names
        // keep track of which protein residues have a cylinder file
        // created
        ArrayList ribbonsCylinderCreators = new ArrayList();
        ArrayList ribbonsSphereCreators = new ArrayList();
        ArrayList pdbCreators = new ArrayList();
        
        Iterator sInterIter = baseInteractions.Sinter.iterator();
        while (sInterIter.hasNext()) {
            SimpleSInteraction sInteraction =
                (SimpleSInteraction) sInterIter.next();
            // check to see if a ribbonsCylinderCreator has already been 
            // created for this protein residue
            RibbonsCylinderCreator rcc = null;
            try {
                rcc =
                    getRibbonsCylinderCreator(
                        sInteraction,
                        ribbonsCylinderCreators);
                rcc.addResidue(sInteraction.rB);
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            RibbonsSphereCreator rsc = null;
            try{
                rsc = getRibbonsSphereCreator(sInteraction,ribbonsSphereCreators);
                rsc.addResidue(sInteraction.rB);
            }catch(IOException e){
                e.printStackTrace();
            }
            
            PDBCreator creator = null;
            try{
                creator = getPDBCreator(sInteraction,pdbCreators);
                creator.addResidue(sInteraction.rB);
            }catch(IOException e){
                e.printStackTrace();
            }
        }

        // close the RibbonsCylinderCreators
        for (Iterator rccIter = ribbonsCylinderCreators.iterator();
            rccIter.hasNext();
            ) {
            RibbonsCylinderCreator rcc =
                (RibbonsCylinderCreator) rccIter.next();
            rcc.close();
        }
        
        // close the RibbonsCylinderCreators
        for (Iterator rscIter = ribbonsSphereCreators.iterator();
                rscIter.hasNext();
            ) {
            RibbonsSphereCreator rsc =
                (RibbonsSphereCreator) rscIter.next();
            rsc.close();
        }
        
        // close the PDBCreators
        for (Iterator pdbIter = pdbCreators.iterator();
                pdbIter.hasNext();
            ) {
            PDBCreator pdb =
                (PDBCreator) pdbIter.next();
            pdb.close();
        }
        
    }
    
    private static RibbonsSphereCreator getRibbonsSphereCreator(
        SimpleSInteraction sInteraction,
        ArrayList ribbonsSphereCreators)
        throws IOException {
        RibbonsSphereCreator creator = null;
        Iterator rscIter = ribbonsSphereCreators.iterator();
        while (rscIter.hasNext() && creator == null) {
            creator = (RibbonsSphereCreator) rscIter.next();
            if (!creator
                .getProteinResidueName()
                .equals(sInteraction.rB.resName)) {
                creator = null;
            } else {
                break;
            }
        }

        if (creator == null) {
            creator =
                new RibbonsSphereCreator(
                    sInteraction.rA.resName,
                    sInteraction.rB.resName);
            ribbonsSphereCreators.add(creator);
        }
        return creator;
        
    }

    private static PDBCreator getPDBCreator(
        SimpleSInteraction sInteraction,
        ArrayList pdbCreators)
        throws IOException {
        PDBCreator creator = null;
        Iterator rscIter = pdbCreators.iterator();
        while (rscIter.hasNext() && creator == null) {
            creator = (PDBCreator) rscIter.next();
            if (!creator
                .getProteinResidueName()
                .equals(sInteraction.rB.resName)) {
                creator = null;
            } else {
                break;
            }
        }
    
        if (creator == null) {
            creator =
                new PDBCreator(
                    sInteraction.rA.resName,
                    sInteraction.rB.resName);
            pdbCreators.add(creator);
        }
        return creator;
        
    }
    
    private static RibbonsCylinderCreator getRibbonsCylinderCreator(
        SimpleSInteraction sInteraction,
        ArrayList ribbonsCylinderCreators)
        throws IOException {
        RibbonsCylinderCreator creator = null;
        Iterator rccIter = ribbonsCylinderCreators.iterator();
        while (rccIter.hasNext() && creator == null) {
            creator = (RibbonsCylinderCreator) rccIter.next();
            if (!creator
                .getProteinResidueName()
                .equals(sInteraction.rB.resName)) {
                creator = null;
            } else {
                break;
            }
        }

        if (creator == null) {
            creator =
                new RibbonsCylinderCreator(
                    sInteraction.rA.resName,
                    sInteraction.rB.resName);
            ribbonsCylinderCreators.add(creator);
        }
        return creator;
    }
    
    /**
     * Processes the interactions from the PDB with this specifc PDB ID string.
     * It searches for the cached version of the PDB file by appending ".pdb"
     * to it before it actually processes the interactions.
     * @param aInteractions
     * @param gInteractions
     * @param cInteractions
     * @param tInteractions
     * @param uInteractions
     * @param pdbID the PDB ID or file name without suffix for the pdb file format
     * model to be processed
     * @param chainlist the array of chain-to-chain matchups to search for
     * interactions between
     * @throws IOException
     */
    private static void addInteractionsFromPDB(
        BaseInteractions aInteractions,
        BaseInteractions gInteractions,
        BaseInteractions cInteractions,
        BaseInteractions tInteractions,
        BaseInteractions uInteractions,
        String pdbID,
        String[] chainlist)
    
        throws IOException {
        InputStream pdbStream = getPDBInputStream(pdbID);
        PDBParser pdbParser = new PDBParser(pdbStream, pdbID);
        pdbParser.parse();

        PDBInformation pdbInformation = pdbParser.getPDBInformation();
        NBInteractionClassifier interactionClassifier =
            new NBInteractionClassifier();
        interactionClassifier.setPDBInformation(pdbInformation);

        Vector pdbModels = pdbParser.getModels();

        Hashtable currentMacromolecules =
            ((PDBModel) pdbModels.get(0)).getMacromolecules();

        // go through the list of proteins
        for (Enumeration e = currentMacromolecules.elements();
            e.hasMoreElements();
            ) {
            Macromolecule macromoleculeA = (Macromolecule) e.nextElement();
            if (macromoleculeA.getType().equals(Macromolecule.PROTEIN)) {
                // go through the list of nucleic acids
                for (Enumeration e2 = currentMacromolecules.elements();
                    e2.hasMoreElements();
                    ) {
                    Macromolecule macromoleculeB =
                        (Macromolecule) e2.nextElement();
                    if (!macromoleculeB.getType().equals(Macromolecule.PROTEIN)
                        && !macromoleculeA.equals(macromoleculeB)
                        && areChainsInChainList(
                            macromoleculeB,
                            macromoleculeA,
                            chainlist)) {
                        System.out.println(macromoleculeB.getChainIdentifier() + " and "
                                           + macromoleculeA.getChainIdentifier()
                                           + " for " + pdbID);
                        interactionClassifier.setMacromoleculeA(macromoleculeA);
                        interactionClassifier.setMacromoleculeB(macromoleculeB);
                        classifyAndAggregateInteractions(
                            aInteractions,
                            gInteractions,
                            cInteractions,
                            tInteractions,
                            uInteractions,
                            interactionClassifier,
                            macromoleculeB);
                    }
                }
            }
        }
    }
    
    // checks to see if the two macromolecules are specificied in chainlist
    // if chainlist is null returns true
    private static boolean areChainsInChainList(
        Macromolecule a,
        Macromolecule b,
        String[] chainlist) {
        if(chainlist == null){
            return true;
        }
        for (int i = 0; i < chainlist.length; i++) {
            String chains = chainlist[i];
            
            String currentChainsA =
                a.getChainIdentifier() + b.getChainIdentifier();
            String currentChainsB = 
                b.getChainIdentifier() + a.getChainIdentifier();
            if(currentChainsA.equals(chains)){
                return true;
            }
            
            if(currentChainsB.equals(chains)){
                return true;
            }
        }
        return false;
    }
    
    
    private static void classifyAndAggregateInteractions(
        BaseInteractions aInteractions,
        BaseInteractions gInteractions,
        BaseInteractions cInteractions,
        BaseInteractions tInteractions,
        BaseInteractions uInteractions,
        NBInteractionClassifier interactionClassifier,
        Macromolecule macromoleculeB) {
        NBInteractionContainer container;
        try {
            container = interactionClassifier.findAndClassifyInteractions();
            Macromolecule nucleicAcid = macromoleculeB;
            /*
             * Macromolecule currentProtein;
             * Macromolecule currentRNA;
             * Macromolecule currentDNA;
             * PDBInformation pdbInformation;
             * NBInteractionClassifier nbInteractionClassifier;
             * NBInteractionContainer nbInteractionContainer;
             */
            Enumeration RNAresidues = nucleicAcid.getResidueEnumeration();

            Vector Adenines = new Vector();
            Vector Cytosines = new Vector();
            Vector Guanines = new Vector();
            Vector Thymines = new Vector();
            Vector Uracils = new Vector();

            while (RNAresidues.hasMoreElements()) {
                Residue r = (Residue) RNAresidues.nextElement();
                if (r.getResName().equals("A"))
                    Adenines.add(r);
                else if (r.getResName().equals("C"))
                    Cytosines.add(r);
                else if (r.getResName().equals("G"))
                    Guanines.add(r);
                else if (r.getResName().equals("T"))
                    Thymines.add(r);
                else if (r.getResName().equals("U"))
                    Uracils.add(r);
            }

            /**
             * NOTES TO SELF
             * 
             * A,G: N7 N9 N1
             * T,C,U: N1 N3 C5
             */

            /*
             * for each base type, if interactions exist, determine the new coordinate system,
             * convert all bonds to the new coordinate system
             */
            sortAndAdd(aInteractions, Adenines, container);
            sortAndAdd(gInteractions, Guanines, container);
            sortAndAdd(cInteractions, Cytosines, container);
            sortAndAdd(tInteractions, Thymines, container);
            sortAndAdd(uInteractions, Uracils, container);

            System.out.println(
                "AP: multiA: finished transforming and compiling.");
        } catch (ParserConfigurationException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        } catch (SAXException e1) {
            e1.printStackTrace();
        }
    }

    /**
     * Given a BaseInteracctions and a Vector of InteractingGroups for a single NA base type,
     * convert the coordinates for the residues and then add to the BaseInteractions
     */
    public static void sortAndAdd(
        BaseInteractions ints,
        Vector residues,
        NBInteractionContainer nbInteractionContainer) {
        String a1;
        String a2;
        String a3;
        /*
         * for each Residue, if interactions exist, determine the new coordinate system,
         * convert all bonds to the new coordinate system
         */
        System.out.println(
            "APanel:MultiA:ResidueLoop: begin.  Residue = " + ints.baseType);

        if (ints.baseType.equals("A") || ints.baseType.equals("G")) {
            a1 = "N7";
            a2 = "N9";
            a3 = "N1";
        } else if (
            ints.baseType.equals("C")
                || ints.baseType.equals("U")
                || ints.baseType.equals("T")) {
            a1 = "N1";
            a2 = "N3";
            a3 = "C5";
        } else {
            System.out.println("unrecognized base type " + ints.baseType);
            return;
        }
        while (residues.size() > 0) {

            Residue r = (Residue) residues.remove(0);
            InteractingGroup ig = nbInteractionContainer.getInteractingGroup(r);

            if ((ig != null) && ig.containsAnInteraction()) {
                // get the three new coordinate atoms
                Atom N7 = r.getAtom(a1);
                Atom N9 = r.getAtom(a2);
                Atom N1 = r.getAtom(a3);
                if (N9 == null || N7 == null || N1 == null) {
                    continue;
                }

                XYZMatrix A = new XYZMatrix(N7.getX(), N7.getY(), N7.getZ());
                XYZMatrix B = new XYZMatrix(N9.getX(), N9.getY(), N9.getZ());
                XYZMatrix C = new XYZMatrix(N1.getX(), N1.getY(), N1.getZ());

                /* first transformation is translation from A to the origin */
                XYZMatrix translation = A;
                //A = (XYZMatrix) A.subtract(translation);
                B = (XYZMatrix) B.subtract(translation);
                C = (XYZMatrix) C.subtract(translation);

                /**
                 * ROTATIONS 
                 *
                 * Spherical coordinates:
                 * x,y,z -> r,theta,phi
                 * 
                 * r = length
                 * theta = angle in x-y plane from positive x-axis, [0,2pi)
                 * phi = angle from positive z-axis, [0,pi]
                 *
                 * double r = Math.sqrt(x*x + y*y + z*z);
                 * double theta = Math.atan2(y,x);
                 * double phi = Math.acos(z/r);
                 */
                double rotation1 = 0 - B.getXYTheta();
                B.applyXYRotation(rotation1);
                C.applyXYRotation(rotation1);
                double rotation2 = Math.PI / 2 - B.getZXTheta();
                //B.applyZXRotation(rotation2);
                C.applyZXRotation(rotation2);
                double rotation3 = 0 - C.getYZTheta();
                //B.applyYZRotation(rotation3);
                //C.applyYZRotation(rotation3);

                //NOW, apply the transformation
                SimpleInteractingGroup sig = ig.simpleCopy();

                sig.transform(translation, rotation1, rotation2, rotation3);

                // add new adenine interaction information to the previous record
                if (ints.genericBase == null)
                    ints.genericBase = sig.nucleicAcidResidue;
                ints.Proteins.addAll(sig.interactingProteinResidues);
                ints.Hbonds.addAll(sig.hydrogenBonds);
                ints.Hinter.addAll(sig.hydrophobicInteractions);
                ints.Einter.addAll(sig.electrostaticInteractions);
                ints.Vinter.addAll(sig.vanderWaalsInteractions);
                ints.Sinter.addAll(sig.stackingInteractions);
                ints.CPinter.addAll(sig.cationPiInteractions);
            }
        }
    }
}
