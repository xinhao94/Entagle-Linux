/*
 * PDBProcessor.java
 *
 * Created on November 10, 2000, 1:44 PM
 */

package entangle;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import org.apache.crimson.tree.XmlDocument;

import entangle.classification.NBInteractionClassifier;
import entangle.classification.NBInteractionContainer;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.PDBInformation;
import entangle.datastructures.PDBModel;
import entangle.utils.io.InteractionXMLDocumentCreator;
import entangle.utils.io.PDBGetter;
import entangle.utils.io.PDBParser;


/**
 * PDBProcessor generates an interaction document for a sequence of PDB files. 
 * @author  Jim Allers
 * @version 1.0
 */
public class PDBProcessor
{
	public NBInteractionClassifier classifier;
    
    
    /** Creates new PDBProcessor */
    public PDBProcessor() 
    {
        classifier = new NBInteractionClassifier();           
	}
	
	
	
	public NBInteractionClassifier getClassifier()
	{
            return classifier;
	}
	
    /**
     * @param args the command line arguments
     */
    public static void main (String[] args)
    {
        PDBProcessor processor = new PDBProcessor();
        String fileDescriptor = args[0];
        Vector pdbIDs = new Vector();
        BufferedReader reader = null;
        
        try
        {
            reader = new BufferedReader(new FileReader(new File(fileDescriptor)));
        }
        catch(FileNotFoundException exc)
        {
            System.out.println("Could not find specified file");
            System.exit(0);
        }
            
        try
        {
            String currentLine = reader.readLine();
            
            while(currentLine!=null)
            {
                pdbIDs.add(new String(currentLine));
                currentLine = reader.readLine();
            }
        }
        catch(IOException e1)
        {
            System.out.println("Error occurred while reading specified file");
        }
		
		// iterate through the list of PDBs and process them.
		// this will attempt to download the PDB from PDB.org if it exists.
        for(int i = 0;i<pdbIDs.size();i++)
        {
            System.out.println("Processing " + i);
            String pdbID = (String)pdbIDs.get(i);
            System.out.println("trying to get " + pdbID + " from file");
            boolean processedPDB = false;
            
            try
            {
                FileInputStream inputStream =
                    new FileInputStream(
                        new File(
                            System.getProperty("user.dir")
                                + File.separator
                                + "pdb"
                                + File.separator
                                + pdbID
                                + ".pdb"));
                processor.process(inputStream,pdbID);
            }
            catch(FileNotFoundException e2)
            {
            	System.out.println("Could not find PDB in directory");
				try
				{
					System.out.println("trying to get " + pdbID + "from pdb.org"); 
					PDBGetter pdbGetter = new PDBGetter(pdbID);
					// writing pdb from pdb.org to file.
					byte[] buf = new byte[1024*32];
					InputStream stream = pdbGetter.openPDBStream();
                    File newPDBFile =
                        new File(
                            System.getProperty("user.dir"),
                            "pdb" + File.separator + pdbID + ".pdb");
					newPDBFile.createNewFile();
                    OutputStream outputStream =
                        new FileOutputStream(
                            new File(
                                System.getProperty("user.dir"),
                                "pdb" + File.separator + pdbID + ".pdb"));
					int bytesRead = 0;
					while((bytesRead = stream.read(buf)) != -1){
						outputStream.write(buf,0,bytesRead);
					}
					outputStream.close();
					stream.close();
					processor.process(new FileInputStream(newPDBFile), pdbID);
				}
				catch(IOException e3)
				{
					System.out.println("Could not get PDB from pdb.org");
				}
            }
            
        }//ends for
    }
	
	
	/**
	 * Processes a PDB model.
	 * @param stream the stream to parse for the PDBs
	 * @param pdbID the ID of the PDB to be processed.
	 */
    public void process(InputStream stream, String pdbID)
    {
        PDBParser pdbParser = new PDBParser(stream,pdbID);
        System.out.println("Parsing " + pdbID);
        try
        {
            pdbParser.parse();
        }
        catch(Exception e)
        {
        	System.err.println("Could not parse " + pdbID);
            System.out.println(e);
            return;
        }
        
        PDBModel pdbModel = (PDBModel)pdbParser.getModels().get(0);
        Hashtable macromolecules = pdbModel.getMacromolecules();
        Vector proteins = new Vector();
        Vector nucleicAcids = new Vector();
        
        for(Enumeration macromoleculeEnumeration = macromolecules.elements(); macromoleculeEnumeration.hasMoreElements();)
        {
            Macromolecule macromolecule = (Macromolecule)macromoleculeEnumeration.nextElement();
                
            if(macromolecule.getType().equals(Macromolecule.PROTEIN))
            {
                proteins.add(macromolecule);
            }
            else
            {
                nucleicAcids.add(macromolecule);
            }
        }
        
        PDBInformation pdbInformation = pdbParser.getPDBInformation();
        classifier.setPDBInformation(pdbInformation);
        
        int i = 0;
        
        try {
            for (Iterator proteinIterator = proteins.iterator();
                proteinIterator.hasNext();
                ) {
                Macromolecule protein = (Macromolecule) proteinIterator.next();
                classifier.setMacromoleculeA(protein);

                for (Iterator nucleicAcidIterator = nucleicAcids.iterator();
                    nucleicAcidIterator.hasNext();
                    ) {
                    	
					System.out.println("Finding and classifying the interactions");
					
                    Macromolecule nucleicAcid =
                        (Macromolecule) nucleicAcidIterator.next();
                    classifier.setMacromoleculeB(nucleicAcid);
                    NBInteractionContainer container =
                        classifier.findAndClassifyInteractions();
                        
					// make sure the directory exists
                    File interactionDocumentsDirectory =
                        new File(System.getProperty("user.dir"),"interactionDocuments");
					if(!interactionDocumentsDirectory.exists()){
						interactionDocumentsDirectory.mkdirs();
					}
					
                    File interactionDocument =
                        new File(
                            interactionDocumentsDirectory,
                            pdbID
                                + protein.getChainIdentifier()
                                + "&"
                                + nucleicAcid.getChainIdentifier()
                                + ".xml");
					interactionDocument.createNewFile();
					
                    FileOutputStream fileOutputStream =
                        new FileOutputStream(interactionDocument);
                    InteractionXMLDocumentCreator documentCreator =
                        new InteractionXMLDocumentCreator(container);
                    XmlDocument xmlDocument =
                        documentCreator.createXMLDocument();
                    xmlDocument.write(fileOutputStream);
                }
            }
        } catch (Exception e) {
            System.out.print(e);
        }
    }//ends process
}