package entangle.j3d;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import javax.media.j3d.Link;
import javax.media.j3d.Material;
import javax.media.j3d.Node;
import javax.media.j3d.SharedGroup;
import javax.vecmath.Color3f;

import entangle.datastructures.Atom;



// Singleton for rendering info lookup
// The plan is to make this customizable by the the user

public class RenderTable implements RenderStyle
{
   static RenderTable table = null;
   
   /** The Radius of the sticks **/
   public static float STICK_RADIUS = 0.14f;

   /** The Radius of the balls int ball and stick mode **/
   public static float BALL_RADIUS = 0.3f;

   static final int STICK_QUALITY = 7;

   Color3f aColor  = new Color3f(1.0f, 1.0f, 1.0f);
   Color3f eColor  = new Color3f(0.0f, 0.0f, 0.0f);
   Color3f dColor  = new Color3f(0.1f, 0.1f, 0.1f);
   Color3f sColor  = new Color3f(1.0f, 1.0f, 1.0f);
	/*
   static final Color3f lightGrey 	= new Color3f(0.78f,	0.78f,	0.78f	);
   static final Color3f red 		= new Color3f(0.94f,	0f,		0f		);
   static final Color3f white 		= new Color3f(1f,		1f,		1f		);
   static final Color3f lightBlue 	= new Color3f(0.56f,	0.56f,	1f		);
   static final Color3f yellow 		= new Color3f(1f,		0.78f,	0.19f	);
   static final Color3f orange 		= new Color3f(1f,		0.64f,	0f		);
   static final Color3f green 		= new Color3f(0f,		1f,		0f		);
   static final Color3f grey 		= new Color3f(.5f,		.5f,	.5f		);
   */
   
   static final Color3f NAlightGrey = new Color3f(0.95f,	0.95f,	0.95f	);
   static final Color3f NAred 		= new Color3f(1f,		0f,		0f		);
   static final Color3f NAwhite 	= new Color3f(1f,		1f,		1f		);
   static final Color3f NAlightBlue = new Color3f(0.75f,	0.75f,	1f		);
   static final Color3f NAyellow 	= new Color3f(1f,		0.9f,	0.23f	);
   static final Color3f NAorange 	= new Color3f(1f,		0.64f,	0f		);
   static final Color3f NAgreen 	= new Color3f(0f,		1f,		0f		);
   static final Color3f NAgrey 		= new Color3f(.65f,		.65f,	.65f	);
   
   static final Color3f PlightGrey 	= new Color3f(0.5f,		0.5f,	0.5f	);
   static final Color3f Pred 		= new Color3f(0.7f,		0f,		0f		);
   static final Color3f Pwhite 		= new Color3f(.7f,		.7f,	.7f		);
   static final Color3f PlightBlue 	= new Color3f(0.4f,		0.4f,	.71f	);
   static final Color3f Pyellow 	= new Color3f(.75f,		0.57f,	0.14f	);
   static final Color3f Porange 	= new Color3f(.75f,		0.40f,	0f		);
   static final Color3f Pgreen 		= new Color3f(0f,		.7f,	0f		);
   static final Color3f Pgrey 		= new Color3f(.3f,		.3f,	.3f		);
   
   
   static final Color3f MINIMUM_PROTEIN_CONNECTION_COLOR = new Color3f(0.4f,0f,0.4f);
   static final Color3f MINIMUM_NUCLEIC_ACID_CONNECTION_COLOR = new Color3f(0f,.4f,.4f);
   
   int renderStyle = RenderStyle.WIRE;

   Hashtable nodeCache = new Hashtable();
   Vector renderList = new Vector(100);


   /** The look-up tableS for the atom colors **/
   static Hashtable NAatomColors = new Hashtable();
   static Hashtable PatomColors = new Hashtable();

   /** The look-up table for the atom radii **/
   static Hashtable atomRadii = new Hashtable();

   static 
   {
            /*
            atomColors.put("C",lightGrey);
            atomColors.put("O",red);
            atomColors.put("H",white);
            atomColors.put("N",lightBlue);
            atomColors.put("S",yellow);
            atomColors.put("P",orange);
            atomColors.put("X", new Color3f(.5f,.5f,.5f)); 
      		*/
      		
      		NAatomColors.put("C",	NAlightGrey);
            NAatomColors.put("O",	NAred);
            NAatomColors.put("H",	NAwhite);
            NAatomColors.put("N",	NAlightBlue);
            NAatomColors.put("S",	NAyellow);
            NAatomColors.put("P",	NAorange);
            NAatomColors.put("X", NAgrey); 
      
            
            PatomColors.put("C",	PlightGrey);
            PatomColors.put("O",	Pred);
            PatomColors.put("H",	Pwhite);
            PatomColors.put("N",	PlightBlue);
            PatomColors.put("S",	Pyellow);
            PatomColors.put("P",	Porange);
            PatomColors.put("X", Pgrey); 
            
      
            // Fill in some default atom radii
            atomRadii.put("C", new Float(1.53));
            atomRadii.put("H", new Float(1.08));
            atomRadii.put("N", new Float(1.48));
            atomRadii.put("O", new Float(1.36));
            atomRadii.put("P", new Float(1.75));
            atomRadii.put("S", new Float(1.70));
            atomRadii.put("Cl", new Float(1.65));
            atomRadii.put("F", new Float(1.30));
            atomRadii.put("Br", new Float(1.80));
            atomRadii.put("I", new Float(2.05));
            atomRadii.put("X", new Float(1.4));
   }




   /** non public constructor **/
   private RenderTable()
   {
   }



   /** initializes the table **/
   static void init()
   {
      table = new RenderTable();
   }
   
   
   /** the accessor method for rthe instance of the RenderTable **/
   public static RenderTable getTable()
   {
      if (table == null)
      {
          init();
      }
      
      return table;
   }



   /** get the radius for atom a **/
   public float getRadius(Atom a)
   {
      String name = a.getName();
      Float r = null;
      if (atomRadii.containsKey(name))
	 		r = (Float)atomRadii.get(name);
      else
	 		r = (Float)atomRadii.get("X");
      
      if (r == null)
	 		return 0.0f;

      return r.floatValue();
   }



   /** Get the color3f for atom a**/
   public Color3f getColor(Atom a)
   {
      String name = a.getAtomType();
      //Color3f c = null;
      
      Color3f c = new Color3f(1f,.7f,.7f); // pink, to make them obvious -- this method should not be used (LRM)
      
      //if (atomColors.containsKey(name))
	 //		c = (Color3f)atomColors.get(name);
      //else
	 //		c = (Color3f)atomColors.get("X");
      
      return c;
   }



   /** get the material for atom a**/
   public Material getMaterial(Atom a)
   {
      Color3f aColor  = getColor(a);
      Color3f dColor  = getColor(a);
      return new Material(aColor, eColor, dColor, sColor, 20.0f);
   }



   /** Set the current rendering style **/
   public void setStyle(int style)
   {
      renderStyle = style;
      //Loop over renderList
      Iterator iter = renderList.iterator();
      while(iter.hasNext())
      {
	  		RenderStyle rs = (RenderStyle)iter.next();
	  		rs.setStyle(style);
      }
   }



   /** What is the current rendering style ? **/
   public int getStyle()
   {
      return renderStyle;
   }



   public Node getSharedAtomGroup(Atom a)
   {
      String pref = "sag"; // SharedAtomGroup
      String key = a.getAtomType();
      SharedAtomGroup sag = (SharedAtomGroup)nodeCache.get(key);
      if (sag != null)
      {
	 		//System.out.println("Using shared Cyl");
	 		return new Link(sag);
      }

      sag = new SharedAtomGroup(a);
      addCachedNode(key, sag);
      return new Link(sag);
   }



   public Node getSharedBondGroup(Atom a)
   {
      	String pref = "sbg"; // SharedBondGroup
		String key = a.getAtomType()+"_BOND";
		SharedBondGroup sbg = (SharedBondGroup)nodeCache.get(key);
		
		if (sbg != null)
		{
			//System.out.println("Using shared Cyl");
			return new Link(sbg);
		}
		else
		{
			sbg = new SharedBondGroup(a);
			addCachedNode(key, sbg);
		}
		
		return new Link(sbg);
   }
   
   
   
   public Node getSharedBondGroup(Atom a,Color3f minimumColor)
   {
        String key = a.getAtomType()+"_MINIMUM";
		SharedBondGroup sbg = (SharedBondGroup)nodeCache.get(key);
		if (sbg != null)
		{
			//System.out.println("Using shared Cyl");
			return new Link(sbg);
		}
		else
		{
			sbg = new SharedBondGroup(a);
			addCachedNode(key, sbg);
		}
	
		return new Link(sbg);
   }


   void addCachedNode(String key, SharedGroup gr)
   {
      nodeCache.put(key, gr);
      renderList.addElement(gr);
   }
}