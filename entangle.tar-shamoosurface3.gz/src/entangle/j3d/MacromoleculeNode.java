/*
 * MacromoleculeNode.java
 *
 * Created on November 15, 2000, 11:39 AM
 */

package entangle.j3d;

import java.util.Enumeration;
import java.util.Hashtable;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Group;

import entangle.classification.InteractingGroup;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.Residue;


/**
 *
 * @author  Jim Allers
 * @version 
 */
public class MacromoleculeNode extends BranchGroup 
{
	Hashtable residueNodes;
	Macromolecule macromolecule;

    private ResidueNode lnkResidueNode;




    /** Creates new MacromoleculeNode */
    public MacromoleculeNode(Macromolecule macromolecule) 
    {
		setCapability(Group.ALLOW_CHILDREN_READ);
		setCapability(Group.ALLOW_CHILDREN_WRITE);
		setCapability(Group.ALLOW_CHILDREN_EXTEND);
		setCapability(BranchGroup.ALLOW_DETACH);
		
		Residue tempResidue;
		
		this.macromolecule = macromolecule;
		residueNodes = new Hashtable();
		
		for(Enumeration e = macromolecule.getResidueEnumeration(); e.hasMoreElements();)
		{
			tempResidue = (Residue)e.nextElement();
			ResidueNode residueNode = new ResidueNode(tempResidue);
			addChild(residueNode);
			residueNodes.put(new Integer(tempResidue.getResidueSequenceNumber()), residueNode);
		}
	}
	
	
	
	
	public void setVisibilityOfInteractingGroup(InteractingGroup currentInteractingGroup, boolean isVisible)
	{
		Residue nucleicAcidResidue = currentInteractingGroup.getNucleicAcidResidue();
        Hashtable interactingProteinResidues = currentInteractingGroup.getInteractingProteinResidues();
		
		if(macromolecule.getType().equals(Macromolecule.PROTEIN))
		{
			for(Enumeration interactingProteinResidueEnumeration = interactingProteinResidues.elements();
				interactingProteinResidueEnumeration.hasMoreElements();)
			{
				Residue proteinResidue = (Residue)interactingProteinResidueEnumeration.nextElement();
				setFullyRendered(proteinResidue,isVisible);
			}
		}
        
        if(macromolecule.getType().equals(Macromolecule.RNA) || macromolecule.getType().equals(Macromolecule.DNA))
        {
			 setFullyRendered(nucleicAcidResidue,isVisible);
		}
	}
	
	
	public ResidueNode getResidueNode(Residue residue)
	{
		return (ResidueNode)residueNodes.get(new Integer(residue.getResidueSequenceNumber()));
	}
	
	
	public void setFullyRendered(Residue residue,boolean isFullyRendered)
	{
		ResidueNode residueNode = (ResidueNode)residueNodes.get(new Integer(residue.getResidueSequenceNumber()));
		
		// deal with the next residue
		if(residue.getParentMacromolecule().containsNextResidue(residue))
		{
			Residue nextResidue = residue.getParentMacromolecule().getNextResidue(residue);
			ResidueNode nextResidueNode = (ResidueNode)residueNodes.get(new Integer(nextResidue.getResidueSequenceNumber()));
			
			// update specified residue node
			updateRenderingMode(residueNode,nextResidueNode,isFullyRendered);
		}
		
		// deal with the previous residue
		if(residue.getParentMacromolecule().containsPreviousResidue(residue))
		{
			Residue previousResidue = residue.getParentMacromolecule().getPreviousResidue(residue);
			ResidueNode previousResidueNode = (ResidueNode)residueNodes.get(
					new Integer(previousResidue.getResidueSequenceNumber()));
			updateRenderingMode(previousResidueNode,residueNode, previousResidueNode.isFullyRendered());
		}
	}
	
	
	
	/**
	* This method makes sure the subsequent residue if it exists is rendered 
	* appropriately
	*/
	public void updateRenderingMode(ResidueNode residueNode, ResidueNode nextResidueNode, boolean isFullyRendered)
	{
		if(nextResidueNode.isFullyRendered())
		{
			// fully-rendered-fully-rendered
			if(isFullyRendered)
			{
				residueNode.setRenderMode(ResidueNode.BOTH_FULLY_RENDERED);
			}
			else
			{
				residueNode.setRenderMode(ResidueNode.NEXT_RESIDUE_IS_FULLY_RENDERED);
			}
		}
		else
		{
			if(isFullyRendered)
			{
				residueNode.setRenderMode(ResidueNode.FULLY_RENDERED_BUT_NEXT_RESIDUE_IS_JUST_BACKBONE);
			}
			else
			{
				residueNode.setRenderMode(ResidueNode.NEXT_RESIDUE_IS_BACKBONE_ONLY);
			}
		}
	}
}