package entangle.j3d;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import entangle.classification.InteractingGroup;
import entangle.classification.NBInteractionContainer;
import entangle.datastructures.Macromolecule;

/**
 * Provides a frame for PDBViewerPanel.
 *
 * @author Lowell Meyer
 * @since 7/26/01
 */
public class PDBViewerFrame extends JFrame
{
	boolean hydrogenVisible = false;
	boolean electrostaticVisible = false;
	boolean stackingVisible = false;
	boolean hydrophobicVisible = false;
	boolean vanderWaalsVisible = false;
	
	Hashtable visibleResidues = new Hashtable();
	
	final PDBViewerPane pdbViewerPane;
	
	
	
	
    public PDBViewerFrame(String title, Macromolecule protein, Macromolecule rna, NBInteractionContainer container)
    {
		setTitle(title);  				// from java.awt.Frame
		
		Macromolecule currentProtein = protein;
		Macromolecule currentNucleicAcid = rna;
		NBInteractionContainer currentContainer = container;
		
		pdbViewerPane = new PDBViewerPane(currentProtein, currentNucleicAcid, currentContainer);
		
		
				
		// SET UP THE MENU BAR FOR THE 3D VIEWING FRAME
		JMenuBar 			menuBar = new JMenuBar();
		JMenu 				menu;
		JCheckBoxMenuItem 	cbMenuItem;

				
				
		// INITIALIZE THE RESIDUES MENU
		menu = new JMenu("Residues");
		menu.setMnemonic(KeyEvent.VK_R);
		menu.getAccessibleContext().setAccessibleDescription("Select which residues are drawn");
		
		menu.setPopupMenuVisible(true);		//////////////////
				 
		// ADD ITEMS TO THE RESIDUES MENU
		Enumeration residues = currentContainer.getInteractingGroups().elements();
				
		while(residues.hasMoreElements() )
		{
			final InteractingGroup currentGroup = (InteractingGroup)residues.nextElement();
			final String residueName = currentGroup.toString();
					
			cbMenuItem = new JCheckBoxMenuItem( residueName );
			cbMenuItem.addItemListener(	
				new ItemListener()
				{
	    			public void itemStateChanged(ItemEvent e)
	    			{
	    				if (e.getStateChange() == ItemEvent.DESELECTED)
	    				{
	    					System.out.println("you deselected " + residueName + " from the residues menu.");
	    					
	    					makeGroupInvisible(currentGroup);
	    				}
	    				else if (e.getStateChange() == ItemEvent.SELECTED)
	    				{
	    					System.out.println("you selected " + residueName + " from the residues menu.");
	    					
	    					makeGroupVisible(currentGroup);
	    				}
	    				
	    				recalculateCenterOfMass();
	    			}
				});
			
			menu.add(cbMenuItem);												
		}
		
		// FORCE THE MENU TO DRAW THE FULL VERSION -- THE ONLY VERSION VISIBLE OVER THE J3D IMAGE
		menu.getPopupMenu().setLightWeightPopupEnabled(false); 
		
		// ADD THE RESIDUES MENU TO THE MENU BAR
		menuBar.add(menu);
				



				
		// INITIALIZE THE INTERACTIONS MENU
		menu = new JMenu("Interactions");
		menu.setMnemonic(KeyEvent.VK_I);
		menu.getAccessibleContext().setAccessibleDescription("Select which interactions are drawn");
		
				
		// ADD ITEMS TO THE INTERACTIONS MENU
		cbMenuItem = new JCheckBoxMenuItem("Hydrogen Bonds");
		cbMenuItem.setMnemonic(KeyEvent.VK_H);
		
		cbMenuItem.addItemListener(
			new ItemListener()
			{
	    		public void itemStateChanged(ItemEvent e)
	    		{
	    			if (e.getStateChange() == ItemEvent.DESELECTED)
	    			{
	    				System.out.println("you deselected Hydrogen Bonds");
	    				hideHydrogenBonds();
	    			}
	    			else if (e.getStateChange() == ItemEvent.SELECTED)
	    			{
	    				System.out.println("you selected Hydrogen Bonds");
	    				showHydrogenBonds();
	    			}
	    		}
			});
		menu.add(cbMenuItem);


		cbMenuItem = new JCheckBoxMenuItem("Electrostatic Interactions");
		cbMenuItem.setMnemonic(KeyEvent.VK_E);
		
		cbMenuItem.addItemListener(
			new ItemListener()
			{
	    		public void itemStateChanged(ItemEvent e)
	    		{
	    			if (e.getStateChange() == ItemEvent.DESELECTED)
	    			{
	    				System.out.println("you deselected Electrostatic Interactions");
	    				hideElectrostaticInteractions();
	    			}
	    			else if (e.getStateChange() == ItemEvent.SELECTED)
	    			{
	    				System.out.println("you selected Electrostatic Interactions");
	    				showElectrostaticInteractions();
	    			}
	    		}
			});
		menu.add(cbMenuItem);
				
				
		cbMenuItem = new JCheckBoxMenuItem("Stacking Interactions");
		cbMenuItem.setMnemonic(KeyEvent.VK_S);
		
		cbMenuItem.addItemListener(
			new ItemListener()
			{
	    		public void itemStateChanged(ItemEvent e)
	    		{
	    			if (e.getStateChange() == ItemEvent.DESELECTED)
	    			{
	    				System.out.println("you deselected Stacking Interactions");
	    				hideStackingInteractions();
	    			}
	    			else if (e.getStateChange() == ItemEvent.SELECTED)
	    			{
	    				System.out.println("you selected Stacking Interactions");
	    				showStackingInteractions();
	    			}
	    		}
			});
		menu.add(cbMenuItem);
		
		cbMenuItem = new JCheckBoxMenuItem("Hydrophobic Interactions");
		cbMenuItem.setMnemonic(KeyEvent.VK_P);
		
		cbMenuItem.addItemListener(
			new ItemListener()
			{
	    		public void itemStateChanged(ItemEvent e)
	    		{
	    			if (e.getStateChange() == ItemEvent.DESELECTED)
	    			{
	    				System.out.println("you deselected Hydrophobic Interactions");
	    				hideHydrophobicInteractions();
	    			}
	    			else if (e.getStateChange() == ItemEvent.SELECTED)
	    			{
	    				System.out.println("you selected Hydrophobic Interactions");
	    				showHydrophobicInteractions();
	    			}
	    		}
			});
		menu.add(cbMenuItem);
		
		
		cbMenuItem = new JCheckBoxMenuItem("Van der Waals Interactions");
		cbMenuItem.setMnemonic(KeyEvent.VK_S);
		
		cbMenuItem.addItemListener(
			new ItemListener()
			{
	    		public void itemStateChanged(ItemEvent e)
	    		{
	    			if (e.getStateChange() == ItemEvent.DESELECTED)
	    			{
	    				System.out.println("you deselected Van der Waals Interactions");
	    				hideVanderWaalsInteractions();
	    			}
	    			else if (e.getStateChange() == ItemEvent.SELECTED)
	    			{
	    				System.out.println("you selected Van der Waals Interactions");
	    				showVanderWaalsInteractions();
	    			}
	    		}
			});
		menu.add(cbMenuItem);
		
		
		// FORCE THE MENU TO DRAW THE FULL VERSION -- THE ONLY VERSION VISIBLE OVER THE J3D IMAGE
		menu.getPopupMenu().setLightWeightPopupEnabled(false); 

		// ADD THE INTERACTIONS MENU TO THE MENU BAR
		menuBar.add(menu);
		//menuBar.setOpaque(true);  // optional??
				
				
		// INITIALIZE THE HELP MENU
		menu = new JMenu("Help");
		menu.setMnemonic(KeyEvent.VK_H);
		menu.getAccessibleContext().setAccessibleDescription("Get info about the display");
		
		
		JMenuItem menuItem;
		
		menuItem = new JMenuItem("Show Legend");
		menuItem.setMnemonic(KeyEvent.VK_L);
		
		menuItem.addActionListener(
			new ActionListener()
			{
	    		public void actionPerformed(ActionEvent e)
	    		{
	    			System.out.println("you selected Help / Show Legend");
	    			showHelp();
	    		}
			});
		menu.add(menuItem);
		
		
		menuItem = new JMenuItem("Show Controls");
		menuItem.setMnemonic(KeyEvent.VK_C);
		
		menuItem.addActionListener(
			new ActionListener()
			{
	    		public void actionPerformed(ActionEvent e)
	    		{
	    			System.out.println("you selected Help / Show Controls");
	    			showControls();
	    		}
			});
		menu.add(menuItem);
		
		
		// FORCE THE MENU TO DRAW THE FULL VERSION -- THE ONLY VERSION VISIBLE OVER THE J3D IMAGE
		menu.getPopupMenu().setLightWeightPopupEnabled(false); 

		// ADD THE INTERACTIONS MENU TO THE MENU BAR
		menuBar.add(menu);
		//menuBar.setOpaque(true);  // optional??
				
				
				
		// ADD THE MENU BAR TO THE FRAME
		setJMenuBar(menuBar);
				
				
				
				
		// ADD THE PDBVIEWERPANE TO THE FRAME
		
		//getContentPane().add( (java.awt.Component)pdbViewerPane, BorderLayout.CENTER);
		setContentPane(pdbViewerPane);
		
		//getContentPane().add(new AnalyzerPanel(new Analyzer("test") ), BorderLayout.CENTER);
		
				
					
				
		// SET FRAME PROPERTIES
		setSize(400,400);
		setVisible(true);
    }
    
    
    private void makeGroupVisible(InteractingGroup group)
    {
    	visibleResidues.put(group.toString(), group);
    	
	    pdbViewerPane.getProteinNode().setVisibilityOfInteractingGroup(group, true);
		pdbViewerPane.getNucleicAcidNode().setVisibilityOfInteractingGroup(group, true);
							
		if (hydrogenVisible)
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfHydrogenBonds(group, true);
								
		if (electrostaticVisible)
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfElectrostaticInteractions(group, true);
								
		if (stackingVisible)
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfStackingInteractions(group, true);
			
		if (hydrophobicVisible)
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfHydrophobicInteractions(group, true);
			
		if (vanderWaalsVisible)
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfVanderWaalsInteractions(group, true);
	}
	
	private void makeGroupInvisible(InteractingGroup group)
	{
		visibleResidues.remove( group.toString() );
		
		pdbViewerPane.getProteinNode().setVisibilityOfInteractingGroup(group, false);
		pdbViewerPane.getNucleicAcidNode().setVisibilityOfInteractingGroup(group, false);
		pdbViewerPane.getInteraction3DContainer().setVisibilityOfInteractions(group, false);
		
		
		// It is possible that the group which was just turned off made invisible a protein residue involved in
		// an interaction with a different visible nucleic acid base.  To fix this, we go through all the visible
		// nucleic acid bases and ensure that their associated proteins are made visible.
		InteractingGroup aVisibleGroup;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			aVisibleGroup = (InteractingGroup)residues.next();
			
			pdbViewerPane.getProteinNode().setVisibilityOfInteractingGroup(aVisibleGroup, true);
		}
	}	
	
	
	private void showHydrogenBonds()
	{
		hydrogenVisible = true;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfHydrogenBonds((InteractingGroup)residues.next(), true);
		}
	}
	
    private void hideHydrogenBonds()
	{
		hydrogenVisible = false;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfHydrogenBonds((InteractingGroup)residues.next(), false);
		}
	}
	
	private void showElectrostaticInteractions()
	{
		electrostaticVisible = true;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfElectrostaticInteractions((InteractingGroup)residues.next(), true);
		}
	}
	
    private void hideElectrostaticInteractions()
	{
		electrostaticVisible = false;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfElectrostaticInteractions((InteractingGroup)residues.next(), false);
		}
	}
	
	private void showStackingInteractions()
	{
		stackingVisible = true;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfStackingInteractions((InteractingGroup)residues.next(), true);
		}
	}
	
    private void hideStackingInteractions()
	{
		stackingVisible = false;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfStackingInteractions((InteractingGroup)residues.next(), false);
		}
	}
	
	private void showHydrophobicInteractions()
	{
		hydrophobicVisible = true;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfHydrophobicInteractions((InteractingGroup)residues.next(), true);
		}
	}
	
    private void hideHydrophobicInteractions()
	{
		hydrophobicVisible = false;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfHydrophobicInteractions((InteractingGroup)residues.next(), false);
		}
	}
	
	private void showVanderWaalsInteractions()
	{
		vanderWaalsVisible = true;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfVanderWaalsInteractions((InteractingGroup)residues.next(), true);
		}
	}
	
    private void hideVanderWaalsInteractions()
	{
		vanderWaalsVisible = false;
		
		for (Iterator residues = visibleResidues.values().iterator(); residues.hasNext(); )
		{
			pdbViewerPane.getInteraction3DContainer().setVisibilityOfVanderWaalsInteractions((InteractingGroup)residues.next(), false);
		}
	}
	
	
	
	private void showHelp()
	{
		HelpFrame hf = new HelpFrame("Legend");
	}
	
	private void showControls()
	{
		ControlFrame cf = new ControlFrame("Controls");
	}
	
	// USED BY RESIDUE MENU ITEM LISTENERS
	private void recalculateCenterOfMass()
	{
		pdbViewerPane.computeCenterOfMass(visibleResidues);
	}
}