package entangle.j3d;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Node;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Color3f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

import entangle.datastructures.Atom;
import entangle.datastructures.Bond;

public class BondNode extends BranchGroup 
{
   Bond myBond;
   Atom a1;
   Atom a2;
   
   Color3f minimumColor;
   static final int STICK_QUALITY = 7;
   RenderTable rTable = RenderTable.getTable();
   
   
   
   protected BondNode(Atom a1,Atom a2)
   {
      this.a1 = a1;
      this.a2 = a2;
      createStick();
   }
   
   /**
   * Build a minimal connection between the residues
   */
   protected BondNode(Atom a1,Atom a2,Color3f minimumColor)
   {
        this.a1 = a1;
        this.a2 = a2;
        this.minimumColor = minimumColor;
        createStick();
   }



   public static Node createWire(Bond b)
   {
           Node wire = null;
           return wire;
   }


   void createStick()
   {
        try
        {
            Vector3f middle = getMiddleOfBond(a1, a2);
            float dist = calcDistance(a1, a2);
            Vector3f rel = new Vector3f( (float)(a2.getX()-a1.getX()),
				   (float)(a2.getY()-a1.getY()), (float)(a2.getZ()-a1.getZ()));
            rel.normalize();
            double xrot = calcAngle( new Vector3f(0.0f, 1.0f, 0.0f), rel);
      
            Vector3f proj = new Vector3f(rel.x, 0.0f, rel.z);
            float yrot = calcSign(new Vector3f(1.0f, 0.0f, 0.0f), proj)*
	                 calcAngle(new Vector3f(0.0f, 0.0f, 1.0f ), proj);
            Node cyl1=null;
            Node cyl2=null;
            
            if(minimumColor!=null)
            {
            	cyl1 = rTable.getSharedBondGroup(a1,minimumColor);
            }
            else
            {
                cyl1 = rTable.getSharedBondGroup(a1); 
            }
            
            if(minimumColor!=null)
            {
                cyl2 = rTable.getSharedBondGroup(a2,minimumColor); 
            }
            else
            {
                cyl2 = rTable.getSharedBondGroup(a2);
            }
            
            Transform3D rot = new Transform3D();
            rot.rotX(xrot);

            Transform3D t3d1 = new Transform3D();
            double halfDistance = (double)(dist/2.0f);
            t3d1.rotY(yrot);
            t3d1.mul(rot);
            t3d1.setTranslation(new Vector3d(a1.getX()+rel.x*(halfDistance/2.0f), 
                                       a1.getY()+rel.y*(halfDistance/2.0f), a1.getZ()+rel.z*(halfDistance/2.0f)));
            t3d1.setScale(new Vector3d(1.0,(double)(dist/2.0f),1.0));

            Transform3D t3d2 = new Transform3D();
            t3d2.rotY(yrot);
            t3d2.mul(rot);
            t3d2.setTranslation(new Vector3d(middle.x+rel.x*(halfDistance/2.0f),
                                       middle.y+rel.y*(halfDistance/2.0f), middle.z+rel.z*(halfDistance/2.0f)));
            t3d2.setScale(new Vector3d(1.0,(double)(dist/2.0f),1.0));
            
            //t3d2.setScale(dist/2.0);
            TransformGroup myTrans = new TransformGroup(t3d1);
            TransformGroup mid = new TransformGroup(t3d2);
            if(cyl2!=null) mid.addChild(cyl2);
            if(cyl1!=null) myTrans.addChild(cyl1);
            addChild(myTrans);
            addChild(mid);
            
            //mid.addChild(cyl2.getShape());
            //myTrans.addChild(cyl1.getShape());
        }
        catch(Exception e)
        {
	    	e.printStackTrace(System.out);
            System.out.println("Error when creating bond cylinder");
            System.out.println("Occurred between " + a1);
            System.out.println(" & " + a2);
        }
   }
   
   
   protected float calcDistance( Atom from, Atom to)
   {
      double dx = (double)(to.getX() - from.getX());
      double dy = (double)(to.getY() - from.getY());
      double dz = (double)(to.getZ() - from.getZ());

      double dist = (double)Math.sqrt( (double)( dx*dx+dy*dy+dz*dz));
      
      return (float)dist;
   }


   protected static Vector3f getMiddleOfBond( Atom from, Atom to)
   {
      float x = (float)((to.getX() - from.getX())/2.0f + from.getX());
      float y = (float)((to.getY() - from.getY())/2.0f + from.getY());
      float z = (float)((to.getZ() - from.getZ())/2.0f + from.getZ());
      
      return new Vector3f(x,y,z);
   }


   protected static float calcAngle(Vector3f coor, Vector3f other)
   {
      double scalarProduct = (double)coor.dot(other);
      
      if (scalarProduct == 0.0f) 
      {
	      //System.out.println("acos "+Math.acos(0.0f));
	  	  return (float)Math.PI/2.0f;
      }
      
      scalarProduct = scalarProduct/(coor.length()*other.length());
      
      return (float)Math.acos(scalarProduct);
   }


   protected static float calcSign(Vector3f coor, Vector3f other)
   {
      double sp = (double)coor.dot(other);
      
      if (sp == 0.0f)
	      return 0.0f;
	      
      return (float)(sp/Math.abs(sp));
   }
}