package entangle.j3d;

public interface RenderStyle 
{
   public static final int NONE = -1;
   public static final int INVISIBLE = 0;
   public static final int CPK = 1;
   public static final int BALL_AND_STICK = 2;
   public static final int STICK = 3;
   public static final int WIRE = 4;
   
   
   public void setStyle(int style);
}
