package entangle.j3d;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Vector3f;

import entangle.datastructures.Atom;


public class AtomNode extends BranchGroup 
{
   Atom myAtom;

   TransformGroup myTrans;
   Transform3D myLoc;

   protected AtomNode(Atom a)
   {
      super();
      myAtom = a;
      
      //System.out.println("Node atom");
      myLoc = new Transform3D();
      myLoc.set(new Vector3f( (float)a.getX(), (float)a.getY(), (float)a.getZ()));
      myTrans = new TransformGroup(myLoc);
      
      addChild(myTrans);
      myTrans.addChild(RenderTable.getTable().getSharedAtomGroup(myAtom));
   }

   void setCoor(float x, float y, float z)
   {
      myLoc.set(new Vector3f(x,y,z));
   }
}

