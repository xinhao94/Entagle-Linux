package entangle.j3d;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Provides a frame for the control help window
 *
 * @author Lowell Meyer
 * @since 8/9/01
 */
public class ControlFrame extends JFrame
{
	
	
    public ControlFrame(String title)
    {
		setTitle(title);  				// from java.awt.Frame
		
		
		JPanel panel = new JPanel();
		
		
		///////////////////
		// Control text 1//
		///////////////////
		
		JLabel text1 = new JLabel("<html><b><font color=black size=+1>Controls:<ul><li>Left-Click and Drag to Rotate<li>Right-Click and Drag to Translate<li>Alt + Left-Click and Drag Vertically to Zoom</ul></font></b></html>");
		
		panel.add(text1);
		
		
		
		// SET FRAME PROPERTIES
		
		getContentPane().add(panel);
			
		pack();
		setVisible(true);
    }   
}