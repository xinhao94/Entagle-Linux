/*
 * Last Modified: 07/27/2000 
 * Author: Jim Allers
 */


package entangle.j3d;

import java.io.File;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.media.j3d.GeometryArray;
import javax.media.j3d.Group;
import javax.media.j3d.LineArray;
import javax.media.j3d.LineAttributes;
import javax.media.j3d.Material;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.RenderingAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Switch;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import com.sun.j3d.utils.geometry.GeometryInfo;
import com.sun.j3d.utils.geometry.NormalGenerator;
import com.sun.j3d.utils.geometry.Sphere;

import entangle.classification.InteractingGroup;
import entangle.classification.NBInteractionContainer;
import entangle.classification.electrostatic.ElectrostaticInteraction;
import entangle.classification.hbonds.HydrogenBond;
import entangle.classification.hydrophobic.HydrophobicInteraction;
import entangle.classification.stacking.StackingInteraction;
import entangle.classification.vanderwaals.VanderWaalsInteraction;
import entangle.datastructures.Atom;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.Residue;
import entangle.utils.EntangleProperties;
import entangle.utils.io.AromaticRingDOMParser;


/**
 * This class has a collection of methods to draw the interactions found between 
 * the two macromolecules
 */
public class Interaction3DContainer
{
    NBInteractionContainer container;
    
    int thickness = 6; //3
    
    float SPHERE_RADIUS = 1.5f;
    
    Color3f lightGreen 	= new Color3f(.5f,.7f,.5f);
    Color3f lightBlue 	= new Color3f(.5f,.5f,.7f);
    Color3f lightOrange = new Color3f(1f,.729f,.411f);
    Color3f red			= new Color3f(1f,0f,0f);
    Color3f	yellow		= new Color3f(1f,1f,0f);
    Color3f pink		= new Color3f(1f,.5f,.5f);
    Color3f orange		= new Color3f(1f,.5f,0f);
    Color3f purple		= new Color3f(1f,0f,1f);
    Color3f black		= new Color3f(0f,0f,0f);
    
    final int ELECTROSTATIC_INTERACTION = 357;
    final int HYDROGEN_BOND = 358;
    final int STACKING_INTERACTION = 359;
    
    Hashtable electrostaticNodes;
    Hashtable hydrogenBondNodes;
    Hashtable stackingNodes;
    Hashtable rings;
    Hashtable vanderWaalsNodes;		//LRM
    Hashtable hydrophobicNodes;		//LRM
    
    Appearance electrostaticAppearance = new Appearance();
    Appearance hydrogenBondAppearance = new Appearance();
    Appearance stackingAppearance = new Appearance();
    //Appearance vanderWaalsAppearance = new Appearance();		//LRM
    //Appearance hydrophobicAppearance = new Appearance();		//LRM
    
    LineAttributes hydrogenBondLineAttributes;
    LineAttributes electrostaticLineAttributes;
    
    //LineAttributes vanderWaalsLineAttributes;		//LRM
    //LineAttributes hydrophobicLineAttributes;		//LRM
    //PointAttributes vanderWaalsPointAttributes;
    //PointAttributes hydrophobicPointAttributes;
    
    NormalGenerator normalGenerator = new NormalGenerator();




    public Interaction3DContainer(NBInteractionContainer container)
    {
		this.container = container;
		hydrogenBondNodes = new Hashtable();
		electrostaticNodes = new Hashtable();
		stackingNodes = new Hashtable();
		vanderWaalsNodes = new Hashtable();		//LRM
		hydrophobicNodes = new Hashtable();		//LRM
		
		hydrogenBondLineAttributes = new LineAttributes(thickness,LineAttributes.PATTERN_DASH,true);
		electrostaticLineAttributes = new LineAttributes(thickness,LineAttributes.PATTERN_DASH_DOT,true);
		
		//vanderWaalsLineAttributes = new LineAttributes(thickness, LineAttributes.PATTERN_DASH,true);		//LRM
		//hydrophobicLineAttributes = new LineAttributes(thickness, LineAttributes.PATTERN_DASH,true);		//LRM
		//vanderWaalsPointAttributes = new PointAttributes(25f, false);
		//hydrophobicPointAttributes = new PointAttributes(25f, false);
		
		hydrogenBondAppearance.setLineAttributes(hydrogenBondLineAttributes);
		electrostaticAppearance.setLineAttributes(electrostaticLineAttributes);
		
		//vanderWaalsAppearance.setLineAttributes(vanderWaalsLineAttributes);		//LRM
		//hydrophobicAppearance.setLineAttributes(hydrophobicLineAttributes);		//LRM
		//vanderWaalsAppearance.setPointAttributes(vanderWaalsPointAttributes);
		//hydrophobicAppearance.setPointAttributes(hydrophobicPointAttributes);
		
		//vanderWaalsAppearance.setTransparencyAttributes(new TransparencyAttributes(TransparencyAttributes.BLENDED, .6f));
		//hydrophobicAppearance.setTransparencyAttributes(new TransparencyAttributes(TransparencyAttributes.BLENDED, .6f));
		
		PolygonAttributes stackingAttributes = new PolygonAttributes();
		stackingAttributes.setCullFace(PolygonAttributes.CULL_NONE);
		stackingAppearance.setPolygonAttributes(stackingAttributes);
		
		try
		{
			String fileName = EntangleProperties.getProperties().getProperty("entangle.aromaticRingsFile");
			File aromaticRingsFile = new File(System.getProperty("user.dir") + File.separator + fileName);
			AromaticRingDOMParser parser = new AromaticRingDOMParser(aromaticRingsFile);
			rings = parser.getAromaticRings();
		}
		catch(Exception e)
		{
			e.printStackTrace(System.out);
		}
    }
    
    
    
    /**
     * buildHydrogenBondNodes builds a switch node for every group of hydrogen bonds
     * between two interacting residues. This switch node can switch from no children 
     * to some children
     */
    public void buildHydrogenBondNodes(Group root)
    {
		for(Enumeration e = container.getInteractingGroups().elements(); e.hasMoreElements();)
		{
			InteractingGroup currentGroup = (InteractingGroup)e.nextElement();
			Residue nucleicAcidResidue = currentGroup.getNucleicAcidResidue();
			Vector hydrogenBondsInGroup = currentGroup.getHydrogenBonds();
			
			for(Enumeration proteinResidues = currentGroup.getInteractingProteinResidues().elements();
				proteinResidues.hasMoreElements();)
			{
				Residue proteinResidue = (Residue)proteinResidues.nextElement();
				Vector hydrogenBonds = new Vector();
				
				for(Iterator iterator = hydrogenBondsInGroup.iterator(); iterator.hasNext();)
				{
					HydrogenBond hydrogenBond = (HydrogenBond)iterator.next();
					
					if(proteinResidue.containsAtom(hydrogenBond.getDonor())|| proteinResidue.containsAtom(hydrogenBond.getAcceptor()))
					   hydrogenBonds.add(hydrogenBond);
				}
				
				Shape3D hydrogenBonds3D = getHydrogenBondsShape(hydrogenBonds);
				
				if(hydrogenBonds3D!=null)
				{
					Switch hydrogenBondsSwitch = new Switch(Switch.CHILD_MASK);
    	  			hydrogenBondsSwitch.setCapability(Switch.ALLOW_SWITCH_WRITE);
					hydrogenBondsSwitch.addChild(hydrogenBonds3D);
					hydrogenBondsSwitch.setWhichChild(Switch.CHILD_NONE);
					
					hydrogenBondNodes.put(Integer.toString(nucleicAcidResidue.getResidueSequenceNumber())+
						Integer.toString(proteinResidue.getResidueSequenceNumber()), hydrogenBondsSwitch);
					root.addChild(hydrogenBondsSwitch);
				}
			}
		}
    }



    /**
     * buildEINodes builds a switch node for every group of electrostatic interactions
     * between two interacting residues. This switch node can switch from showing 
     * no interactions to showing the interactions
     */
    public void buildEINodes(Group root)
    {
		for(Enumeration e = container.getInteractingGroups().elements(); e.hasMoreElements();)
		{
			InteractingGroup currentGroup = (InteractingGroup)e.nextElement();
			Residue nucleicAcidResidue = currentGroup.getNucleicAcidResidue();
			Vector electrostaticInteractionsInGroup = currentGroup.getElectrostaticInteractions();
			for(Enumeration proteinResidues = currentGroup.getInteractingProteinResidues().elements();
				proteinResidues.hasMoreElements();)
			{
				Residue proteinResidue = (Residue)proteinResidues.nextElement();
				Vector electrostaticInteractions = new Vector();
				
				for(Iterator iterator = electrostaticInteractionsInGroup.iterator(); iterator.hasNext();)
				{
					ElectrostaticInteraction electrostaticInteraction = (ElectrostaticInteraction)iterator.next();
					
					if(proteinResidue.containsAtom(electrostaticInteraction.getPositiveAtom())||
					   proteinResidue.containsAtom(electrostaticInteraction.getNegativeAtom()))
					   	electrostaticInteractions.add(electrostaticInteraction);
				}
				
				Shape3D electrostatics3D = getElectrostaticsShape(electrostaticInteractions);
				
				if(electrostatics3D != null)
				{
					Switch eiSwitch = new Switch(Switch.CHILD_MASK);
    	  			eiSwitch.setCapability(Switch.ALLOW_SWITCH_WRITE);
					eiSwitch.addChild(electrostatics3D);
					eiSwitch.setWhichChild(Switch.CHILD_NONE);
					
					electrostaticNodes.put(Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) +
						Integer.toString(proteinResidue.getResidueSequenceNumber()), eiSwitch);
					root.addChild(eiSwitch);
				}
			}
		}
    }
    
    
    
    
    
    
    
    /**
     * buildVanderWaalsNodes builds a switch node for every group of vanderwaals interactions
     * between two interacting residues. This switch node can switch from showing 
     * no interactions to showing the interactions
     */
    public void buildVanderWaalsNodes(Group root)
    {
		for(Enumeration e = container.getInteractingGroups().elements(); e.hasMoreElements();)
		{
			InteractingGroup currentGroup = (InteractingGroup)e.nextElement();
			Residue nucleicAcidResidue = currentGroup.getNucleicAcidResidue();
			Vector vanderWaalsInteractionsInGroup = currentGroup.getVanderWaalsInteractions();
			for(Enumeration proteinResidues = currentGroup.getInteractingProteinResidues().elements();
				proteinResidues.hasMoreElements();)
			{
				Residue proteinResidue = (Residue)proteinResidues.nextElement();
				Vector vanderWaalsInteractions = new Vector();
				
				for(Iterator iterator = vanderWaalsInteractionsInGroup.iterator(); iterator.hasNext();)
				{
					VanderWaalsInteraction vanderWaalsInteraction = (VanderWaalsInteraction)iterator.next();
					
					if(proteinResidue.containsAtom(vanderWaalsInteraction.getAtomA())||
					   proteinResidue.containsAtom(vanderWaalsInteraction.getAtomB()))
					   	vanderWaalsInteractions.add(vanderWaalsInteraction);
				}
				
				javax.media.j3d.Group vanderWaals3D = getVanderWaalsGroup(vanderWaalsInteractions);
				
				if(vanderWaals3D != null)
				{
					Switch eiSwitch = new Switch(Switch.CHILD_MASK);
    	  			eiSwitch.setCapability(Switch.ALLOW_SWITCH_WRITE);
					eiSwitch.addChild(vanderWaals3D);
					eiSwitch.setWhichChild(Switch.CHILD_NONE);
					
					vanderWaalsNodes.put(Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) +
						Integer.toString(proteinResidue.getResidueSequenceNumber()), eiSwitch);
					root.addChild(eiSwitch);
				}
			}
		}
    }
    
    /**
     * buildHydrophobicNodes builds a switch node for every group of hydrophobic interactions
     * between two interacting residues. This switch node can switch from showing 
     * no interactions to showing the interactions
     */
    public void buildHydrophobicNodes(Group root)
    {
		for(Enumeration e = container.getInteractingGroups().elements(); e.hasMoreElements();)
		{
			InteractingGroup currentGroup = (InteractingGroup)e.nextElement();
			Residue nucleicAcidResidue = currentGroup.getNucleicAcidResidue();
			Vector hydrophobicInteractionsInGroup = currentGroup.getHydrophobicInteractions();
			for(Enumeration proteinResidues = currentGroup.getInteractingProteinResidues().elements();
				proteinResidues.hasMoreElements();)
			{
				Residue proteinResidue = (Residue)proteinResidues.nextElement();
				Vector hydrophobicInteractions = new Vector();
				
				for(Iterator iterator = hydrophobicInteractionsInGroup.iterator(); iterator.hasNext();)
				{
					HydrophobicInteraction hydrophobicInteraction = (HydrophobicInteraction)iterator.next();
					
					if(proteinResidue.containsAtom(hydrophobicInteraction.getNonPolarAtomA())||
					   proteinResidue.containsAtom(hydrophobicInteraction.getNonPolarAtomB()))
					   	hydrophobicInteractions.add(hydrophobicInteraction);
				}
				
				javax.media.j3d.Group hydrophobic3D = getHydrophobicGroup(hydrophobicInteractions);
				
				if(hydrophobic3D != null)
				{
					Switch eiSwitch = new Switch(Switch.CHILD_MASK);
    	  			eiSwitch.setCapability(Switch.ALLOW_SWITCH_WRITE);
					eiSwitch.addChild(hydrophobic3D);
					eiSwitch.setWhichChild(Switch.CHILD_NONE);
					
					hydrophobicNodes.put(Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) +
						Integer.toString(proteinResidue.getResidueSequenceNumber()), eiSwitch);
					root.addChild(eiSwitch);
				}
			}
		}
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
	/**
   	 * buildStackNodes builds a switch node for every stacking interaction
   	 * between two interacting residues. This switch node can switch from showing 
	 * no interactions to showing the interactions
   	 */
    public void buildStackNodes(Group root)
    {
		for(Iterator stackingIterator = container.getStackingInteractions().iterator(); stackingIterator.hasNext();)
		{
			StackingInteraction stackingInteraction = (StackingInteraction)stackingIterator.next();
			Residue residueA = stackingInteraction.getResidueA();
			Residue residueB = stackingInteraction.getResidueB();
			Residue proteinResidue = null;
			Residue nucleicAcidResidue = null;
			
			if(residueA.getParentMacromolecule().getType().equals(Macromolecule.PROTEIN))
			{
				proteinResidue = residueA;
				nucleicAcidResidue = residueB;
			}
			else
			{
				nucleicAcidResidue = residueA;
				proteinResidue = residueB;
			}
			
			TransformGroup stackingNode = buildStackingGroup(nucleicAcidResidue, proteinResidue);
			
			if(stackingNode != null)
			{
				Switch stackingSwitch = new Switch(Switch.CHILD_MASK);
      			stackingSwitch.setCapability(Switch.ALLOW_SWITCH_WRITE);
				stackingSwitch.addChild(stackingNode);
				stackingSwitch.setWhichChild(Switch.CHILD_NONE);
				
				stackingNodes.put(Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) +
					Integer.toString(proteinResidue.getResidueSequenceNumber()), stackingSwitch);
				root.addChild(stackingSwitch);
			}
		}
	}
	
	
	
	public void setVisibilityOfInteractions(InteractingGroup interactingGroup,boolean isVisible)
	{
		Residue nucleicAcidResidue = interactingGroup.getNucleicAcidResidue();
		
		for(Enumeration proteinEnumeration = interactingGroup.getInteractingProteinResidues().elements(); proteinEnumeration.hasMoreElements();)
		{
			Residue proteinResidue = (Residue)proteinEnumeration.nextElement();
			setVisibilityOfInteractions(nucleicAcidResidue, proteinResidue, isVisible);
		}
	}
	
	
    public void setVisibilityOfInteractions(Residue nucleicAcidResidue, Residue proteinResidue, boolean isVisible)
    {
		String key = Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) + 
		     Integer.toString(proteinResidue.getResidueSequenceNumber());
		Switch hydrogenBondSwitch = (Switch)hydrogenBondNodes.get(key);
		Switch electrostaticSwitch = (Switch)electrostaticNodes.get(key);
		Switch stackingSwitch = (Switch)stackingNodes.get(key);
		Switch hydrophobicSwitch = (Switch)hydrophobicNodes.get(key);		//LRM
		Switch vanderWaalsSwitch = (Switch)vanderWaalsNodes.get(key);		//LRM
		
		if(isVisible)
		{
			if(hydrogenBondSwitch!=null)
				hydrogenBondSwitch.setWhichChild(0);
			if(electrostaticSwitch!=null)
				electrostaticSwitch.setWhichChild(0);
			if(stackingSwitch!=null)
				stackingSwitch.setWhichChild(0);
			if(hydrophobicSwitch!=null)
				hydrophobicSwitch.setWhichChild(0);
			if(vanderWaalsSwitch!=null)
				vanderWaalsSwitch.setWhichChild(0);
		}
		else
		{
			if(hydrogenBondSwitch!=null)
				hydrogenBondSwitch.setWhichChild(Switch.CHILD_NONE);
			if(electrostaticSwitch!=null)
				electrostaticSwitch.setWhichChild(Switch.CHILD_NONE);
			if(stackingSwitch!=null)
				stackingSwitch.setWhichChild(Switch.CHILD_NONE);
			if(hydrophobicSwitch!=null)
				hydrophobicSwitch.setWhichChild(Switch.CHILD_NONE);
			if(vanderWaalsSwitch!=null)
				vanderWaalsSwitch.setWhichChild(Switch.CHILD_NONE);
		}
    }


	////////////////////////////////////////////////////////////////////////////////////////
	// CODE BELOW ADDED BY LRM TO IMPLEMENT THE INTERACTIONS MENU ON THE 3D DISPLAY ////////
	////////////////////////////////////////////////////////////////////////////////////////

	public void setVisibilityOfHydrogenBonds(InteractingGroup interactingGroup, boolean isVisible)
	{
		Residue nucleicAcidResidue = interactingGroup.getNucleicAcidResidue();
		
		for(Enumeration proteinEnumeration = interactingGroup.getInteractingProteinResidues().elements(); proteinEnumeration.hasMoreElements(); )
		{
			Residue proteinResidue = (Residue)proteinEnumeration.nextElement();
			
			String key = Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) + 
		    											Integer.toString(proteinResidue.getResidueSequenceNumber());
			Switch hydrogenBondSwitch = (Switch)hydrogenBondNodes.get(key);
			
			if(isVisible)
			{
				if(hydrogenBondSwitch!=null)
					hydrogenBondSwitch.setWhichChild(0);
			}
			else
			{
				if(hydrogenBondSwitch!=null)
					hydrogenBondSwitch.setWhichChild(Switch.CHILD_NONE);
			}
		}
	}
	
	public void setVisibilityOfElectrostaticInteractions(InteractingGroup interactingGroup, boolean isVisible)
	{
		Residue nucleicAcidResidue = interactingGroup.getNucleicAcidResidue();
		
		for(Enumeration proteinEnumeration = interactingGroup.getInteractingProteinResidues().elements(); proteinEnumeration.hasMoreElements(); )
		{
			Residue proteinResidue = (Residue)proteinEnumeration.nextElement();
			
			String key = Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) + 
		    											Integer.toString(proteinResidue.getResidueSequenceNumber());
			Switch electrostaticSwitch = (Switch)electrostaticNodes.get(key);
			
			if(isVisible)
			{
				if(electrostaticSwitch!=null)
					electrostaticSwitch.setWhichChild(0);
			}
			else
			{
				if(electrostaticSwitch!=null)
					electrostaticSwitch.setWhichChild(Switch.CHILD_NONE);
			}
		}
	}
	
	public void setVisibilityOfStackingInteractions(InteractingGroup interactingGroup, boolean isVisible)
	{
		Residue nucleicAcidResidue = interactingGroup.getNucleicAcidResidue();
		
		for(Enumeration proteinEnumeration = interactingGroup.getInteractingProteinResidues().elements(); proteinEnumeration.hasMoreElements(); )
		{
			Residue proteinResidue = (Residue)proteinEnumeration.nextElement();
			
			String key = Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) + 
		    											Integer.toString(proteinResidue.getResidueSequenceNumber());
			Switch stackingSwitch = (Switch)stackingNodes.get(key);
			
			if(isVisible)
			{
				if(stackingSwitch!=null)
					stackingSwitch.setWhichChild(0);
			}
			else
			{
				if(stackingSwitch!=null)
					stackingSwitch.setWhichChild(Switch.CHILD_NONE);
			}
		}
	}
	
	public void setVisibilityOfHydrophobicInteractions(InteractingGroup interactingGroup, boolean isVisible)
	{
		Residue nucleicAcidResidue = interactingGroup.getNucleicAcidResidue();
		
		for(Enumeration proteinEnumeration = interactingGroup.getInteractingProteinResidues().elements(); proteinEnumeration.hasMoreElements(); )
		{
			Residue proteinResidue = (Residue)proteinEnumeration.nextElement();
			
			String key = Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) + 
		    											Integer.toString(proteinResidue.getResidueSequenceNumber());
			Switch hydrophobicSwitch = (Switch)hydrophobicNodes.get(key);
			
			if(isVisible)
			{
				if(hydrophobicSwitch!=null)
					hydrophobicSwitch.setWhichChild(0);
			}
			else
			{
				if(hydrophobicSwitch!=null)
					hydrophobicSwitch.setWhichChild(Switch.CHILD_NONE);
			}
		}
	}
	
	public void setVisibilityOfVanderWaalsInteractions(InteractingGroup interactingGroup, boolean isVisible)
	{
		Residue nucleicAcidResidue = interactingGroup.getNucleicAcidResidue();
		
		for(Enumeration proteinEnumeration = interactingGroup.getInteractingProteinResidues().elements(); proteinEnumeration.hasMoreElements(); )
		{
			Residue proteinResidue = (Residue)proteinEnumeration.nextElement();
			
			String key = Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) + 
		    											Integer.toString(proteinResidue.getResidueSequenceNumber());
			Switch vanderWaalsSwitch = (Switch)vanderWaalsNodes.get(key);
			
			if(isVisible)
			{
				if(vanderWaalsSwitch!=null)
					vanderWaalsSwitch.setWhichChild(0);
			}
			else
			{
				if(vanderWaalsSwitch!=null)
					vanderWaalsSwitch.setWhichChild(Switch.CHILD_NONE);
			}
		}
	}
	/////////////////////////////////////////////////////////
	// END OF LRM ADDED CODE ///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////


    public void setVisibilityOfInteractions(Residue nucleicAcidResidue, Residue proteinResidue, boolean isVisible, int interactionsType)
    {
		String key = Integer.toString(nucleicAcidResidue.getResidueSequenceNumber()) +
			        Integer.toString(proteinResidue.getResidueSequenceNumber());
		Switch mySwitch = null;
		
		switch(interactionsType)
		{
			case HYDROGEN_BOND:
				mySwitch = (Switch)hydrogenBondNodes.get(key);
				break;
			case ELECTROSTATIC_INTERACTION:
				mySwitch = (Switch)electrostaticNodes.get(key);
				break;
			case STACKING_INTERACTION:
				mySwitch = (Switch)stackingNodes.get(key); 
				break;
			default:
				break;
		}
		
		if(isVisible && mySwitch!=null)
		{
			mySwitch.setWhichChild(0);
		}
		else
		{
			mySwitch.setWhichChild(Switch.CHILD_NONE);
		}
    }
    
    
    /**
     * switches the visibility of the EI node, it does this by grabbing
     * the EI switch and switching the child to none
     */
    public void setVisibilityOfElectrostaticInteractions(Residue nucleicAcidResidue, Residue proteinResidue, boolean isVisible)
    {
		setVisibilityOfInteractions(nucleicAcidResidue,proteinResidue, isVisible,ELECTROSTATIC_INTERACTION);
    }


    /**
     * switches the visibility of the hydrogen bond node, it does this by grabbing
     * the hydrogen bond switch and switching the child to none
     */
    public void setVisibilityOfHydrogenBonds(Residue nucleicAcidResidue, Residue proteinResidue, boolean isVisible)
    {
		setVisibilityOfInteractions(nucleicAcidResidue,proteinResidue, isVisible,HYDROGEN_BOND);
    }
    

    /**
     * builds a shape3D which include a line array of hydrogen bonds and its 
     * appearance
     */
    public Shape3D getElectrostaticsShape(Vector electrostaticInteractions)
    {
		LineArray lineArray = null;
		Shape3D electrostatics3D = null;
		
		if(electrostaticInteractions.size()!=0)
		{
		    lineArray = new LineArray(electrostaticInteractions.size()*2, GeometryArray.COORDINATES|GeometryArray.COLOR_3);
		    int index = 0;
		    
		    for(Enumeration e2 = electrostaticInteractions.elements(); e2.hasMoreElements();)
			{
				ElectrostaticInteraction tempElectrostaticInteraction = (ElectrostaticInteraction)e2.nextElement();
				Atom positive = tempElectrostaticInteraction.getPositiveAtom();
				Atom negative = tempElectrostaticInteraction.getNegativeAtom();
				Point3d postivePoint = new Point3d(positive.getX(),positive.getY(),positive.getZ());
				Point3d negativePoint = new Point3d(negative.getX(),negative.getY(),negative.getZ());
				lineArray.setColor(index,red);
				lineArray.setCoordinate(index,postivePoint);
				index++;
				lineArray.setColor(index,red);
				lineArray.setCoordinate(index,negativePoint);
				index++;
	   		}
	   		
	    	electrostatics3D = new Shape3D(lineArray,hydrogenBondAppearance);
		}
		
		return electrostatics3D;
    }

    /**
     * builds two polygons to indicate the aromatic rings involved in the 
     * stacking interaction and outputs these polygons tucked away 
     * inside a TransformGroup
     */
    public TransformGroup buildStackingGroup(Residue nucleicAcidResidue,Residue proteinResidue)
	{
		TransformGroup transformGroup = new TransformGroup();
		GeometryInfo nucleicAcidInfo = new GeometryInfo(GeometryInfo.POLYGON_ARRAY);
		GeometryArray nucleicAcidPolygon;
		GeometryInfo proteinResidueInfo = new GeometryInfo(GeometryInfo.POLYGON_ARRAY);
		GeometryArray proteinPolygon;
		Vector nucleicAcidRingMembers = (Vector)rings.get(nucleicAcidResidue.getResName());
		Vector proteinRingMembers = (Vector)rings.get(proteinResidue.getResName());
		
		// construct nucleic acid ring polygon
		Point3d[] nucleicAcidRingPoints = new Point3d[nucleicAcidRingMembers.size()];
		Color3f[] nucleicAcidColors = new Color3f[nucleicAcidRingMembers.size()];
		
		for(int i=0;i<nucleicAcidRingPoints.length;i++)
		{
			Atom tempAtom = nucleicAcidResidue.getAtom((String)nucleicAcidRingMembers.get(i));
			nucleicAcidRingPoints[i] = new Point3d(tempAtom.getX(),tempAtom.getY(),tempAtom.getZ());
			nucleicAcidColors[i] = lightOrange;
		}
		
		int[] nucleicAcidStripCounts = { nucleicAcidRingMembers.size()};
		nucleicAcidInfo.setStripCounts(nucleicAcidStripCounts);
		nucleicAcidInfo.setCoordinates(nucleicAcidRingPoints);
		nucleicAcidInfo.setColors(nucleicAcidColors);
		normalGenerator.generateNormals(nucleicAcidInfo);
		nucleicAcidPolygon = nucleicAcidInfo.getGeometryArray();
		
		// construct protein ring polygon
		Point3d[] proteinRingPoints = new Point3d[proteinRingMembers.size()];
		Color3f[] proteinColors = new Color3f[proteinRingMembers.size()];
		
		for(int j=0;j<proteinRingPoints.length;j++)
		{
			Atom tempAtom = proteinResidue.getAtom((String)proteinRingMembers.get(j));
			proteinRingPoints[j] = new Point3d(tempAtom.getX(),tempAtom.getY(),tempAtom.getZ());
			proteinColors[j] = lightOrange;
		}
		
		int[] proteinStripCounts = { proteinRingMembers.size()};
		proteinResidueInfo.setStripCounts(proteinStripCounts);
		proteinResidueInfo.setCoordinates(proteinRingPoints);
		proteinResidueInfo.setColors(proteinColors);
		normalGenerator.generateNormals(proteinResidueInfo);
		proteinPolygon = proteinResidueInfo.getGeometryArray();
	
		Shape3D nucleicAcidShape = new Shape3D(nucleicAcidPolygon,stackingAppearance);
		Shape3D proteinShape = new Shape3D(proteinPolygon,stackingAppearance);
		
		transformGroup.addChild(nucleicAcidShape);
		transformGroup.addChild(proteinShape);
		
		return transformGroup;
    }

    /**
     * builds a shape3D which include a line array of hydrogen bonds and its 
     * appearance
     */
    public Shape3D getHydrogenBondsShape(Vector hydrogenBonds)
    {
		LineArray lineArray = null;
		Shape3D hydrogenBonds3D = null;
		
		if(hydrogenBonds.size()!=0)
		{
		    lineArray = new LineArray(hydrogenBonds.size()*2, GeometryArray.COORDINATES|GeometryArray.COLOR_3);
		    int index = 0;
		    
		    for(Enumeration e2 = hydrogenBonds.elements(); e2.hasMoreElements();)
		    {
				HydrogenBond tempHydrogenBond = (HydrogenBond)e2.nextElement();
				Atom donor = tempHydrogenBond.getDonor();
				Atom acceptor = tempHydrogenBond.getAcceptor();
				Point3d donorPoint = new Point3d(donor.getX(),donor.getY(),donor.getZ());
				Point3d acceptorPoint = new Point3d(acceptor.getX(),acceptor.getY(),acceptor.getZ());
				lineArray.setColor(index,yellow);
				lineArray.setCoordinate(index,donorPoint);
				index++;
				lineArray.setColor(index,yellow);
				lineArray.setCoordinate(index,acceptorPoint);
				index++;
	    	}
	    
	    	hydrogenBonds3D = new Shape3D(lineArray,hydrogenBondAppearance);
		}
	
	return hydrogenBonds3D;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    /**
     * builds a group which include hydrophobic bond atoms and its 
     * appearance
     */
    public javax.media.j3d.Group getHydrophobicGroup(Vector interactions)
    {
		javax.media.j3d.Group hydrophobicGroup = new javax.media.j3d.Group();


		if(interactions.size()!=0)
		{
			Appearance atomAAppearance = new Appearance();
			//atomAAppearance.setColoringAttributes(new ColoringAttributes(purple, ColoringAttributes.NICEST));
			atomAAppearance.setTransparencyAttributes(new TransparencyAttributes(TransparencyAttributes.SCREEN_DOOR, .5f));
			atomAAppearance.setMaterial(new Material(new Color3f(.2f,0f,.1f),new Color3f(0f,0f,0f),new Color3f(1f,0f,.5f),new Color3f(1f,0f,.5f), 64f));
			
			
			Appearance atomBAppearance = new Appearance();
			//atomBAppearance.setColoringAttributes(new ColoringAttributes(lightGreen, ColoringAttributes.NICEST));
			atomBAppearance.setTransparencyAttributes(new TransparencyAttributes(TransparencyAttributes.SCREEN_DOOR, .5f));
			atomBAppearance.setMaterial(new Material(new Color3f(.1f,.14f,.1f),new Color3f(0f,0f,0f),new Color3f(.5f,.7f,.5f),new Color3f(.5f,.7f,.5f), 64f));
			
			
		    for(Enumeration e2 = interactions.elements(); e2.hasMoreElements();)
		    {
				HydrophobicInteraction tempHydrophobicInteraction = (HydrophobicInteraction)e2.nextElement();
				
				Atom a = tempHydrophobicInteraction.getNonPolarAtomA();
				Vector3d aVector = new Vector3d(a.getX(),a.getY(),a.getZ());
				
				Transform3D		aTransform = new Transform3D();
				aTransform.set(aVector); 	// Sets the transform to translate to the coordinates in aVector
				
				TransformGroup 	atomAGroup = new TransformGroup(aTransform);   	//javax.media.j3d.TransformGroup holds a translation
																				// which is applied to all its children
				Sphere aSphere = new Sphere(SPHERE_RADIUS, atomAAppearance);
				atomAGroup.addChild(aSphere);
				
				
				
				Atom b = tempHydrophobicInteraction.getNonPolarAtomB();
				Vector3d bVector = new Vector3d(b.getX(),b.getY(),b.getZ());
				
				Transform3D		bTransform = new Transform3D();
				bTransform.set(bVector); 	// Sets the transform to translate to the coordinates in aVector
				
				TransformGroup 	atomBGroup = new TransformGroup(bTransform);   	//javax.media.j3d.TransformGroup holds a translation
																				// which is applied to all its children
				Sphere bSphere = new Sphere(SPHERE_RADIUS, atomBAppearance);
				atomBGroup.addChild(bSphere);
				
				
				hydrophobicGroup.addChild(atomAGroup);
				hydrophobicGroup.addChild(atomBGroup);
	    	}
		}
	
	return hydrophobicGroup;
    }
    
    
    /**
     * builds a group which include a vanderwaals bond atoms and its 
     * appearance
     */
    public javax.media.j3d.Group getVanderWaalsGroup(Vector interactions)
    {
		javax.media.j3d.Group vdwGroup = new javax.media.j3d.Group();


		if(interactions.size()!=0)
		{
			RenderingAttributes ra = new RenderingAttributes();
			//ra.setDepthBufferWriteEnable(false); // true default
			//ra.setAlphaTestFunction(RenderingAttributes.GREATER); // .ALWAYS default
			//ra.setAlphaTestValue( .5f ); // 0 default
			
			Appearance atomAAppearance = new Appearance();
			//atomAAppearance.setColoringAttributes(new ColoringAttributes(orange, ColoringAttributes.NICEST));
			atomAAppearance.setTransparencyAttributes(new TransparencyAttributes(TransparencyAttributes.SCREEN_DOOR, .5f));
			atomAAppearance.setMaterial(new Material(new Color3f(.2f,.1f,0f),new Color3f(0f,0f,0f),new Color3f(1f,.5f,0f),new Color3f(1f,.5f,0f), 64f));
			
			atomAAppearance.setRenderingAttributes(ra);
			
			Appearance atomBAppearance = new Appearance();
			//atomBAppearance.setColoringAttributes(new ColoringAttributes(yellow, ColoringAttributes.NICEST));
			atomBAppearance.setTransparencyAttributes(new TransparencyAttributes(TransparencyAttributes.SCREEN_DOOR, .5f));
			atomBAppearance.setMaterial(new Material(new Color3f(.2f,.2f,0f),new Color3f(0f,0f,0f),new Color3f(1f,1f,0f),new Color3f(1f,1f,0f), 64f));
			
			atomBAppearance.setRenderingAttributes(ra);
			
		    for(Enumeration e2 = interactions.elements(); e2.hasMoreElements();)
		    {
				VanderWaalsInteraction tempVanderWaalsInteraction = (VanderWaalsInteraction)e2.nextElement();
				
				Atom a = tempVanderWaalsInteraction.getAtomA();
				Vector3d aVector = new Vector3d(a.getX(),a.getY(),a.getZ());
				
				Transform3D		aTransform = new Transform3D();
				aTransform.set(aVector); 	// Sets the transform to translate to the coordinates in aVector
				
				TransformGroup 	atomAGroup = new TransformGroup(aTransform);   	//javax.media.j3d.TransformGroup holds a translation
																				// which is applied to all its children
				Sphere aSphere = new Sphere(SPHERE_RADIUS, atomAAppearance);
				atomAGroup.addChild(aSphere);
				
				
				Atom b = tempVanderWaalsInteraction.getAtomB();
				Vector3d bVector = new Vector3d(b.getX(),b.getY(),b.getZ());
				
				Transform3D		bTransform = new Transform3D();
				bTransform.set(bVector); 	// Sets the transform to translate to the coordinates in aVector
				
				TransformGroup 	atomBGroup = new TransformGroup(bTransform);   	//javax.media.j3d.TransformGroup holds a translation
																				// which is applied to all its children
				Sphere bSphere = new Sphere(SPHERE_RADIUS, atomBAppearance);
				atomBGroup.addChild(bSphere);
				
				
				vdwGroup.addChild(atomAGroup);
				vdwGroup.addChild(atomBGroup);
	    	}
		}
	
	return vdwGroup;
    }
}