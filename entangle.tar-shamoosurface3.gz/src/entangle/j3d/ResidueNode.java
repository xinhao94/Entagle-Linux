/*
 * ResidueNode.java
 *
 * Created on October 25, 2000, 9:55 AM
 */


///////////////////////////////////////////////////////////////////////
/////// NOTE -> LINE WIDTH FOR EVERYTHING IS SET ON LINE ~498 /////////
///////////////////////////////////////////////////////////////////////

package entangle.j3d;
import java.util.Enumeration;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.GeometryArray;
import javax.media.j3d.Group;
import javax.media.j3d.LineArray;
import javax.media.j3d.LineAttributes;
import javax.media.j3d.Link;
import javax.media.j3d.Node;
import javax.media.j3d.RenderingAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.SharedGroup;
import javax.media.j3d.Switch;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;

import entangle.datastructures.Atom;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.Residue;
import entangle.datastructures.ResidueStructure;


/**
 *	ResidueNode contains a number of branch groups which represent switching
 *      from a fully rendered residue to just a backbone
 * @author  Jim Allers
 * @version 
 */
public class ResidueNode extends BranchGroup 
{
	Switch mySwitch;
	ResidueStructure residueStructure;
	BranchGroup fullyRenderedBeforeBackboneNode;
	BranchGroup backboneBeforeBackboneNode;
	BranchGroup fullyRenderedBeforeFullyRenderedNode;
	BranchGroup backboneBeforeFullyRenderedNode;
	
	static final int NEXT_RESIDUE_IS_BACKBONE_ONLY = 0;
	static final int NEXT_RESIDUE_IS_FULLY_RENDERED = 1;
	static final int BOTH_FULLY_RENDERED = 2;
	static final int FULLY_RENDERED_BUT_NEXT_RESIDUE_IS_JUST_BACKBONE = 3;
	static final int DO_NOT_RENDER = 4;
	boolean isFullyRendered = false;
	
	final Residue thisResidue;
	
	
	
    /** Creates new ClassName */
    public ResidueNode(Residue residue)
    {
    	thisResidue = residue;
    	
		setCapability(Group.ALLOW_CHILDREN_READ);
		setCapability(Group.ALLOW_CHILDREN_WRITE);
		setCapability(Group.ALLOW_CHILDREN_EXTEND);
		setCapability(BranchGroup.ALLOW_DETACH);
		mySwitch = new Switch(Switch.CHILD_MASK);
		mySwitch.setCapability(Switch.ALLOW_SWITCH_WRITE);
		residueStructure = residue.getParentMacromolecule().getResidueStructure(residue);
		buildPossibleChildren(residue);
		mySwitch.setWhichChild(NEXT_RESIDUE_IS_BACKBONE_ONLY);
		addChild(mySwitch);
	}
	
	
	
	public boolean isFullyRendered()
	{
		return isFullyRendered;
	}
	
	
	
	/**
	 * Each residue is responsible for rendering itself and the connection to
	 * the next residue which in the minimal case is the same cylinder
	 */
	public void buildPossibleChildren(Residue residue)
	{
		SharedGroup backboneConnection = new SharedGroup();
		backboneConnection.addChild(buildBackboneConnectingBond(residue, residue.getParentMacromolecule()));
		SharedGroup nextResidueIsFullBackbone = new SharedGroup();
		nextResidueIsFullBackbone.addChild(nextResidueIsFullBackboneConnectingBond(residue, residue.getParentMacromolecule()));
		SharedGroup connection = new SharedGroup();
		connection.addChild(buildConnectingBond(residue, residue.getParentMacromolecule()));
		SharedGroup connectionFromFullToBackbone = new SharedGroup();
		connectionFromFullToBackbone.addChild(connectionFromFullyRenderedToBackbone(residue, residue.getParentMacromolecule()));
		SharedGroup fullResidue = buildResidue(residue);
		Link fullResidueLink = new Link(fullResidue);
		Link backboneLink = new Link(backboneConnection);
		
		//backbone-backbone
		backboneBeforeBackboneNode = new BranchGroup();
		backboneBeforeBackboneNode.setCapability(BranchGroup.ALLOW_DETACH);
		backboneBeforeBackboneNode.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
		backboneBeforeBackboneNode.addChild(new Link(backboneConnection));
		
		//backbone-full residue
		backboneBeforeFullyRenderedNode = new BranchGroup();
		backboneBeforeFullyRenderedNode.setCapability(BranchGroup.ALLOW_DETACH);
		backboneBeforeFullyRenderedNode.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
		backboneBeforeFullyRenderedNode.addChild(new Link(nextResidueIsFullBackbone));
			
		// full residue- full residue
		fullyRenderedBeforeFullyRenderedNode = new BranchGroup();
		fullyRenderedBeforeFullyRenderedNode.setCapability(BranchGroup.ALLOW_DETACH);
		fullyRenderedBeforeFullyRenderedNode.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
		fullyRenderedBeforeFullyRenderedNode.addChild(new Link(fullResidue));
		fullyRenderedBeforeFullyRenderedNode.addChild(new Link(connection));
		
		// full residue-backbone
		fullyRenderedBeforeBackboneNode = new BranchGroup();
		fullyRenderedBeforeBackboneNode.setCapability(BranchGroup.ALLOW_DETACH);
		fullyRenderedBeforeBackboneNode.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
		fullyRenderedBeforeBackboneNode.addChild(new Link(fullResidue));
		fullyRenderedBeforeBackboneNode.addChild(new Link(connectionFromFullToBackbone));
		
		mySwitch.insertChild(backboneBeforeBackboneNode,NEXT_RESIDUE_IS_BACKBONE_ONLY);
		mySwitch.insertChild(backboneBeforeFullyRenderedNode, NEXT_RESIDUE_IS_FULLY_RENDERED);
		mySwitch.insertChild(fullyRenderedBeforeFullyRenderedNode, BOTH_FULLY_RENDERED);
		mySwitch.insertChild(fullyRenderedBeforeBackboneNode, FULLY_RENDERED_BUT_NEXT_RESIDUE_IS_JUST_BACKBONE);
	}
	
	
	
	public void setRenderMode(int renderMode)
	{
		switch(renderMode)
		{
			case BOTH_FULLY_RENDERED:
				mySwitch.setWhichChild(BOTH_FULLY_RENDERED);
				isFullyRendered = true;
				break;
			case FULLY_RENDERED_BUT_NEXT_RESIDUE_IS_JUST_BACKBONE:
				mySwitch.setWhichChild(FULLY_RENDERED_BUT_NEXT_RESIDUE_IS_JUST_BACKBONE);
				isFullyRendered = true;
				break;
			case NEXT_RESIDUE_IS_BACKBONE_ONLY:
				mySwitch.setWhichChild(NEXT_RESIDUE_IS_BACKBONE_ONLY);
				isFullyRendered = false;
				break;
			case NEXT_RESIDUE_IS_FULLY_RENDERED:
				mySwitch.setWhichChild(NEXT_RESIDUE_IS_FULLY_RENDERED);
				isFullyRendered = false;
				break;
			case DO_NOT_RENDER:
				mySwitch.setWhichChild(Switch.CHILD_NONE);
				break;
			default:
				break;
		}
	}
	
	
	
	public Node connectionFromFullyRenderedToBackbone(Residue residue, Macromolecule macromolecule)
	{
		Node connectingBond = null;
		Vector lines = new Vector();
		
		if(macromolecule.containsNextResidue(residue))
		{
			Residue nextResidue = macromolecule.getNextResidue(residue);
			
			if(macromolecule.getType().equals(Macromolecule.PROTEIN))
			{
				Atom carbonAtom = residue.getAtom("C");
				Atom carbonAlphaAtom = nextResidue.getAtom("CA");
				
				if(carbonAtom!=null&&carbonAlphaAtom!=null)
				{
					Point3d carbonPoint = new Point3d(carbonAtom.getX(), carbonAtom.getY(), carbonAtom.getZ());
					Point3d carbonAlphaPoint = new Point3d(carbonAlphaAtom.getX(), carbonAlphaAtom.getY(), carbonAlphaAtom.getZ());
					Point3d midPoint = getMidPoint(carbonPoint, carbonAlphaPoint);
					
					LineInformation firstLine = new LineInformation(carbonPoint, midPoint,
						(Color3f)RenderTable.PatomColors.get(carbonAtom.getAtomType()));
					LineInformation secondLine = new LineInformation(carbonAlphaPoint, midPoint,
						(Color3f)RenderTable.PatomColors.get(carbonAtom.getAtomType()));
					
					lines.add(firstLine);
					lines.add(secondLine);
					
					connectingBond = constructLineGroup(lines);
				}
			}
			else
			{
				if(nextResidue.containsAtom("P") && residue.containsAtom("O3*"))
				{
					Atom oxygenAtom = residue.getAtom("O3*");
					Point3d oxygenPoint = new Point3d(oxygenAtom.getX(),oxygenAtom.getY(), oxygenAtom.getZ());
					
					Atom phosphorousAtom = nextResidue.getAtom("P");
					Point3d phosphorousPoint = new Point3d(phosphorousAtom.getX(), phosphorousAtom.getY(), phosphorousAtom.getZ());
					
					Point3d midPoint = getMidPoint(oxygenPoint, phosphorousPoint);
					
					LineInformation firstLine = new LineInformation(oxygenPoint, midPoint, 
						(Color3f)RenderTable.NAatomColors.get(oxygenAtom.getAtomType()));
					LineInformation secondLine = new LineInformation(midPoint, phosphorousPoint,
						(Color3f)RenderTable.NAatomColors.get(phosphorousAtom.getAtomType()));
						
					lines.add(firstLine);
					lines.add(secondLine);
					
					connectingBond = constructLineGroup(lines);
				}
			}
		}
		
		/*if(macromolecule.containsNextResidue(residue)){
			Residue nextResidue =
				macromolecule.getNextResidue(residue);
			if(macromolecule.getType().equals(Macromolecule.PROTEIN)){
				Atom carbonAtom = residue.getAtom("C");
				Atom nitrogenAtom = nextResidue.getAtom("CA");
				if(carbonAtom!=null&&nitrogenAtom!=null)
					connectingBond = new BondNode(carbonAtom,
								      nitrogenAtom,
				RenderTable.MINIMUM_PROTEIN_CONNECTION_COLOR);
			}else{
				if(nextResidue.containsAtom("P")
					&&residue.containsAtom("O3*")){
					Atom oxygenAtom = residue.getAtom("O3*");
					Atom phosphorousAtom = nextResidue.getAtom("P");
					connectingBond = 
						new BondNode(oxygenAtom,
							     phosphorousAtom,
				RenderTable.MINIMUM_PROTEIN_CONNECTION_COLOR);
				}//ends if
			}//ends if-else
		}//ends if */
		
		return connectingBond;
	}
	
	
	
	public Node buildConnectingBond(Residue residue, Macromolecule macromolecule)
	{
		Node connectingBond = null;
		Vector lines = new Vector();
        
        if(macromolecule.containsNextResidue(residue))
        {
	   	    Residue nextResidue = macromolecule.getNextResidue(residue);
			
			if(macromolecule.getType().equals(Macromolecule.PROTEIN))
			{
				Atom carbonAtom = residue.getAtom("C");
				Point3d carbonPoint = new Point3d(carbonAtom.getX(),carbonAtom.getY(), carbonAtom.getZ());
				Atom nitrogenAtom = nextResidue.getAtom("N");
				Point3d nitrogenPoint = new Point3d(nitrogenAtom.getX(),nitrogenAtom.getY(), nitrogenAtom.getZ());
				Point3d midPoint = getMidPoint(carbonPoint,nitrogenPoint);
				LineInformation firstLine = new LineInformation(carbonPoint,midPoint,
						(Color3f)RenderTable.PatomColors.get(carbonAtom.getAtomType()));
				LineInformation secondLine = new LineInformation(nitrogenPoint,midPoint,
						(Color3f)RenderTable.PatomColors.get(nitrogenAtom.getAtomType()));
				lines.add(firstLine);
				lines.add(secondLine);
				connectingBond = constructLineGroup(lines);
			}
			else
			{
				 if(nextResidue.containsAtom("P")&&residue.containsAtom("O3*"))
				 {
					Atom oxygenAtom = residue.getAtom("O3*");
					Point3d oxygenPoint = new Point3d(oxygenAtom.getX(),oxygenAtom.getY(), oxygenAtom.getZ());
					Atom phosphorousAtom = nextResidue.getAtom("P");
					Point3d phosphorousPoint = new Point3d(phosphorousAtom.getX(), phosphorousAtom.getY(), phosphorousAtom.getZ());
					Point3d midPoint = getMidPoint(oxygenPoint, phosphorousPoint);
					LineInformation firstLine = new LineInformation(oxygenPoint, midPoint,
							(Color3f)RenderTable.NAatomColors.get(oxygenAtom.getAtomType()));
					LineInformation secondLine = new LineInformation(midPoint, phosphorousPoint,
							(Color3f)RenderTable.NAatomColors.get(phosphorousAtom.getAtomType()));
					lines.add(firstLine);
					lines.add(secondLine);
					connectingBond = constructLineGroup(lines);
				}
			}
		}
		
		/*if(macromolecule.containsNextResidue(residue)){
			Residue nextResidue =
				macromolecule.getNextResidue(residue);
			if(macromolecule.getType().equals(Macromolecule.PROTEIN)){
				Atom carbonAtom = residue.getAtom("C");
				Atom nitrogenAtom = nextResidue.getAtom("N");
				if(carbonAtom!=null&&nitrogenAtom!=null)
					connectingBond = new BondNode(carbonAtom,
								      nitrogenAtom);
			}else{
				if(nextResidue.containsAtom("P")
					&&residue.containsAtom("O3*")){
					Atom oxygenAtom = residue.getAtom("O3*");
					Atom phosphorousAtom = nextResidue.getAtom("P");
					connectingBond = 
						new BondNode(oxygenAtom,
							     phosphorousAtom);
				}//ends if
			}//ends if-else
		}//ends if */
		
		return connectingBond;
	}
	
	
	
	public Node nextResidueIsFullBackboneConnectingBond(Residue residue, Macromolecule macromolecule)
	{
		Node connectingBond = null;
		Vector lines = new Vector();
		
		if(macromolecule.containsNextResidue(residue))
		{
			Residue nextResidue = macromolecule.getNextResidue(residue);
			
			if(macromolecule.getType().equals(Macromolecule.PROTEIN))
			{
				Atom carbonAlphaAtom = residue.getAtom("CA");
				Atom nitrogenAtom = nextResidue.getAtom("N");
				
				if(carbonAlphaAtom!=null&&nitrogenAtom!=null)
				{
					Point3d carbonAlphaAtomPoint = new Point3d(carbonAlphaAtom.getX(), carbonAlphaAtom.getY(), carbonAlphaAtom.getZ());
					Point3d nitrogenPoint = new Point3d(nitrogenAtom.getX(), nitrogenAtom.getY(), nitrogenAtom.getZ());
					Point3d midPoint = getMidPoint(carbonAlphaAtomPoint, nitrogenPoint);
					LineInformation firstLine = new LineInformation(carbonAlphaAtomPoint, midPoint,
						(Color3f)RenderTable.PatomColors.get(carbonAlphaAtom.getAtomType()));
					LineInformation secondLine = new LineInformation(nitrogenPoint,midPoint,
						(Color3f)RenderTable.PatomColors.get(nitrogenAtom.getAtomType()));
					lines.add(firstLine);
					lines.add(secondLine);
					connectingBond = constructLineGroup(lines);
				}
			}
			else
			{
				Atom phosphorousAtomA = residue.getAtom("P");
				Atom phosphorousAtomB = nextResidue.getAtom("P");
				
				if(nextResidue.containsAtom("P")&&residue.containsAtom("P"))
				{
					Point3d phosphorousPointA = new Point3d(phosphorousAtomA.getX(), phosphorousAtomA.getY(), phosphorousAtomA.getZ());
					Point3d phosphorousPointB = new Point3d(phosphorousAtomB.getX(), phosphorousAtomB.getY(), phosphorousAtomB.getZ());
					Point3d midPoint = getMidPoint(phosphorousPointA, phosphorousPointB);
					LineInformation line = new LineInformation(phosphorousPointA, phosphorousPointB, RenderTable.MINIMUM_NUCLEIC_ACID_CONNECTION_COLOR);
					lines.add(line);
					connectingBond = constructLineGroup(lines);
	   			 }
			}
		}
		  
		/*if(macromolecule.containsNextResidue(residue)){
			Residue nextResidue = 
				macromolecule.getNextResidue(residue);
			if(macromolecule.getType().equals(Macromolecule.PROTEIN)){
				Atom carbonAlphaAtom = residue.getAtom("CA");
				Atom nitrogenAtom = nextResidue.getAtom("N");
				if(carbonAlphaAtom!=null&&nitrogenAtom!=null)
					connectingBond = 
						new BondNode(carbonAlphaAtom,
							     nitrogenAtom,
					RenderTable.MINIMUM_PROTEIN_CONNECTION_COLOR);
			}else{
                            if(residue.containsAtom("P")&&nextResidue.containsAtom("P")){
				Atom phosphorousAtomA = residue.getAtom("P");
					Atom phosphorousAtomB = nextResidue.getAtom("P");
					connectingBond = new BondNode(
						phosphorousAtomA,phosphorousAtomB,
                                        RenderTable.MINIMUM_NUCLEIC_ACID_CONNECTION_COLOR);
                            }
			}//ends if-else
		}//ends if */
		
		return connectingBond;
	}



	public Node buildBackboneConnectingBond(Residue residue, Macromolecule macromolecule)
	{
		Node connectingBond = null;
		Vector lines = new Vector();
		
		if(macromolecule.containsNextResidue(residue))
		{
			Residue nextResidue = macromolecule.getNextResidue(residue);
			
			if(macromolecule.getType().equals(Macromolecule.PROTEIN))
			{
				Atom carbonAlphaAtomA = residue.getAtom("CA");
				Atom carbonAlphaAtomB = nextResidue.getAtom("CA");
	    		Point3d carbonAlphaAtomAPoint = new Point3d(carbonAlphaAtomA.getX(), carbonAlphaAtomA.getY(), carbonAlphaAtomA.getZ());
	    		Point3d carbonAlphaAtomBPoint = new Point3d(carbonAlphaAtomB.getX(), carbonAlphaAtomB.getY(), carbonAlphaAtomB.getZ());
	    		LineInformation line = new LineInformation(carbonAlphaAtomAPoint, carbonAlphaAtomBPoint,
						       RenderTable.MINIMUM_PROTEIN_CONNECTION_COLOR);
	   			lines.add(line);
				connectingBond = constructLineGroup(lines);
			}
			else
			{
				if(nextResidue.containsAtom("P") && residue.containsAtom("P"))
				{
					Atom phosphorousAtomA = residue.getAtom("P");
					Point3d phosphorousPointA = new Point3d(phosphorousAtomA.getX(), phosphorousAtomA.getY(), phosphorousAtomA.getZ());
					Atom phosphorousAtomB = nextResidue.getAtom("P");
					Point3d phosphorousPointB = new Point3d(phosphorousAtomB.getX(), phosphorousAtomB.getY(), phosphorousAtomB.getZ());
					LineInformation line = new LineInformation(phosphorousPointA, phosphorousPointB,
						RenderTable.MINIMUM_NUCLEIC_ACID_CONNECTION_COLOR);
					lines.add(line);
					connectingBond = constructLineGroup(lines);
				}
			}
		}
		
		return connectingBond;
	}
	
	
	

	/**
	 * builds a Java3D group containing all the residues and
	 *
	 */
	public SharedGroup buildResidue(Residue residue)
	{
		SharedGroup residueGroup = new SharedGroup();
		Vector lines = new Vector();
		buildWireResidue(residue,lines);
		residueGroup.addChild(constructLineGroup(lines));
                
		// go through the atoms, find bonded atoms and construct information about the lines
		/*for(Enumeration e = residue.getAtomKeys(); e.hasMoreElements();){
			String atomName = (String)e.nextElement();
			Atom atom = residue.getAtom(atomName);
			if(atom!=null)
				residueGroup.addChild(new AtomNode(atom));
		}//ends for

		for(Enumeration e = residueStructure.getBonds().elements();
			e.hasMoreElements();){
			Bond currentBond = (Bond)e.nextElement();
			Atom atom1 = residue.getAtom(currentBond.getAtomName1());
			Atom atom2 = residue.getAtom(currentBond.getAtomName2());
			if(atom1!=null&&atom2!=null){
				residueGroup.addChild(new BondNode(atom1,atom2));
			}//ends if
		}//ends for*/ 
		
		return residueGroup;
	}
	
	
	
	
	/**
	* Constructs a transformGroup that contains a LineArray for the specified 
	*/
	public Shape3D constructLineGroup(Vector lines)
	{
		LineArray macromoleculeLineArray = null;
		Shape3D shape3D = null;
		
		if(lines.size()!=0)
		{
	   		macromoleculeLineArray = new LineArray(lines.size()*2, GeometryArray.COORDINATES|GeometryArray.COLOR_3);
	    	
	    	int index = 0;    
	   		
	   		for(Enumeration e2 = lines.elements(); e2.hasMoreElements();)
	   		{
				LineInformation tempLineInformation = (LineInformation)e2.nextElement();
				macromoleculeLineArray.setColor(index, tempLineInformation.getColor3f());
				macromoleculeLineArray.setCoordinate(index, tempLineInformation.getFirstPoint());
				
				index++;
				
				macromoleculeLineArray.setColor(index, tempLineInformation.getColor3f());
				macromoleculeLineArray.setCoordinate(index, tempLineInformation.getSecondPoint());
				
				index++;
	    	}
	    	
	    	Appearance macromoleculeAppearance = new Appearance();
	    	
	    	//macromoleculeAppearance.setMaterial(new Material(new Color3f(.2f,.2f,2f),new Color3f(.1f,.1f,.1f),new Color3f(1f,1f,0f),new Color3f(1f,1f,0f), 64f));
			
			//macromoleculeAppearance.setTransparencyAttributes(new TransparencyAttributes(TransparencyAttributes.SCREEN_DOOR, 0f));
	    	
	    	// set line attributes- line width, line pattern, antialiasing flag
	    	LineAttributes macromoleculeLineAttributes = new LineAttributes(4,LineAttributes.PATTERN_SOLID,true); // SETS THE LINE
			
			RenderingAttributes renderAttributes = new RenderingAttributes();									  // WIDTH FOR EVERYTHING
	    	
	    	//renderAttributes.setVisible(false);
	    	//renderAttributes.setDepthBufferWriteEnable(false);
	    	//renderAttributes.setDepthBufferEnable(false);

	    	//renderAttributes.setAlphaTestFunction(RenderingAttributes.ALWAYS); // .ALWAYS default
			//renderAttributes.setAlphaTestValue( .4f ); // 0 default
	    	
	    	
	    	macromoleculeAppearance.setLineAttributes(macromoleculeLineAttributes);
			macromoleculeAppearance.setRenderingAttributes(renderAttributes);
			shape3D = new Shape3D(macromoleculeLineArray, macromoleculeAppearance);
		}
		
		return shape3D;
	}
	
	
	/**
     * builds residues a relatively cheap and efficient way, 
     * only constructing a array of lines from the bonds present
     */
	public void buildWireResidue(Residue residue,Vector lines)
	{
		// go through the atoms, find bonded atoms and construct information about the lines
		for(Enumeration e = residue.getAtomKeys(); e.hasMoreElements();)
		{
			String firstAtomName = (String)e.nextElement();
			Atom firstAtom = residue.getAtom(firstAtomName);
			
			// construct lines that points toward every atom 
			// this atom is connected to
			try
			{
				for(Enumeration bondedAtoms = residueStructure.getBondedAtomNames(firstAtomName).elements();
					bondedAtoms.hasMoreElements();)
				{
					String bondedAtomName = (String)bondedAtoms.nextElement();
					
					if(residue.containsAtom(bondedAtomName))
					{
						Atom secondAtom = residue.getAtom(bondedAtomName);
						lines.add(constructLine (firstAtom, secondAtom));
					}
				}
			}
			catch(Exception g)
			{
				g.printStackTrace(System.out);
				System.out.println("error when building wire residue for " + residue);
				System.out.println("Trying to get bonded atom names for " + firstAtom);
			}
		}
	}


  	public LineInformation constructLine(Atom primaryAtom,Atom secondaryAtom)
  	{
		LineInformation lineInformation = new LineInformation();
		Point3d primaryAtomPoint = new Point3d(primaryAtom.getX(),primaryAtom.getY(), primaryAtom.getZ());
		double midx = (primaryAtom.getX()+secondaryAtom.getX())/2;
		double midy = (primaryAtom.getY()+secondaryAtom.getY())/2;
		double midz = (primaryAtom.getZ()+secondaryAtom.getZ())/2;
		Point3d midPoint = new Point3d(midx,midy,midz);
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		String type = thisResidue.getParentMacromolecule().getType();
		
		
		if (type == Macromolecule.RNA || type == Macromolecule.DNA)
		{
			Color3f NatomColor = (Color3f)RenderTable.NAatomColors.get(primaryAtom.getAtomType());
			lineInformation.setColor3f(NatomColor);
		}
		else if(type == Macromolecule.PROTEIN)
		{
			Color3f PatomColor = (Color3f)RenderTable.PatomColors.get(primaryAtom.getAtomType());
			lineInformation.setColor3f(PatomColor);
		}
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		
		lineInformation.setPoints(primaryAtomPoint,midPoint);
		//lineInformation.setColor3f(atomColor);
		return lineInformation;
	}



    public Point3d getMidPoint(Point3d point1, Point3d point2)
    {
		Point3d midPoint = new Point3d((point1.x+point2.x)/2, (point1.y+point2.y)/2, (point1.z+point2.z)/2);
		return midPoint;
	}
    	
    	
    	
	private class LineInformation
	{
		Point3d firstPoint;
		Point3d secondPoint;
		Color3f color3f;
		
		public LineInformation()
		{
		}

		public LineInformation(Point3d firstPoint, Point3d secondPoint, Color3f color3f)
		{
			this.firstPoint = firstPoint;
			this.secondPoint = secondPoint;
			this.color3f = color3f;
		}



		public Point3d getFirstPoint()
		{
			return firstPoint;
		}

		public Point3d getSecondPoint()
		{
			return secondPoint;
		}

		public Color3f getColor3f()
		{
			return color3f;
		}

		public void setFirstPoint(Point3d point)
		{
			firstPoint = point;
		}

		public void setSecondPoint(Point3d point)
		{
			secondPoint = point;
		}

		public void setPoints(Point3d firstPoint,Point3d secondPoint)
		{
			this.firstPoint = firstPoint;
			this.secondPoint = secondPoint;
		}

		public void setColor3f(Color3f color3f)
		{
			this.color3f = color3f;
		}
	}
}