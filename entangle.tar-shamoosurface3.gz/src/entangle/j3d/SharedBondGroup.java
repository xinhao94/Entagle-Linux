package entangle.j3d;

import javax.media.j3d.Appearance;
import javax.media.j3d.ColoringAttributes;
import javax.media.j3d.Material;
import javax.media.j3d.SharedGroup;
import javax.media.j3d.Switch;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Color3f;

import com.sun.j3d.utils.geometry.Cylinder;
import com.sun.j3d.utils.geometry.Primitive;

import entangle.datastructures.Atom;



/**
 * SharedBondGroup.java
 *
 *
 * Created: Sat Nov 28 20:46:06 1998
 *
 * @author Stephan Reiling
 */

public class SharedBondGroup extends SharedGroup implements RenderStyle
{
   Switch mySwitch;
   Color3f minimumColor = null;
   Cylinder cyl;
   private BondNode lnkBondNode;
   
   
   
   public SharedBondGroup(Atom a) 
   {
      super();
      mySwitch = new Switch(Switch.CHILD_MASK);
      mySwitch.setCapability(Switch.ALLOW_SWITCH_WRITE);
      addChild(mySwitch);
      RenderTable rTable = RenderTable.getTable();
      
      Material m = rTable.getMaterial(a);
      Appearance appearance = new Appearance();
      
      if(a.getAtomType().equals("H")) 
			appearance.setTransparencyAttributes(new TransparencyAttributes(TransparencyAttributes.FASTEST, .5f));
			
      appearance.setMaterial(m);
      ColoringAttributes coloringAttributes = new ColoringAttributes();
      coloringAttributes.setShadeModel(ColoringAttributes.FASTEST);
      appearance.setColoringAttributes(coloringAttributes);
      cyl = new Cylinder(RenderTable.STICK_RADIUS, 1.0f,Primitive.GENERATE_NORMALS, 
				  RenderTable.STICK_QUALITY,RenderTable.STICK_QUALITY, appearance);

      mySwitch.addChild(cyl);
      mySwitch.setWhichChild(0);
      compile();
   }
   
   
   
   public SharedBondGroup(Atom a,Color3f minimumColor)
   {
          super();
          mySwitch = new Switch(Switch.CHILD_MASK);
          mySwitch.setCapability(Switch.ALLOW_SWITCH_WRITE);
          addChild(mySwitch);
          RenderTable rTable = RenderTable.getTable();
          Material m = rTable.getMaterial(a);
          m.setAmbientColor(minimumColor);
          m.setDiffuseColor(minimumColor);
          Appearance appearance = new Appearance();
	  	  ColoringAttributes coloringAttributes = new ColoringAttributes();
      	  coloringAttributes.setShadeModel(ColoringAttributes.FASTEST);
      	  appearance.setColoringAttributes(coloringAttributes);
          appearance.setMaterial(m);
          cyl = new Cylinder(RenderTable.STICK_RADIUS, 1.0f, Primitive.GENERATE_NORMALS, 
				  RenderTable.STICK_QUALITY,RenderTable.STICK_QUALITY, appearance);

          mySwitch.addChild(cyl);
          mySwitch.setWhichChild(0);
          compile();
   }



   public void setStyle(int style)
   {
      switch(style)
      {
      		case RenderStyle.BALL_AND_STICK:
      		
      		case RenderStyle.STICK:
	 			mySwitch.setWhichChild(0);
	 			break;
      		
      		case RenderStyle.CPK:
	 			mySwitch.setWhichChild(Switch.CHILD_NONE);
	 			break;
      }
   }
}