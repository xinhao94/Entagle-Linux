package entangle.j3d;

import javax.media.j3d.Appearance;
import javax.media.j3d.ColoringAttributes;
import javax.media.j3d.Material;
import javax.media.j3d.Node;
import javax.media.j3d.SharedGroup;
import javax.media.j3d.Switch;
import javax.media.j3d.TransparencyAttributes;

import com.sun.j3d.utils.geometry.Primitive;
import com.sun.j3d.utils.geometry.Sphere;

import entangle.datastructures.Atom;



public class SharedAtomGroup extends SharedGroup implements RenderStyle
{
   Switch mySwitch;
   private AtomNode lnkAtomNode;



   public SharedAtomGroup(Atom a) 
   {
      super();
      mySwitch = new Switch(Switch.CHILD_MASK);
      mySwitch.setCapability(Switch.ALLOW_SWITCH_WRITE);
      addChild(mySwitch);
      RenderTable rTable = RenderTable.getTable();

      Material m = rTable.getMaterial(a);
      Appearance appearance = new Appearance();
      appearance.setMaterial(m);
      ColoringAttributes coloringAttributes = new ColoringAttributes();
      coloringAttributes.setShadeModel(ColoringAttributes.FASTEST);
      appearance.setColoringAttributes(coloringAttributes);
      
      if(a.getAtomType().equals("H")) 
			appearance.setTransparencyAttributes(new TransparencyAttributes(TransparencyAttributes.FASTEST, .5f));
      
      // Ball and Stick:
      Node n = new Sphere(RenderTable.BALL_RADIUS,Primitive.GENERATE_NORMALS,7,appearance);
      mySwitch.addChild(n);

      //CPK:
      n = new Sphere(rTable.getRadius(a), Primitive.GENERATE_NORMALS,7, appearance);
      mySwitch.addChild(n);
      
      // STICK:
      n = new Sphere(RenderTable.STICK_RADIUS, Primitive.GENERATE_NORMALS,4,appearance);
      mySwitch.addChild(n);

      mySwitch.setWhichChild(0);
      compile();
   }
   
   
   
   public void setStyle(int style)
   {
      switch(style)
      {
      	case RenderStyle.BALL_AND_STICK:
	 		mySwitch.setWhichChild(0);
	 		break;
      	case RenderStyle.CPK:
	 		mySwitch.setWhichChild(1);
	 		break;
      	case RenderStyle.STICK:
	 		mySwitch.setWhichChild(2);
	 		break;
      }
   }
}