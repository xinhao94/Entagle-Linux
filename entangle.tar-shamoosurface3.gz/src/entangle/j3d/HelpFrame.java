package entangle.j3d;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Provides a frame for the help window
 *
 * @author Lowell Meyer
 * @since 7/31/01
 */
public class HelpFrame extends JFrame
{
	
	
    public HelpFrame(String title)
    {
		setTitle(title);  				// from java.awt.Frame
		
		
		JPanel panel = new JPanel();
		
		GridBagLayout gridbag = new GridBagLayout();
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(10,10,10,10);
		
		panel.setLayout(gridbag);
		
		///////////////////
		// HYDROGEN BOND //
		///////////////////
		
		ImageIcon icon = new ImageIcon(System.getProperty("user.dir") + File.separator + "images" + File.separator + "hydrogen.jpg");

		JLabel label = new JLabel("Hydrogen Bond", icon, JLabel.CENTER);
		
		//Set the position of the text, relative to the icon:
		label.setVerticalTextPosition(JLabel.BOTTOM);
		label.setHorizontalTextPosition(JLabel.CENTER);
		
		c.gridx = 1;
		c.gridy = 0;
		gridbag.setConstraints(label, c);
		
		panel.add(label);
		
		
		///////////////////
		// ELECTROSTATIC //
		///////////////////
		
		ImageIcon icon2 = new ImageIcon(System.getProperty("user.dir") + File.separator + "images" + File.separator + "electrostatic.jpg");

		JLabel label2 = new JLabel("Electrostatic Interaction", icon2, JLabel.CENTER);
		
		//Set the position of the text, relative to the icon:
		label2.setVerticalTextPosition(JLabel.BOTTOM);
		label2.setHorizontalTextPosition(JLabel.CENTER);

		c.gridx = 0;
		c.gridy = 0;
		gridbag.setConstraints(label2, c);

		panel.add(label2);
		
		
		///////////////////
		// STACKING      //
		///////////////////
		
		ImageIcon icon3 = new ImageIcon(System.getProperty("user.dir") + File.separator + "images" + File.separator + "stacking.jpg");

		JLabel label3 = new JLabel("Stacking Interaction", icon3, JLabel.CENTER);
		
		//Set the position of the text, relative to the icon:
		label3.setVerticalTextPosition(JLabel.BOTTOM);
		label3.setHorizontalTextPosition(JLabel.CENTER);
		
		c.gridx = 0;
		c.gridy = 1;
		gridbag.setConstraints(label3, c);

		panel.add(label3);
		
		
		///////////////////
		// HYDROPHOBIC   //
		///////////////////
		
		ImageIcon icon4 = new ImageIcon(System.getProperty("user.dir") + File.separator + "images" + File.separator + "hydrophobic.jpg");

		JLabel label4 = new JLabel("Hydrophobic Interaction", icon4, JLabel.CENTER);
		
		//Set the position of the text, relative to the icon:
		label4.setVerticalTextPosition(JLabel.BOTTOM);
		label4.setHorizontalTextPosition(JLabel.CENTER);
		
		c.gridx = 1;
		c.gridy = 1;
		gridbag.setConstraints(label4, c);

		panel.add(label4);
		
		
		///////////////////
		// VANDERWAALS   //
		///////////////////
		
		ImageIcon icon5 = new ImageIcon(System.getProperty("user.dir") + File.separator + "images" + File.separator + "vanderwaals.jpg");

		JLabel label5 = new JLabel("Van der Waals Interaction", icon5, JLabel.CENTER);
		
		//Set the position of the text, relative to the icon:
		label5.setVerticalTextPosition(JLabel.BOTTOM);
		label5.setHorizontalTextPosition(JLabel.CENTER);
		
		c.gridx = 2;
		c.gridy = 1;
		gridbag.setConstraints(label5, c);

		panel.add(label5);
		
		
		///////////////////
		// PROTEIN       //
		///////////////////
		
		ImageIcon icon6 = new ImageIcon(System.getProperty("user.dir") + File.separator + "images" + File.separator + "protein_backbone.jpg");

		JLabel label6 = new JLabel("Protein Backbone", icon6, JLabel.CENTER);
		
		//Set the position of the text, relative to the icon:
		label6.setVerticalTextPosition(JLabel.BOTTOM);
		label6.setHorizontalTextPosition(JLabel.CENTER);
		
		c.gridx = 2;
		c.gridy = 0;
		gridbag.setConstraints(label6, c);

		panel.add(label6);
		
		
		///////////////////
		// RNA           //
		///////////////////
		
		ImageIcon icon7 = new ImageIcon(System.getProperty("user.dir") + File.separator + "images" + File.separator + "rna_backbone.jpg");

		JLabel label7 = new JLabel("RNA Backbone", icon7, JLabel.CENTER);
		
		//Set the position of the text, relative to the icon:
		label7.setVerticalTextPosition(JLabel.BOTTOM);
		label7.setHorizontalTextPosition(JLabel.CENTER);
		
		c.gridx = 3;
		c.gridy = 0;
		gridbag.setConstraints(label7, c);

		panel.add(label7);
		
		
		///////////////////
		// Residue       //
		///////////////////
		
		ImageIcon icon8 = new ImageIcon(System.getProperty("user.dir") + File.separator + "images" + File.separator + "residue.jpg");

		JLabel label8 = new JLabel("Visible Residue", icon8, JLabel.CENTER);
		
		//Set the position of the text, relative to the icon:
		label8.setVerticalTextPosition(JLabel.BOTTOM);
		label8.setHorizontalTextPosition(JLabel.CENTER);
		
		c.gridx = 3;
		c.gridy = 1;
		gridbag.setConstraints(label8, c);

		panel.add(label8);
		
		
		
		// SET FRAME PROPERTIES
		
		getContentPane().add(panel);
			
		pack();
		setVisible(true);
    }   
}