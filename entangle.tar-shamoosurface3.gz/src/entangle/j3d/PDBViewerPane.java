/*
* Last Modified: 07/21/2000 - 08:03:54
* Author: Jim Allers
*/

package entangle.j3d;

import java.awt.BorderLayout;
import java.io.File;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.media.j3d.AmbientLight;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.DirectionalLight;
import javax.media.j3d.Group;
import javax.media.j3d.Locale;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.swing.JPanel;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

import com.sun.j3d.utils.behaviors.mouse.MouseRotate;
import com.sun.j3d.utils.behaviors.mouse.MouseTranslate;
import com.sun.j3d.utils.behaviors.mouse.MouseZoom;
import com.sun.j3d.utils.universe.SimpleUniverse;

import entangle.classification.InteractingGroup;
import entangle.classification.NBInteractionContainer;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.Residue;
import entangle.utils.CenterOfMassFinder;
import entangle.utils.io.ResidueLibraryParser;


/**
 * PDBViewerPane provides the user with a way to look at the structure of a 
 * specified nucleic acid and protein
 */
public class PDBViewerPane extends JPanel
{
    Macromolecule protein;
    Macromolecule rna;
    NBInteractionContainer container;
    //LRM		Residue currentResidue;
    Hashtable interactingGroupsTable;
    
    //LRM		InteractingGroup currentInteractingGroup;
    //InteractingGroup	firstInteractingGroup;	//LRM
    
    Hashtable residueStructures; 
    
    File residueLibraryFile = new File(System.getProperty("user.dir")+File.separator+
		"data" + File.separator + "residueDefinitions" + File.separator + "residues");
    
    File atomTypesFile = new File(System.getProperty("user.dir") + File.separator + 
                 "data" + File.separator + "residueDefinitions" + File.separator + "atomTypes");
    
    // Stuff about the Java3D scene and view
    SimpleUniverse su;
    BranchGroup currentlyShownBranchGroup;
    BranchGroup niceMacromoleculeScene;
    MacromoleculeNode proteinNode;
    MacromoleculeNode nucleicAcidNode;
    Locale locale;
    CenterOfMassFinder centerOfMassFinder;
    Point3d centerOfMass;
    Point3d pivotPoint;
    Interaction3DContainer interaction3DContainer;
    Canvas3D canvas3D;
    TransformGroup pivotPointTG; // changing this transformGroup's transform 
                                 // moves around the origin for viewing the structure
    Transform3D pivotPointTransform;
    TransformGroup macromoleculesTG;
    Transform3D mainTransform;
    TransformGroup mainTG;
    //LRM		JComboBox rnaResidueSelectionBox;
        
        
        
        
    public PDBViewerPane(Macromolecule protein, Macromolecule rna, NBInteractionContainer container)
    {
		RenderTable.init();
	
		
		this.protein = protein;
		this.rna = rna;
		this.container = container;
		
		residueStructures = (new ResidueLibraryParser(residueLibraryFile, atomTypesFile)).getResidueStructures();
		interaction3DContainer = new Interaction3DContainer(container);
		this.interactingGroupsTable = container.getInteractingGroups();
		//LRM		currentInteractingGroup = (InteractingGroup)interactingGroupsTable.elements().nextElement();
		//firstInteractingGroup = (InteractingGroup)interactingGroupsTable.elements().nextElement(); //LRM
		
		centerOfMassFinder = new CenterOfMassFinder();
		centerOfMass = centerOfMassFinder.findCenterOfMass(protein,rna);
		pivotPoint = centerOfMass;
		
		createPane();
    }
    
    
    
    
    MacromoleculeNode getProteinNode()
    {
    	return proteinNode;
    }
    
    MacromoleculeNode getNucleicAcidNode()
    {
    	return nucleicAcidNode;
    }
    
    Interaction3DContainer getInteraction3DContainer()
    {
    	return interaction3DContainer;
    }
        
        
        
    public void createPane()
    {
		setLayout(new BorderLayout());
		
		//LRM		rnaResidueSelectionBox = new JComboBox();
		
		//LRM		for(Enumeration e = interactingGroupsTable.elements();e.hasMoreElements();)
		//			{
		//    			rnaResidueSelectionBox.addItem(e.nextElement());
		//			}
		
		
		// rebuild the scene graph when a new interacting group is chosen
		//LRM		rnaResidueSelectionBox.addItemListener(new ItemListener()
		//			{
		//    			public void itemStateChanged(ItemEvent e)
		//    			{
		//					if(e.getStateChange()==ItemEvent.SELECTED)
		//					{
		//	    				proteinNode.setVisibilityOfInteractingGroup(currentInteractingGroup, false);
		//	    				nucleicAcidNode.setVisibilityOfInteractingGroup(currentInteractingGroup, false);
		//	    				interaction3DContainer.setVisibilityOfInteractions(currentInteractingGroup, false);
		//	    				currentInteractingGroup = (InteractingGroup)rnaResidueSelectionBox.getSelectedItem();
		//	    				proteinNode.setVisibilityOfInteractingGroup(currentInteractingGroup, true);
		//	    				nucleicAcidNode.setVisibilityOfInteractingGroup(currentInteractingGroup, true);
		//	    				interaction3DContainer.setVisibilityOfInteractions(currentInteractingGroup, true);
		//	    		
		//	    				// switching the pivot point but keeping the same location
		//	    				// as viewed by the user
		//	    				// deal with the pivotPointTG
		//	    				Residue residue = currentInteractingGroup.getNucleicAcidResidue();
		//	    				pivotPoint = centerOfMassFinder.findCenterOfMass(residue);
		//	    				changePivotPosition(pivotPoint);
		//					}
		//  			}
		//LRM		});
    	
    	//LRM		rnaResidueSelectionBox.setLightWeightPopupEnabled(false);
		//LRM		add(rnaResidueSelectionBox,BorderLayout.SOUTH);
		
		canvas3D = new Canvas3D(SimpleUniverse.getPreferredConfiguration());
		add(canvas3D,BorderLayout.CENTER);
		
		su = new SimpleUniverse(canvas3D);
		
		// viewing platform stuff
		su.getViewingPlatform().setNominalViewingTransform();
		Transform3D translate3D = new Transform3D();
		Transform3D modifiedTransform = new Transform3D();
		Vector3f translationVector = new Vector3f(0,0,30);
		translate3D.setTranslation(translationVector);
		
		// get current viewing platform transform
		su.getViewingPlatform().getViewPlatformTransform().getTransform(modifiedTransform);
		
		// translate it backwards
		modifiedTransform.mul(translate3D);
		su.getViewingPlatform().getViewPlatformTransform().setTransform(modifiedTransform);
		
		su.getViewer().getView().setBackClipDistance(40.0);
		
		su.getViewer().getView().setDepthBufferFreezeTransparent(false);  //true by default
		
		//su.getViewer().getView().setSceneAntialiasingEnable(true); //false by default
		
		//fastMacromoleculeScene = createFastMacromoleculeScene();
		niceMacromoleculeScene = createNiceMacromoleculeScene();
    	currentlyShownBranchGroup = niceMacromoleculeScene;
    	
    	currentlyShownBranchGroup.compile(); // NEW
    	
		su.addBranchGraph(currentlyShownBranchGroup);
		locale = su.getLocale();
    }
    
    
    
    
   	/**
     * builds the nice looking scene graph for the PDBViewer
     */
    public BranchGroup createNiceMacromoleculeScene()
    {
		BranchGroup objRoot = new BranchGroup();
		
		objRoot.setCapability(Group.ALLOW_CHILDREN_READ);
		objRoot.setCapability(Group.ALLOW_CHILDREN_WRITE);
		objRoot.setCapability(Group.ALLOW_CHILDREN_EXTEND);
		objRoot.setCapability(BranchGroup.ALLOW_DETACH);
		
		// Build the transform groups for the interactions,
		// protein and nucleic acid
		proteinNode = new MacromoleculeNode(protein);
		nucleicAcidNode = new MacromoleculeNode(rna);
		TransformGroup proteinTG = buildSpecificMacromoleculeTG(proteinNode); //, firstInteractingGroup);	// LRM -> "first" used to be current
		TransformGroup rnaTG = buildSpecificMacromoleculeTG(nucleicAcidNode); //, firstInteractingGroup);	// LRM -> "" same
		
		macromoleculesTG = new TransformGroup();
		macromoleculesTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		macromoleculesTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		
		mainTransform = new Transform3D();
		mainTG = new TransformGroup();
		mainTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		mainTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		
		objRoot.addChild(mainTG);
		pivotPointTransform = new Transform3D();
		Vector3d translateVector = new Vector3d(-centerOfMass.x,-centerOfMass.y,-centerOfMass.z);
		pivotPointTransform.setTranslation(translateVector);
		pivotPointTG = new TransformGroup(pivotPointTransform);
		pivotPointTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		pivotPointTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		pivotPointTG.addChild(proteinTG);
		pivotPointTG.addChild(rnaTG);
		
		interaction3DContainer.buildHydrogenBondNodes(pivotPointTG);
		interaction3DContainer.buildEINodes(pivotPointTG);
		interaction3DContainer.buildStackNodes(pivotPointTG);
		interaction3DContainer.buildVanderWaalsNodes(pivotPointTG);		//LRM
		interaction3DContainer.buildHydrophobicNodes(pivotPointTG);		//LRM
		//LRM		interaction3DContainer.setVisibilityOfInteractions(currentInteractingGroup, true);
		
		macromoleculesTG.addChild(pivotPointTG);
		mainTG.addChild(macromoleculesTG);
		BoundingSphere bounds = new BoundingSphere(new Point3d(),1000.0);
		MouseRotate mr = new MouseRotate(macromoleculesTG);
		MouseZoom mz = new MouseZoom(macromoleculesTG);
		MouseTranslate mt = new MouseTranslate(macromoleculesTG);
		
		macromoleculesTG.addChild(mr);
		macromoleculesTG.addChild(mz);
		macromoleculesTG.addChild(mt);
		
		mr.setSchedulingBounds(bounds);
		mz.setSchedulingBounds(bounds);
		mt.setSchedulingBounds(bounds);
		
		initLighting(objRoot);
		
		// Allow Java3D to optimize branch group
		objRoot.compile();
		return objRoot;
	}
	
	
	
	public void changePivotPosition(Point3d point)
	{
		System.out.println("Changing Pivot Position");
		
		Transform3D translate3D = new Transform3D();
		Vector3d pivotTranslation = new Vector3d(-point.x,-point.y,-point.z);
		Vector3d oldPivotTranslation = new Vector3d();
		
		pivotPointTransform.get(oldPivotTranslation); 	// puts the current transform into oldpivottranslation
		Vector3d differenceTranslation = new Vector3d();
		pivotPointTransform.setTranslation(pivotTranslation);
		pivotPointTG.setTransform(pivotPointTransform);
		differenceTranslation.sub(pivotTranslation,oldPivotTranslation);
		translate3D.setTranslation(differenceTranslation);
		
		// move the main transform group to counter the translation
		// made by the pivotPointGroup
		Transform3D macromoleculesTransform = new Transform3D();
		macromoleculesTG.getTransform(macromoleculesTransform);
		Vector3d newTranslation = new Vector3d();
		Vector3d oldTranslation = new Vector3d();
		
		macromoleculesTransform.get(oldTranslation);
		macromoleculesTransform.mul(translate3D);
		macromoleculesTransform.get(newTranslation);
		
		oldTranslation.sub(newTranslation);
		translate3D.setTranslation(oldTranslation);
		mainTG.getTransform(mainTransform);
		mainTransform.mul(translate3D);
		mainTG.setTransform(mainTransform);
	}
    
    // CALLED BY PDBVIEWERFRAME, specifically by the Residue menu Item Listeners
    public void computeCenterOfMass(Hashtable visibleResidues)
    {
    	double x = 0;
    	double y = 0;
    	double z = 0;
    	
    	int n = visibleResidues.size();
    	
    	Point3d aCOM; 								// the center-of-mass for the current residue
		double a, b, c;
		
		Residue currentResidue;
		
		boolean test = true;
		
    	for(Enumeration vr = visibleResidues.elements(); vr.hasMoreElements(); )
    	{
    		test = false;
    		
    		currentResidue = ((InteractingGroup)vr.nextElement()).getNucleicAcidResidue();
    		
    		aCOM = centerOfMassFinder.findCenterOfMass(currentResidue);
    		
    		a = (aCOM.x) / n;
    		b = (aCOM.y) / n;
    		c = (aCOM.z) / n;
    		
    		x = x + a;
    		y = y + b;
    		z = z + c;
    	}
    	
    	Point3d theCOM = new Point3d(x, y, z); 	// the combined center-of-mass
    	
    	if(test)
    	{
    		theCOM = centerOfMassFinder.findCenterOfMass(protein,rna);
    	}
    	
    	System.out.println("The combined center of mass is " + theCOM);
    	
    	changePivotPosition(theCOM);
    }
    
    
	void initLighting(BranchGroup root)
	{
		BoundingSphere bounds;
		
		//LinearFog fog;
		bounds = new BoundingSphere(new Point3d(0.0,0.0,0.0), 1000.0);
		Color3f dlColor = new Color3f(1.0f, 1.0f, 1.0f);

		Vector3f lDirect1 = new Vector3f(1.0f, -1.0f, -1.0f);
		Vector3f lDirect2 = new Vector3f(-1.0f, 1.0f, 1.0f);

		DirectionalLight lgt1 = new DirectionalLight(dlColor, lDirect1);
		lgt1.setInfluencingBounds(bounds);
		DirectionalLight lgt2 = new DirectionalLight(dlColor, lDirect2);
		lgt2.setInfluencingBounds(bounds);

		Color3f alColor = new Color3f(0.65f, 0.65f, 0.65f);
		AmbientLight aLgt = new AmbientLight(alColor);
		aLgt.setInfluencingBounds(bounds);

		root.addChild(aLgt);
		root.addChild(lgt1);
		root.addChild(lgt2);



		/* CURRENTLY DOESN'T DO ANYTHING, DON'T KNOW WHY
		
		// Try some fog for depth cueing
		LinearFog fog = new LinearFog();
		fog.setCapability(LinearFog.ALLOW_DISTANCE_WRITE);
		fog.setColor(new Color3f(1f,0f, 0f));
		fog.setFrontDistance(70.0);
		fog.setBackDistance(200.0);
		fog.setInfluencingBounds(bounds);
		fog.addScope(root);
		root.addChild(fog);

		*/
	}



   	public TransformGroup buildSpecificMacromoleculeTG(MacromoleculeNode macromoleculeNode) //LRM  , InteractingGroup currentInteractingGroup)
    {
        TransformGroup macromoleculeTG = new TransformGroup();
        //Residue tempResidue;
        
        macromoleculeTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        macromoleculeTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		//LRM	macromoleculeNode.setVisibilityOfInteractingGroup(currentInteractingGroup, true);
		macromoleculeTG.addChild(macromoleculeNode);
	    
	    return macromoleculeTG;
	}
}