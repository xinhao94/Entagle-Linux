package entangle.datastructures;

import java.util.Hashtable;
import java.util.Enumeration;

import entangle.utils.XMLEnabled;
import entangle.utils.Transformable;
import entangle.utils.math.XYZMatrix;

/**
 * @author LRM
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SimplePResidue implements XMLEnabled, Transformable {
    int residueSequenceNumber;
    public String resName;
    public String chainID;
    public String pdbID;

    // table of SimpleAtoms
    public Hashtable atoms;

    static Hashtable longResidueNames;
    // a hashtable of residue names keyed by their 3 letter abbreviation (1 letter for rnas)

    public SimplePResidue(Residue r) {
        residueSequenceNumber = r.residueSequenceNumber;
        resName = r.resName;
        chainID = r.chainID;
        atoms = new Hashtable();
        pdbID = r.getParentMacromolecule().getPdbName();
        Enumeration e = r.atoms.elements();
        while (e.hasMoreElements()) {
            Atom a = (Atom) e.nextElement();
            SimpleAtom sa = a.simpleCopy();
            atoms.put(sa.name, sa);
        }
        if (longResidueNames == null)
            longResidueNames = Residue.longResidueNames;
    }

    public void transform(XYZMatrix t, double r1, double r2, double r3) {
        Enumeration e = atoms.elements();
        
        for (;e.hasMoreElements();){
            Transformable element = (Transformable) e.nextElement();
            element.transform(t, r1, r2, r3);
        }
    }

    public String buildXML() {
        return "        <proteinResidue>\n"
            + "            <type>"
            + resName
            + "</type>\n"
            + "            <chainID>"
            + chainID
            + "</chainID>\n"
            + "        </proteinResidue>";
    }

    public String buildHTML() {
        return "<tr><td>"
            + resName
            + "</td><td>"
            + chainID
            + "</td><td>"
            + residueSequenceNumber
            + "</td></tr>\n";
    }
}
