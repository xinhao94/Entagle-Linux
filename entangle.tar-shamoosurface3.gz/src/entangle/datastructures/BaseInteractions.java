package entangle.datastructures;

import java.util.Enumeration;
import java.util.Vector;

import entangle.utils.XMLEnabled;

/**
 * @author Lowell Meyer
 *
 * This class is used for the multiple PDB file generic base analysis.
 * It holds a single nucleic acid base and a compilation of all interactions
 * that base takes part in over a large number of PDB files with many protein
 * residues.
 */
public class BaseInteractions {
	public String baseType; // A,C,G,T,U
	
	public SimpleRNAResidue genericBase; // stores a nucleic acid residue for reference
	public Vector Proteins; // stores VERY basic information about protein residues that interact with uracils
	public Vector Hbonds; // stores ALL hydrogen bonds, in new coordinate system
	public Vector Hinter; // stores ALL hydrophobic interactions, in new coordinate system
	public Vector Einter; // stores ALL electrostatic interactions, in new coordinate system
	public Vector Vinter; // stores ALL vanderwaals interactions, in new coordinate system
	public Vector Sinter; // stores ALL stacking interactions, in new coordinate system
	public Vector CPinter; // stores ALL cation pi interactions, in new coordinate system
	
	public BaseInteractions(String type){
		if(type.length() != 1)
			throw new IllegalArgumentException("The base type required is the one-letter base name.");
			
		baseType = type;
		
		genericBase = null;
		Proteins = new Vector();
		Hbonds = new Vector();
		Hinter = new Vector();
		Einter = new Vector();
		Vinter = new Vector();
		Sinter = new Vector();
		CPinter = new Vector();
	}
	
	
	public String buildXML(){
		String base = genericBase.buildXML();
		String protein = buildVectorXML(Proteins);
		String hb = buildVectorXML(Hbonds);
		String hi = buildVectorXML(Hinter);
		String ei = buildVectorXML(Einter);
		String vi = buildVectorXML(Vinter);
		String si = buildVectorXML(Sinter);
		String cpi = buildVectorXML(CPinter);
		
		return "<xml>\n"
				+ "    <baseType>" + baseType + "</baseType>\n"
				+ base + protein + hb + hi + ei + vi + si 
				+ "</xml>";
		
	}
	
	public String buildVectorXML(Vector v){
		String xml = "";
		
		Enumeration e = v.elements();
		while(e.hasMoreElements() ){
			XMLEnabled x = (XMLEnabled)e.nextElement();
			xml += x.buildXML() + "\n";
		}
		
		return xml;
	}
	
	public String buildHTML(){
		if(genericBase == null)
			return "<html><head><title>NO INTERACTIONS</title></head><body><p><h1>No Residues Present.</h1></body></html>\n";
			
		return "<html>\n" +
				"<head><title>Base Generalization Analysis for " + baseType + "</title></head>\n" +
				"<body>\n" +
				
				"<p><h2>Nucleic Acid Base Information</h2>\n" +
				"<table><tr><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td></tr>\n" +
				genericBase.buildHTML() +
				"</table>\n\n" +
				
				"<p><h2>Interacting Protein Residues</h2>\n" +
				"<table><tr><td>Name</td><td>Chain ID</td><td>Sequence #</td></tr>\n" +
				buildVectorHTML(Proteins) +
				"</table>\n\n" +
				
				"<p><h2>Hydrogen Bonds</h2>\n" +
				"<table><tr><td>Donor</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Acceptor</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Hydrogen</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\n" +
				"<tr><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td></tr>\n" +
				buildVectorHTML(Hbonds) +
				"</table>\n\n" +
				
				"<p><h2>Hydrophobic Interactions</h2>\n" +
				"<table><tr><td>NonPolar Atom A</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>NonPolar Atom B</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\n" +
				"<tr><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td></tr>\n" +
				buildVectorHTML(Hinter) +
				"</table>\n\n" +
				
				"<p><h2>Electrostatic Interactions</h2>\n" +
				"<table><tr><td>Atom A</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Atom B</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\n" +
				"<tr><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td></tr>\n" +
				buildVectorHTML(Einter) +
				"</table>\n\n" +
				
				"<p><h2>VanderWaals Interactions</h2>\n" +
				"<table><tr><td>Atom A</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Atom B</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\n" +
				"<tr><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td><td>Name</td><td>Type</td><td>Residue</td><td>Molecule</td><td>PDB File</td><td>X</td><td>Y</td><td>Z</td></tr>\n" +
				buildVectorHTML(Vinter) +
				"</table>\n\n" +
				
				"<p><h2>Stacking Interactions</h2>\n" +
				"<table><tr><td>C to C Dist</td><td>Deg. Of Stagger</td><td>Dihedral Angle</td><td>RingA.X</td><td>RingA.Y</td><td>RingA.Z</td><td>RingB.X</td><td>RingB.Y</td><td>RingB.Z</td></tr>\n" +
				buildVectorHTML(Sinter) +
				"</table>\n\n" +
				
				"<p><h2>Cation Pi Interactions</h2>\n" +
				"<table><tr><td>+ to Center Dist</td><td>Cation Name</td><td>Cation Res Name</td><td>Cation.X</td><td>Cation.Y</td><td>Cation.Z</td>"+
				buildVectorHTML(CPinter) + 
				"</table>\n\n" + 
				
				"</body>\n" +
				"</html>";
	}
	
	public String buildVectorHTML(Vector v){
		String html = "";
		
		Enumeration e = v.elements();
		while(e.hasMoreElements() ){
			XMLEnabled x = (XMLEnabled)e.nextElement();
			html += x.buildHTML();
		}
		
		return html;
	}
}
