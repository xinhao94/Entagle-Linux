/*
 * 1.2 code
 * Last Modified: 07/21/2000 - 07:49:57
 * Author: Jim Allers
 */
package entangle.datastructures;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/**
 * A class which given a residue contains information about that residue's structure
 */
public class ResidueStructure {
    String resName;
    Vector bonds;
    Hashtable atomHybridizations;

    final public static String SP1 = "SP1";
    final public static String SP2 = "SP2";
    final public static String SP3 = "SP3";

    private Bond lnkBond;

    public ResidueStructure(Residue residue) {
        resName = residue.getResName();
        bonds = new Vector();
        atomHybridizations = new Hashtable(); // atom hybridizations (Strings) 
    }

    public ResidueStructure(String resName) {
        this.resName = resName;
        bonds = new Vector();
    }

    public String getResName() {
        return resName;
    }

    public Vector getBonds() {
        return bonds;
    }

    public int getNumberOfBonds() {
        return bonds.size();
    }

    public Bond getBond(int i) {
        return (Bond) bonds.elementAt(i);
    }

    public Vector getBondedAtomNames(Atom atomObject) {
        return getBondedAtomNames(atomObject.getName());
    }

    public Vector getBondedAtomNames(String atomName) {
        Vector atomNames = new Vector();

        for (int i = 0; i < bonds.size(); i++) {
            Bond tempBond = (Bond) bonds.elementAt(i);

            if (atomName.equals(tempBond.getAtomName1()))
                atomNames.addElement(tempBond.getAtomName2());
            if (atomName.equals(tempBond.getAtomName2()))
                atomNames.addElement(tempBond.getAtomName1());
        }

        return atomNames;
    }

    public void addBond(String atomName1, String atomName2) {
        Bond bondObject = new Bond(atomName1, atomName2);
        bonds.addElement(bondObject);
    }

    public void addBond(Bond bond) {
        bonds.addElement(bond);
    }

    public boolean containsBond(Bond bond) {
        boolean containsBond = false;

        for (Enumeration e = bonds.elements(); e.hasMoreElements();) {
            Bond tempBond = (Bond) e.nextElement();

            if ((bond.getAtomName1().equals(tempBond.getAtomName1())
                && bond.getAtomName2().equals(tempBond.getAtomName2()))
                || (bond.getAtomName1().equals(tempBond.getAtomName2())
                    && bond.getAtomName2().equals(tempBond.getAtomName1())))
                containsBond = true;
        }

        return containsBond;
    }

    public void addAtomHybridization(String atomName, String hybridization) {
        if (!atomHybridizations.containsKey(atomName)) {
            atomHybridizations.put(atomName, hybridization);
        }
    }

    public String getAtomHybridization(String atomName) {
        return (String) atomHybridizations.get(atomName);
    }

    public String toString() {
        String str = getResName() + ":: ";

        for (Enumeration e = bonds.elements(); e.hasMoreElements();) {
            str += "(" + ((Bond) e.nextElement()).toString() + ") ";
        }

        return str;
    }
}