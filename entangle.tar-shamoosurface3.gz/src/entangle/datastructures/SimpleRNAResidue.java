package entangle.datastructures;

import java.util.Enumeration;
import java.util.Hashtable;

import entangle.utils.Transformable;
import entangle.utils.XMLEnabled;
import entangle.utils.math.XYZMatrix;

/**
 * @author LRM
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SimpleRNAResidue implements Transformable, XMLEnabled{
    int	residueSequenceNumber;
    public String resName;
    Hashtable atoms;				// SimpleAtom list
    public String chainID;
    public String pdbID;
    
    // a hashtable of residue names keyed by their 3 letter abbreviation
    // (1 letter for rnas)
    static Hashtable longResidueNames; 

    public SimpleRNAResidue(Residue r){
       	residueSequenceNumber = r.residueSequenceNumber;
		
       	resName = r.resName;
        pdbID = r.getParentMacromolecule().getPdbName();
        
       	atoms = new Hashtable();
       	Enumeration e = r.atoms.elements();
       	while(e.hasMoreElements()){
            Atom a = (Atom)e.nextElement();
	    SimpleAtom sa = a.simpleCopy();
            atoms.put( sa.name, sa);
        }
	
       	chainID = r.chainID;
		
       	if(longResidueNames == null){
	    longResidueNames = Residue.longResidueNames;
	}
	
    }	
    
    public SimpleAtom getAtom(String name){
	return (SimpleAtom)atoms.get(name);
    }
	
	
    public void transform(XYZMatrix t, double r1, double r2, double r3){
       	Enumeration e = atoms.elements();
       	for (;e.hasMoreElements();){
            Transformable element = (Transformable) e.nextElement();
            element.transform(t, r1, r2, r3);
        }
    }
	
	public String buildXML(){
		String atomXML = "        <atoms>";
		
		Enumeration e = atoms.elements();
		while(e.hasMoreElements()){
			SimpleAtom a = (SimpleAtom)e.nextElement();
			atomXML += ("\n" + a.buildXML());
		}
		
		atomXML += "\n        </atoms>";
		
		return   "    <residue>\n"
				+ "        <type>" + resName + "</type>\n"
				+ atomXML + "\n"
				+ "    </residue>";
	}
	
	public String buildHTML(){
		String html = "";
		Enumeration e = atoms.elements();
		while(e.hasMoreElements() ){
			html += "<tr>" + ((SimpleAtom)e.nextElement()).buildHTML() + "</tr>\n";
		}
		return html;
	}
}











