package entangle.datastructures;


public class AtomLabel
{
		String residueName;
		String atomName;
		
		
		
		public AtomLabel(String residueName, String atomName)
		{
			this.residueName = residueName;
			this.atomName = atomName;
		}
		
		
		
		public void setResidueName(String residueName)
		{
			this.residueName = residueName;
		}
		
		public String getResidueName()
		{
			return residueName;
		}

		public void setAtomName(String atomName)
		{
			this.atomName = atomName;
		}
		
		public String getAtomName()
		{
			return atomName;
		}
		
		public String toString()
		{
			return residueName+atomName;
		}
}