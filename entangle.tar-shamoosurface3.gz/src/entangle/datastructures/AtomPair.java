/*
 * 1.2 code.
 * Last Modified: 3.12.2000
 * Author: Jim Allers (jima@rice.edu)
*/
package entangle.datastructures;


/**
 * AtomPair is a class which stores a protein atom object,
 * a rna atom object, and the distance between them
 */
public class AtomPair
{
 	private Atom macromoleculeAAtom;
 	private Atom macromoleculeBAtom;
 	private double distance;


    public AtomPair(Atom macromoleculeAAtom, Atom macromoleculeBAtom)
    {
		this.macromoleculeAAtom = macromoleculeAAtom;
		this.macromoleculeBAtom = macromoleculeBAtom;
		
		// The distance between the two atoms
		distance =
			Math.sqrt((macromoleculeAAtom.getX()- macromoleculeBAtom.getX())
				     *(macromoleculeAAtom.getX()- macromoleculeBAtom.getX())
				   +  (macromoleculeAAtom.getY()- macromoleculeBAtom.getY())
				     *(macromoleculeAAtom.getY()- macromoleculeBAtom.getY())
				   +  (macromoleculeAAtom.getZ()- macromoleculeBAtom.getZ())
				     *(macromoleculeAAtom.getZ()- macromoleculeBAtom.getZ()));
	}


	public AtomPair(Atom macromoleculeAAtom, Atom macromoleculeBAtom, double distance)
	{
		this.macromoleculeAAtom = macromoleculeAAtom;
		this.macromoleculeBAtom = macromoleculeBAtom;
		this.distance = distance;
	}
	
	
	
	
	public double getDistance()
	{
		return distance;
	}

	public Atom getMacromoleculeAAtom()
	{
		return macromoleculeAAtom;
	}

	public Atom getMacromoleculeBAtom()
	{
		return macromoleculeBAtom;
	}
}