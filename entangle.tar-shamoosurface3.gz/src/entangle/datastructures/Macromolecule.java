/*
 * 1.2 code
 * Last Modified: 07/21/2000 - 07:49:57
 * Author: Jim Allers
 */
package entangle.datastructures;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;



public class Macromolecule implements Serializable
{
    Hashtable residues;
    String name;
    String chainIdentifier;
    String type;
    Hashtable residueStructures;
    Hashtable VanderWaalsRadii;
    
    String pdbName;
    
    final public static String PROTEIN = "protein";
    final public static String RNA = "rna";
    final public static String DNA = "dna"; 



    public Macromolecule(Hashtable residueStructures, Hashtable vanderWaalsRadii, String pdb)
    {
		residues = new Hashtable();
        this.residueStructures = residueStructures;
		this.VanderWaalsRadii = vanderWaalsRadii;
		this.pdbName = pdb;
    }
    
    
    
    public double getVanderWaalsRadius(Atom atom)
    {
		double radius = 2.0;
		Double radiusDouble = (Double)VanderWaalsRadii.get(atom.getName());
		
		if(radiusDouble!=null)
			radius = radiusDouble.doubleValue();
			
		return radius;
    }


    /**
     * equals returns whether the macromolecule is the same as another one
     * but all it does is figure if the name and chain identifier are the same
     */
    public boolean equals(Macromolecule compareMacro)
    {
		boolean equals = false;
		
		if(this.getName().equals(compareMacro.getName())&&
		   this.getChainIdentifier().equals(compareMacro.getChainIdentifier()))
	    	equals = true;
	    	
		return equals;
    }
    
    
	    
    public void setType(String type)
    {
		this.type = type;
    }

    public String getType()
    {
		return type;
    }
    
    
    public boolean containsResidue(Residue residue)
    {
        return residues.contains(residue);
    }
    
    
    public boolean containsPreviousResidue(Residue residue)
    {
        return containsPreviousResidue(residue.getResidueSequenceNumber());
    }
    
    
    public boolean containsPreviousResidue(int resSeq)
    {
        return containsResidue(resSeq - 1);
    }
    
    
    public boolean containsNextResidue(Residue residue)
    {
        return containsNextResidue(residue.getResidueSequenceNumber());
    }
    
    
    public boolean containsNextResidue(int resSeq)
    {
        return containsResidue(resSeq + 1);
    }
    
    
    public boolean containsResidue(int resSeq)
    {
            Integer resSeqInteger = new Integer(resSeq);
            
            return containsResidue(resSeqInteger);
    }
    
    
    public boolean containsResidue(Integer resSeqInteger)
    {
            boolean containsResidue = false;
            
            if(residues.containsKey(resSeqInteger))
                containsResidue = true;
                
            return containsResidue;
    }
    
    
    public boolean containsResidueType(String resName)
    {
            boolean containsResidueType = false;
            
            for(Enumeration e = getResidueEnumeration();e.hasMoreElements();)
            {
                    if(((Residue)e.nextElement()).getResName().equals(resName))
                        containsResidueType = true;
            }
            
            return containsResidueType;
    }
    
    
    public void addResidue(Residue residue)
    {
		Integer resSeq;
		resSeq = new Integer(residue.getResidueSequenceNumber());
		residues.put(resSeq,residue);
    }


    public Hashtable getResidues()
    {
		return residues;
    }
    
    
    public Enumeration getResidueEnumeration()
    {
            return residues.elements();
    }
    
    
    public Enumeration getResidueKeys()
    {
		return residues.keys();
    }
    
    
    public Residue getResidue(Integer resSeq)
    {
		return (Residue)residues.get(resSeq);
    }


    public Residue getResidue(int resSeq)
    {
            return (Residue)residues.get(new Integer(resSeq));
    }
    
    
    public Residue getNextResidue(Residue residue)
    {
        return getResidue(residue.getResidueSequenceNumber() + 1);
    }
    
    
    public Residue getPreviousResidue(Residue residue)
    {
        return getResidue(residue.getResidueSequenceNumber()-1);
    }


    public ResidueStructure getResidueStructure(Residue residue)
    {
		return (ResidueStructure)residueStructures.get(residue.getResName());
    }
    
    
    public void setChainIdentifier(String chainID)
    {
		chainIdentifier = chainID;
    }
    
    
    public String getChainIdentifier()
    {
		return chainIdentifier;
    }
    
    
    public void setName(String name)
    {
		this.name = name;
    }


    public String getName()
    {
		return name;
    }
    
    
    public Vector getBondedAtoms(Atom atom)
    {
        ResidueStructure residueStructure = (ResidueStructure)residueStructures.get(atom.getResName());
        Residue residue = atom.getParentResidue();
        
        Vector bondedAtoms = new Vector();
        
        for(Iterator iterator = residueStructure.getBondedAtomNames(atom).iterator(); iterator.hasNext();)
        {
            String atomName = (String)iterator.next();
            
            if(residue.containsAtom(atomName))
            {
                bondedAtoms.add(residue.getAtom(atomName));
            }
        }
        
        return bondedAtoms;
    }


    public Vector getBondedAtomNames(Atom atom)
    {
		ResidueStructure residueStructure = (ResidueStructure)residueStructures.get(atom.getResName());
		return residueStructure.getBondedAtomNames(atom);
    }
    /**
     * @return Returns the pdbName.
     */
    public String getPdbName() {
        return pdbName;
    }

}