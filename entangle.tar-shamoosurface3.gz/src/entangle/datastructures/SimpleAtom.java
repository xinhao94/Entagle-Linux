package entangle.datastructures;

import entangle.utils.Transformable;
import entangle.utils.XMLEnabled;
import entangle.utils.math.XYZMatrix;

/**
 * @author LRM
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SimpleAtom implements Transformable, XMLEnabled{
    public String name;    //Atom name (O3*, N9, N7, etc)
    public String atomType;//Atom type (H,C,S,P,O,N)
    public String resName; //Residue name
    public String chainID; //Chain identifier
    public int resSeq;     // Residue sequence number
    public double x;      //
    public double y;      //
    public double z;      //
    
    public String molName; // parent macromolecule name
    public String pdbName; // pdb file name
    
    public SimpleAtom(Atom a){
    	name = a.getName();
    	atomType = a.getAtomType();
    	resName = a.getResName();
    	chainID = a.getChainID();
    	resSeq = a.getResSeq();
    	x = a.x;
    	y = a.y;
    	z = a.z;
    	
    	molName = a.getParentResidue().getParentMacromolecule().getName();
    	pdbName = a.getParentResidue().getParentMacromolecule().pdbName;
    }
    
    
    public String buildXML(){
    	return  "            <atom>\n"
    			+"                <name>" + name + "</name>\n"
    			+"                <type>" + atomType + "</type>\n"
    			+"                <resName>" + resName + "</resName>\n"
    			+"                <molName>" + molName + "</molName>\n"
    			+"                <pdbName>" + pdbName + "</pdbName>\n"
    			+"                <x>" + x + "</x>\n"
    			+"                <y>" + y + "</y>\n"
    			+"                <z>" + x + "</z>\n"
    			+"            </atom>";
    }
    
    public String buildHTML(){
    	return "<td>" + name + 
    			"</td><td>" + atomType + 
    			"</td><td>" + resName +  
    			"</td><td>" + molName + 
    			"</td><td>" + pdbName + 
    			"</td><td>" + x + 
    			"</td><td>" + y + 
    			"</td><td>" + z + 
    			"</td>";
    }
    
    
    /**
	 * Applies 4 transformations, in order:
	 * 	1) translation -t
	 * 	2) XYZ theta rotation r1
	 * 	3) ZXY theta rotation r2
	 * 	4) YZX theta rotation r3
	 */
    public void transform(XYZMatrix t, double r1, double r2, double r3){
    	subtract(t);
    	applyXYRotation(r1);
    	applyZXRotation(r2);
    	applyYZRotation(r3);
    }
    
    
    public void subtract(XYZMatrix t){
    	x -= t.getX();
    	y -= t.getY();
    	z -= t.getZ();
    }
    
    /**
	 * Applies the given Theta rotation in the standard XYZ spherical
	 * coordinate system to the XYZ coordinates internally.
	 * 
	 * x = r cos T sin P
	 * y = r sin T sin P
	 * z = r cos P
	 */
	public void applyXYRotation(double rTheta){
		double r = getR();
		double theta = getXYTheta() + rTheta;
		double phi = getXYPhi();
		x = r * Math.cos(theta) * Math.sin(phi);
		y = r * Math.sin(theta) * Math.sin(phi);
		z = r * Math.cos(phi);
	}

	public void applyYZRotation(double rTheta){
		double r = getR();
		double theta = getYZTheta() + rTheta;
		double phi = getYZPhi();
		y = r * Math.cos(theta) * Math.sin(phi);
		z = r * Math.sin(theta) * Math.sin(phi);
		x = r * Math.cos(phi);
	}
	
	public void applyZXRotation(double rTheta){
		double r = getR();
		double theta = getZXTheta() + rTheta;
		double phi = getZXPhi();
		z = r * Math.cos(theta) * Math.sin(phi);
		x = r * Math.sin(theta) * Math.sin(phi);
		y = r * Math.cos(phi);
	}
	
	/*
	 * Spherical coordinates:
	 * x,y,z -> r,theta,phi
	 * 
	 * r = length
	 * theta = angle in x-y plane from positive x-axis, [0,2pi)
	 * phi = angle from positive z-axis, [0,pi]
	 *
	 * double r = Math.sqrt(x*x + y*y + z*z);
	 * double theta = Math.atan2(y,x);
	 * double phi = Math.acos(z/r);
	 */
	public double getR() {
		return Math.sqrt(x * x + y * y + z * z);
	}


	public double getXYTheta() {
		return Math.atan2(y, x);
	}

	public double getYZTheta(){
		return Math.atan2(z, y);
	}

	public double getZXTheta() {
		return Math.atan2(x, z);
	}


	public double getXYPhi() {
		return Math.acos(z / getR() );
	}
	
	public double getYZPhi(){
		return Math.acos(x / getR() );
	}

	public double getZXPhi() {
		return Math.acos(y / getR() );
	}
}
