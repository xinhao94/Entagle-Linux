/**
 * This class follows from the documentation for the HBPLUS program
 * DD-D-H
 */
package entangle.datastructures;

import java.util.Enumeration;
import java.util.Vector;



public class DonorGroupGeometry
{
	final public static String NEXT_RESIDUE = "NextResidue";
	final public static String PREVIOUS_RESIDUE ="PreviousResidue";
	final public static String ANY_RESIDUE = "AnyResidue";
    final public static String SP2 = "SP2";
    final public static String SP3 = "SP3";
    final public static String SP1 = "SP1";

	AtomLabel donor;
	AtomLabel antecedent;
	AtomLabel antecedentAntecedent;
	Vector bondedAtoms;
	Vector hydrogenInfos;
    String hybridization;
    int numberOfHydrogens;
    int numberOfBondedAtoms;
    boolean areHydrogensFixed;
	
    
    
    
    public DonorGroupGeometry(String residueName, String atomName, String hybridization, int numberOfHydrogens,
        			int numberOfBondedAtoms, boolean areHydrogensFixed)
    {
        donor = new AtomLabel(residueName,atomName);
	    bondedAtoms = new Vector();
	    hydrogenInfos = new Vector();
        
        this.hybridization = hybridization;
        this.numberOfHydrogens = numberOfHydrogens;
        this.numberOfBondedAtoms = numberOfBondedAtoms;
        this.areHydrogensFixed = areHydrogensFixed;
    }
    
    

	public AtomLabel getDonorLabel()
	{
		return donor;
	}
	
	public void setDonorLabel(AtomLabel atomLabel)
	{
		donor = atomLabel;
	}
	
	
    public String getResidueName()
    {
        return donor.getResidueName();
    }

    
    public String getAtomName()
    {
        return donor.getAtomName();
    }

    
    public String getHybridization()
    {
        return hybridization;
    }
    
	public void setHybridization(String hybridization)
	{
		this.hybridization = hybridization;
	}
	
	
    public int getNumberOfHydrogens()
    {
        return numberOfHydrogens;
    }

	public void setNumberOfHydrogens(int numberOfHydrogens)
	{
		this.numberOfHydrogens = numberOfHydrogens;
	}
	
	
    public int getNumberOfBondedAtoms()
    {
        return numberOfBondedAtoms;
    }
	
	public void setNumberOfBondedAtoms(int numberOfBondedAtoms)
	{
		this.numberOfBondedAtoms = numberOfBondedAtoms;
	}


    public boolean areHydrogensFixed()
    {
        return areHydrogensFixed;
    }
	
	public void setAreHydrogensFixed(boolean areHydrogensFixed)
	{
		this.areHydrogensFixed = areHydrogensFixed;
	}
	
	
	public void setAntecedent(String residueName,String atomName)
	{
		antecedent = new AtomLabel(residueName,atomName);
	}
	
	
	public void setAntecedentAntecedent(String residueName, String atomName)
	{
		antecedentAntecedent = new AtomLabel(residueName,atomName);
	}
	
	
	public AtomLabel getAntecedent()
	{
		return antecedent;
	}
	
	
	public AtomLabel getAntecedentAntecedent()
	{
		return antecedentAntecedent;
	}
	
	
	public void addBondedAtom(AtomLabel atomLabel)
	{
		if(!bondedAtoms.contains(atomLabel))
		{
			bondedAtoms.add(atomLabel);
		}
	}
	
	public void addBondedAtom(String residueName,String atomName)
	{
		AtomLabel bondedAtom = new AtomLabel(residueName,atomName);
		addBondedAtom(bondedAtom);
	}
	
	
	public AtomLabel getBondedAtomAt(int i)
	{
		return (AtomLabel)bondedAtoms.get(i);
	}
	
	
	public void removeAllBondedAtoms()
	{
		bondedAtoms.removeAllElements();
	}
	
	
	public HydrogenInfo getHydrogenInfoAt(int i)
	{
		return (HydrogenInfo)hydrogenInfos.get(i);
	}
	
	public void addHydrogenInfo(HydrogenInfo hydrogenInfo)
	{
		hydrogenInfos.add(hydrogenInfo);
	}
	
	
	public boolean containsHydrogenName(String hydrogenName)
	{
		boolean containsHydrogenName = false;
		
		for(Enumeration e = hydrogenInfos.elements();e.hasMoreElements();)
		{
			HydrogenInfo tempHydrogenInfo = (HydrogenInfo)e.nextElement();
			
			if(tempHydrogenInfo.getName().equals(hydrogenName))
				containsHydrogenName = true;
		}
		
		return containsHydrogenName;
	}
	
	
	public void removeAllHydrogenInfos()
	{
		hydrogenInfos.removeAllElements();
	}
	
	
	public int getNumberOfHydrogenInfos()
	{
		return hydrogenInfos.size();
	}
	
	
	public void addHydrogenInfo(String hydrogenName,double torsionAngle, double angle, double distance)
	{
		HydrogenInfo hydrogenInfo = new HydrogenInfo(hydrogenName,torsionAngle,angle,distance);
		hydrogenInfos.add(hydrogenInfo);
	}
	
	
	public String toString()
	{
		String str = donor.getResidueName()+donor.getAtomName();
		return str;
	}
}