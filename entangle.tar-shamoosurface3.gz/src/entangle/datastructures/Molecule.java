/*
 * Molecule.java
 *
 * Created on September 5, 2000, 4:24 AM
 */

package entangle.datastructures;

/**
 * Molecule represents any heteromolecule from a PDB file. It uses a graph structure
 * starting with the root, every atom an atom is bonded to is either its children or
 * parent 
 * @author  Jim Allers
 * @version 
 */
public class Molecule extends Object 
{
    Atom root;
    
    
    
    /** Creates new Molecule */
    
    public Molecule() 
    {
    }

}