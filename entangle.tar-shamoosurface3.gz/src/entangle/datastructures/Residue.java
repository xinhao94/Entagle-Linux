/*
 * 1.2 code
 * Last Modified: 07/21/2000 - 07:49:57
 * Author: Jim Allers
 */

package entangle.datastructures;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;


public class Residue implements Serializable
{
    int residueSequenceNumber;
    String resName;
    Hashtable atoms;
    String chainID;
    Macromolecule parentMacromolecule;
    static Hashtable longResidueNames; // a hashtable of residue names keyed by their 3 letter abbreviation (1 letter for rnas)



    public Residue(String resName)
    {
		atoms = new Hashtable();
        this.resName = resName;
        buildLongResidueNames();
    }
    
    
    /**
     * Returns a copy of this interacting group, but with only the geometric
     * information about the data... i.e. without all the overhead.
     * 
     * Used for multiple PDB generalization analysis. 
     * 
     * -LRM
     */
    public SimpleRNAResidue simpleRNACopy(){
    	return new SimpleRNAResidue(this);
    }

    public SimplePResidue simplePCopy(){
    	return new SimplePResidue(this);
    }
    
    
    public void setParentMacromolecule(Macromolecule macromolecule)
    {
        parentMacromolecule = macromolecule;
    }
    
    public Macromolecule getParentMacromolecule()
    {
        return parentMacromolecule;
    }
    
    
    
    public void buildLongResidueNames(){
   		if(longResidueNames == null){
            longResidueNames = new Hashtable();
            longResidueNames.put("A","Adenine");
            longResidueNames.put("C","Cytosine");
            longResidueNames.put("G","Guanine");
            longResidueNames.put("T","Thymine");
            longResidueNames.put("U","Uracil");
            longResidueNames.put("ASP","Aspartic Acid");
            longResidueNames.put("ASN","Asparagine");
            longResidueNames.put("ARG","Arginine");
            longResidueNames.put("CYS","Cysteine");    
            longResidueNames.put("ALA","Alanine");
            longResidueNames.put("GLN","Glutamine");
            longResidueNames.put("GLU","Glutamic Acid");
            longResidueNames.put("HIS","Histidine");
            longResidueNames.put("ILE","Isoleucine");
            longResidueNames.put("LEU","Leucine");
            longResidueNames.put("LYS","Lysine");
            longResidueNames.put("MET","Methionine");
            longResidueNames.put("PHE","Phenylalanine");
            longResidueNames.put("PRO","Proline");
            longResidueNames.put("SER","Serine");
            longResidueNames.put("THR","Threonine");
            longResidueNames.put("TRP","Tryptophan");
            longResidueNames.put("TYR","Tyrosine");
            longResidueNames.put("VAL","Valine");
   		}
    }
    
    
    public String toString()
    { 
            Integer resSeqInteger = new Integer(residueSequenceNumber);
            String str = "";
            
            if(longResidueNames.containsKey(getResName()))
            {
                    str = (String)longResidueNames.get(getResName()) + " " + resSeqInteger.toString();
            }
            else
            {
                    str = getResName() + " " + resSeqInteger.toString();
            }
            
            return str;
    }
    
    
    public int getNumberOfAtoms()
    {
            return atoms.size();
    }
    
    
    public void setChainID(String chainID)
    {
            this.chainID = chainID;
    }
   
    public String getChainID()
    {
            return chainID;
    }


    /**
     * returns the enumeration for the keys within the atom hashtable
     */
    public Enumeration getAtomKeys()
    {
		return atoms.keys();
    }
    
    
    public Enumeration getAtomEnumeration()
    {
        return atoms.elements();
    }


    public void setResName(String resName)
    {
        this.resName = resName;
    }


    public String getResName()
    {
        return resName;
    }


    public int getResidueSequenceNumber()
    {
		return residueSequenceNumber;
    }
    
    
    public void setResidueSequenceNumber(int resSeq)
    {
        residueSequenceNumber = resSeq;
    }
    
    
    public void addAtom(Atom atom)
    {
		atoms.put(atom.getName(),atom);
    }


    public boolean containsAtom(String atomName)
    {
		return atoms.containsKey(atomName);
    }
    
    
    /**
     * 
     */
    public boolean containsAtom(Atom atom)
    {
		boolean containsAtom = false;
		String atomName = atom.getName();
		
		if(atoms.containsKey(atomName))
		{
	    	if(atom.getSerial()==getAtom(atomName).getSerial()&& atom.getChainID().equals(getAtom(atomName).getChainID()))
				containsAtom = true;
		}
	
		return containsAtom;
    }
    
    
    
    public boolean containsAtom(AtomLabel atomLabel)
    {
        boolean containsAtom = false;
        String residueName = atomLabel.getResidueName();
        String atomName = atomLabel.getAtomName();
        
        final int NEXT_RESIDUE = 69;
        final int ANY_RESIDUE = 70;
        final int PREVIOUS_RESIDUE = 71;
        
        int residueNameType = 0;
        
        if(residueName.equals(DonorGroupGeometry.NEXT_RESIDUE)) 
            residueNameType = NEXT_RESIDUE;
            
        if(residueName.equals(DonorGroupGeometry.PREVIOUS_RESIDUE))
            residueNameType = PREVIOUS_RESIDUE;
            
        if(residueName.equals(DonorGroupGeometry.ANY_RESIDUE))
            residueNameType = ANY_RESIDUE;
            
            
        switch(residueNameType)
        {
            case NEXT_RESIDUE:
                if(this.getParentMacromolecule().containsNextResidue(this))
                {
                    Residue nextResidue = this.getParentMacromolecule().getNextResidue(this);
                    if(nextResidue.containsAtom(atomName))
                        containsAtom = true;
                }
                break;
            case PREVIOUS_RESIDUE:
                if(this.getParentMacromolecule().containsPreviousResidue(this))
                {
                    Residue previousResidue = this.getParentMacromolecule().getPreviousResidue(this);
                    if(previousResidue.containsAtom(atomName))
                         containsAtom = true;
                }
                break;
            case ANY_RESIDUE:
                if(this.containsAtom(atomName))
                        containsAtom = true;
                break;
            default:
                if(this.containsAtom(atomName))
                        containsAtom = true;
                break;
        }
        
        return containsAtom;
    }
        
        
        
    public Atom getAtom(String atomName)
    {
		return (Atom)atoms.get(atomName);
    }
    
    
    /**
    * if atom is not found with atom label, null is returned
    */
    public Atom getAtom(AtomLabel atomLabel)
    {
        String residueName = atomLabel.getResidueName();
        String atomName = atomLabel.getAtomName();
        Atom atom = null;
        
        final int NEXT_RESIDUE = 69;
        final int ANY_RESIDUE = 70;
        final int PREVIOUS_RESIDUE = 71;
        
        int residueNameType = 0;
        
        if(residueName.equals(DonorGroupGeometry.NEXT_RESIDUE)) 
            residueNameType = NEXT_RESIDUE;
            
        if(residueName.equals(DonorGroupGeometry.PREVIOUS_RESIDUE))
            residueNameType = PREVIOUS_RESIDUE;
            
        if(residueName.equals(DonorGroupGeometry.ANY_RESIDUE))
            residueNameType = ANY_RESIDUE;
            
            
        switch(residueNameType)
        {
            case NEXT_RESIDUE:
                if(this.getParentMacromolecule().containsNextResidue(this))
                {
                    Residue nextResidue = this.getParentMacromolecule().getNextResidue(this);
                    if(nextResidue.containsAtom(atomName))
                        atom = nextResidue.getAtom(atomName);
                }
                break;
            case PREVIOUS_RESIDUE:
                if(this.getParentMacromolecule().containsPreviousResidue(this))
                {
                    Residue previousResidue = this.getParentMacromolecule().getPreviousResidue(this);
                    if(previousResidue.containsAtom(atomName))
                        atom = previousResidue.getAtom(atomName);
                }
                break;
            case ANY_RESIDUE:
                if(this.containsAtom(atomName))
                        atom = this.getAtom(atomName);
                break;
            default:
                if(this.containsAtom(atomName))
                        atom = this.getAtom(atomName);
                break;
        }
        
        return atom;
    }
    
    
    
    public Vector getBondedAtoms(Atom atom)
    {
        return getParentMacromolecule().getBondedAtoms(atom);
    }        
}
