package entangle.datastructures;

import java.io.Serializable;
import java.util.Vector;


/**
* MoleculeLabel is a tiny class to store the name of a molecule and the chain
* indentifiers that are associated with it. This class also stores MoleculeIdentifers
* which store both the model number and the chain identifier.
*/
public class MoleculeLabel implements Serializable
{
        String moleculeName;
        Vector chainIDs;
        int molID;



        public MoleculeLabel(String moleculeName,int molID)
        {
                this.moleculeName = moleculeName;
                this.chainIDs = new Vector();
				this.molID = molID;
        }



        public int getMolID()
        {
	    	return molID;
		}
        
        
        public String getMoleculeName()
        {
                return moleculeName;
        }


        public Vector getChainIDs()
        {
                return chainIDs;
        }
        
        
        public void addChainID(String chainID)
        {
                chainIDs.add(chainID);
        }
        
        
        public String toString()
        {
                String str = getMoleculeName() + ", chains: ";
                
                for(int i=0;i<chainIDs.size();i++)
                {
                        str += (String)chainIDs.get(i);
                }
                
                return str;
        }
}


