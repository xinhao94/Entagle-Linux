package entangle.datastructures;
import java.util.Hashtable;

/**
* A class which represents a PDB model or a collection of macromolecules as specified by the MODEL record
*/
public class PDBModel
{
        int modelNumber;
        Hashtable macromolecules;
        private Macromolecule lnkMacromolecule;
        
        
        
        public PDBModel(int modelNumber,Hashtable macromolecules)
        {
                this.modelNumber = modelNumber;
                this.macromolecules = macromolecules;
        }
        
        
        
        public PDBModel(int modelNumber)
        {
                this.modelNumber = modelNumber;
                macromolecules = new Hashtable();
        }
        
        
        public void setPDBModel(Hashtable macromolecules)
        {
                this.macromolecules = macromolecules;
        }
        
        
        public void addMacromolecule(Macromolecule macromolecule)
        {
                macromolecules.put(macromolecule.getChainIdentifier(),macromolecule);
        }
        
        
        public Macromolecule getMacromolecule(String chainID)
        {
                return (Macromolecule)macromolecules.get(chainID);
        }
        
        
        public int getModelNumber()
        {
                return modelNumber;
        }
        
        
        public Hashtable getMacromolecules()
        {
                return macromolecules;
        }
}
