/*
 * HydrogenInfo.java
 *
 * Created on August 22, 2000, 4:16 PM
 */

package entangle.datastructures;


/**
 *
 * @author  Jim Allers
 * @version 
 */
public class HydrogenInfo
{
	String hydrogenName;
	double torsionAngle;
	double angle;
	double distance;
    private DonorGroupGeometry lnkDonorGroupGeometry;
		
		
		
	public HydrogenInfo(String hydrogenName)
	{
		this.hydrogenName = hydrogenName;
	}
		
	public HydrogenInfo(String hydrogenName,double torsionAngle, double angle, double distance)
	{
		this.hydrogenName = hydrogenName;
		this.torsionAngle = torsionAngle;
		this.angle = angle;
		this.distance = distance;
	}
		
		
	public void setName(String hydrogenName)
	{
		this.hydrogenName = hydrogenName;
	}
		
		
	public String getName()
	{
		return hydrogenName;
	}
	
	
	public void setTorsionAngle(double torsionAngle)
	{
		this.torsionAngle = torsionAngle;
	}
	
	
	public double getTorsionAngle()
	{
		return torsionAngle;
	}
	
	
	public void setAngle(double angle)
	{
		this.angle = angle;
	}
	
	
	public double getAngle()
	{
		return angle;
	}
	
	
	public void setDistance(double distance)
	{
		this.distance = distance;
	}
	
	
	public double getDistance()
	{
		return distance;
	}
	
	
	public String toString()
	{
		return hydrogenName;
	}
}