package entangle.datastructures;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;


/**
 *  PDBInformation is a class which will store information about the PDB file, e.g.,
 *  molecule names and corresponding chain IDs
 */
public class PDBInformation implements Serializable
{
    Hashtable moleculeLabels;
    String pdbName;
    Stack compoundLines;
    private MoleculeLabel lnkMoleculeLabel;



    public PDBInformation()
    {
        moleculeLabels = new Hashtable();
    }



    public void setPDBName(String pdbName)
    {
        this.pdbName = pdbName;
    }


    public String getPDBName()
    {
        return pdbName;
    }


    public void setCompoundLines(Stack compoundLines)
    {
        this.compoundLines = compoundLines;
    }


    public Stack getCompoundLines()
    {
        return compoundLines;
    }


    public Hashtable getMoleculeLabels()
    {
        return moleculeLabels;
    }


    public Enumeration getMoleculeLabelElements()
    {
        return moleculeLabels.elements();
    }


    public int getNumberOfMoleculeLabels()
    {
        return moleculeLabels.size();
    }
    
    
    public Enumeration getMoleculeNames()
    {
        return moleculeLabels.keys();
    }


    public MoleculeLabel getMoleculeLabel(String moleculeName)
    {
        return (MoleculeLabel)moleculeLabels.get(moleculeName);
    }


    public void addMoleculeLabel(MoleculeLabel moleculeLabel)
    {
        moleculeLabels.put(moleculeLabel.getMoleculeName(),moleculeLabel);
    }

    public String toString()
    {
        return ("PDB Information " + getPDBName());
    }
}