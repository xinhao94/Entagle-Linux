/*
 * 1.2 code
 * Last Modified: 07/21/2000 - 07:49:57
 * Author: Jim Allers
 */
package entangle.datastructures;

import java.io.Serializable;

/**
 * the class which contains the two atom names of atoms who are bonded together within a residue
 */
public class Bond implements Serializable
{
    String atomName1;
    String atomName2; 	// Vector of atom names that are connected to
        				// center atom
    
    public Bond(String atomName1, String atomName2)
    {
        this.atomName1 = atomName1;
        this.atomName2 = atomName2;
    }

    
    
    public String getAtomName1()
    {
        return atomName1;
    }

    public String getAtomName2()
    {
        return atomName2;
    }
	
	public String toString()
	{
		String str = atomName1 + ", " + atomName2;
		return str;
	}
}


