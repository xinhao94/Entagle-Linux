/*
 * 1.2 code.
 * Last Modified: 07/21/2000 - 08:09:14
 * Author: Jim Allers
 */
 
package entangle.datastructures;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;


/**
 * Atom defines an atom PDB style
 *
 */
public class Atom implements Serializable
{
    private int serial;     //Atom serial number
    private String name;    //Atom name (H,C,S,P,O,N)
    private String atomType;
    private String resName; //Residue name
    private String chainID; //Chain identifier
    private int resSeq;     // Residue sequence number
    private Residue parentResidue;
    public double x;      //
    public double y;      //
    public double z;      //
       
       
       
    public Atom()
    {
    }
    
    public Atom(int serial,String name,String resName,String chainID, int resSeq,double x,double y, double z)
    {
        this.serial = serial;
        this.name = name;
        this.resName = resName;
        this.chainID = chainID;
        this.resSeq = resSeq;
        this.x = x;
        this.y = y;
        this.z = z;
        setAtomType(atomType(name));
    }
    
    
    public SimpleAtom simpleCopy(){
    	return new SimpleAtom(this);
    }
    
    
    
    
    public void setParentResidue(Residue parentResidue)
    {
        this.parentResidue = parentResidue;
    }
    
    
    public Residue getParentResidue()
    {
        return parentResidue;
    }
    
    
    
    /*
     * ouputs a string that specifies what type of atom the atom is
     * O-oxygen, N-nitrogen, P-phosphorous, S-sulfur, H-hydrogen
     */
    public String atomType(String atomName)
    {
        int index=0;
        
        char[] atomNameArray = atomName.toCharArray();
        Character[] arrayNumbers = new Character[10];
        
        arrayNumbers[0]=new Character('0');arrayNumbers[1]=new Character('1');arrayNumbers[2]=new Character('2');
        arrayNumbers[3]=new Character('3');arrayNumbers[4]=new Character('4');
        arrayNumbers[5]=new Character('5');arrayNumbers[6]=new Character('6');arrayNumbers[7]=new Character('7');
        arrayNumbers[8]=new Character('8');arrayNumbers[9]=new Character('9');
        
        List numbers = Arrays.asList(arrayNumbers);
        
        if(numbers.contains(new Character(atomName.charAt(index))))
            index++;
            
        if(atomName.charAt(index)=='C') atomType = "C";
        if(atomName.charAt(index)=='N') atomType = "N";
        if(atomName.charAt(index)=='O') atomType = "O";
        if(atomName.charAt(index)=='H') atomType = "H";
        if(atomName.charAt(index)=='P') atomType = "P";
        if(atomName.charAt(index)=='C') atomType = "C";
        if(atomName.charAt(index)=='S') atomType = "S";
        
        return atomType;
    }
        
        
    public void setSerial(int serial)
    {
        this.serial = serial;
    }


    public int getSerial()
    {
        return serial;
    }


    public void setName(String name)
    {
        this.name = name;
        this.atomType = atomType(name);
    }


    public String getName()
    {
        return name;
    }


    public String getAtomType()
    {
        return atomType;
    }


    public void setAtomType(String atomType)
    {
        this.atomType = atomType;
    }


    public void setResName(String resName)
    {
        this.resName = resName;
    }


    public String getResName()
    {
        return resName;
    }


    public void setChainID(String chainID)
    {
        this.chainID = chainID;
    }


    public String getChainID()
    {
        return chainID;
    }


    public void setResSeq(int residueNumber)
    {
        resSeq = residueNumber;
    }


    public int getResSeq()
    {
        return resSeq;
    }


    public void setX(double x)
    {
        this.x = x;
    }


    public double getX()
    {
        return x;
    }


    public void setY(double y)
    {
        this.y = y;
    }


    public double getY()
    {
        return y;
    }


    public void setZ(double z)
    {
        this.z = z;
    }


    public double getZ()
    {
        return z;
    }


    public void setCoordinates(double x, double y, double z)
    {
        setX(x);
        setY(y);
        setZ(z);
    }
    
    
    public String toString()
    {
        Integer serial = new Integer(getSerial());
        Integer resSeqInteger = new Integer(getResSeq());
        Double x = new Double(getX());
        Double y = new Double(getY());
        Double z = new Double(getZ());
        String str = getResName() + " " + resSeqInteger.toString() + " " + getName();
        
        return str;
    }
    
    
    public Vector getBondedAtoms()
    {
        return this.getParentResidue().getParentMacromolecule().getBondedAtoms(this);
    }
    
    
    public Vector getBondedAtomNames()
    {
		return this.getParentResidue().getParentMacromolecule().getBondedAtomNames(this);
    }


    public double getVanderWaalsRadius()
    {
		return this.getParentResidue().getParentMacromolecule().getVanderWaalsRadius(this);
    }
    
    
    public double getDistance(Atom atom)
    {
        double distance = 
            Math.sqrt((this.x-atom.x)*(this.x-atom.x) + (this.y-atom.y)*(this.y-atom.y) + (this.z-atom.z)*(this.z-atom.z));
        return distance;
    }
}