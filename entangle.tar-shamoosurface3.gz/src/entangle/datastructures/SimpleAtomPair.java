/*
 * Created on Jun 2, 2003
 */
package entangle.datastructures;

/**
 * <code>SimpleAtomPair</code> is a more memory efficient version of 
 * <code>AtomPair</code>
 * @author Jim Allers
 */
public class SimpleAtomPair {
	public SimpleAtom simpleAtomA;
	public SimpleAtom simpleAtomB;
	public double distance;
	
	public SimpleAtomPair(AtomPair atomPair){
		this.simpleAtomA = atomPair.getMacromoleculeAAtom().simpleCopy();
		this.simpleAtomB = atomPair.getMacromoleculeBAtom().simpleCopy();
		this.distance = atomPair.getDistance();
	}
}
