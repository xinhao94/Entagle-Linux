package entangle.gui;

import java.awt.Dimension;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import entangle.classification.NBInteractionContainer;
import entangle.datastructures.PDBInformation;
import entangle.gui.interactionsTable.EIParticipantCellRenderer;
import entangle.gui.interactionsTable.ElectrostaticInteractionTableModel;
import entangle.gui.interactionsTable.HBondParticipantCellRenderer;
import entangle.gui.interactionsTable.HydrogenBondTableModel;
import entangle.gui.interactionsTable.HydrophobicInteractionTableModel;
import entangle.gui.interactionsTable.StackingInteractionTableModel;
import entangle.gui.interactionsTable.TableSorter;
import entangle.gui.interactionsTable.VanderWaalsInteractionTableModel;
import entangle.gui.interactionsTree.InteractionTreeCellRenderer;
import entangle.gui.interactionsTree.InteractionTreeModel;
import entangle.utils.EntangleProperties;

/*
*  AnalysisTabbedPane provides the ability to view the interactions uncovered by 
*  flipping through various panes that display different types of interactions 
*/
public class AnalysisTabbedPane extends JTabbedPane
{
    AnalyzerPanel analyzerPanel;
	HydrogenBondTableModel hBondTableModel;
	ElectrostaticInteractionTableModel eiTableModel;
	VanderWaalsInteractionTableModel vanderWaalsInteractionTableModel;
	HydrophobicInteractionTableModel hydrophobicInteractionTableModel;
	StackingInteractionTableModel stackingInteractionTableModel;
    JTree allResiduesTree;
    JEditorPane allResiduesPane;
    JScrollPane hydrogenBondScrollPane,allResiduesScrollPane,electrostaticScrollPane;
    JScrollPane VanderWaalsScrollPane,hydrophobicScrollPane,stackingInteractionScrollPane;
    NBInteractionContainer container;
    PDBInformation pdbInformation;
	
    public AnalysisTabbedPane(AnalyzerPanel master)
    {
        analyzerPanel = master;
        
        ImageIcon hydrogenBondsIcon       = getEntangleImageIcon("entangle.hydrogenBondIconImage");
        ImageIcon electrostaticIcon       = getEntangleImageIcon("entangle.electrostaticIconImage");
        ImageIcon VanderWaalsIcon         = getEntangleImageIcon("entangle.VanderWaalsIconImage");
        ImageIcon hydrophobicIcon         = getEntangleImageIcon("entangle.hydrophobicIconImage");
        ImageIcon stackingInteractionIcon = getEntangleImageIcon("entangle.stackingInteractionIconImage");
        
        Dimension tabbedPaneSize = new Dimension(800, 500);
        setPreferredSize(tabbedPaneSize);
		
		hBondTableModel                  = new HydrogenBondTableModel();
		eiTableModel                     = new ElectrostaticInteractionTableModel();
		stackingInteractionTableModel    = new StackingInteractionTableModel();
		hydrophobicInteractionTableModel = new HydrophobicInteractionTableModel();
		vanderWaalsInteractionTableModel = new VanderWaalsInteractionTableModel();
        
        hydrogenBondScrollPane = 
			buildScrollPane( buildHydrogenBondTable(hBondTableModel), hydrogenBondsIcon, "Hydrogen bonds");
		electrostaticScrollPane = 
			buildScrollPane( buildElectrostaticInteractionTable(eiTableModel), 
			electrostaticIcon, "Electrostatic interactions");
        hydrophobicScrollPane = buildScrollPane( buildHydrophobicInteractionTable(
			hydrophobicInteractionTableModel), hydrophobicIcon, "Hydrophobic interactions");
		VanderWaalsScrollPane = buildScrollPane( buildVanderWaalsInteractionTable(
			vanderWaalsInteractionTableModel), VanderWaalsIcon, "van der Waals Interactions");
		stackingInteractionScrollPane = buildScrollPane( buildStackingInteractionTable(
			stackingInteractionTableModel), stackingInteractionIcon, "Stacking interactions");
        
        allResiduesTree = new JTree(new DefaultTreeModel(new DefaultMutableTreeNode("Load PDB and analyze...")));
        allResiduesTree.setCellRenderer(new InteractionTreeCellRenderer());
		allResiduesScrollPane = buildScrollPane(allResiduesTree, "All interactions by residue");
    }
    
    
    
	/*
	 * This method constructs an icon from the Entangle property which is the path
	 * for the image file
     */
	public ImageIcon getEntangleImageIcon(String entangleProperty)
	{
		return new ImageIcon(System.getProperty("user.dir") + File.separator 
					+ EntangleProperties.getProperties().getProperty(entangleProperty));
	}
	
	
    public JScrollPane buildScrollPane(JComponent jcomponent, String label)
    {
        JScrollPane scrollPane = new JScrollPane(jcomponent);
        addTab(label,scrollPane);
        
        return scrollPane;
    }
         
                
	public JScrollPane buildScrollPane(JComponent jcomponent, ImageIcon icon, String toolTipText)
	{
		JScrollPane scrollPane = new JScrollPane(jcomponent);
		addTab(null,icon,scrollPane,toolTipText);
		
		return scrollPane;
	}
	
	
	public JTable buildHydrogenBondTable(HydrogenBondTableModel hbondTableModel)
	{
		TableSorter tableSorter = new TableSorter(hbondTableModel);
		HBondParticipantCellRenderer hbpCellRenderer = new HBondParticipantCellRenderer(hbondTableModel,tableSorter);
		JTable hydrogenBondTable = new JTable(tableSorter);
		hydrogenBondTable.getColumnModel().getColumn(1).setCellRenderer(hbpCellRenderer);
		hydrogenBondTable.getColumnModel().getColumn(3).setCellRenderer(hbpCellRenderer);
		tableSorter.addMouseListenerToHeaderInTable(hydrogenBondTable);
		
		return hydrogenBondTable;
	}
	
	
	public JTable buildElectrostaticInteractionTable(ElectrostaticInteractionTableModel eiTableModel)
	{
		TableSorter tableSorter = new TableSorter(eiTableModel);
		EIParticipantCellRenderer eiCellRenderer = new EIParticipantCellRenderer(eiTableModel,tableSorter);
		JTable eiTable = new JTable(tableSorter);
		eiTable.getColumnModel().getColumn(1).setCellRenderer(eiCellRenderer);
		eiTable.getColumnModel().getColumn(3).setCellRenderer(eiCellRenderer);
		tableSorter.addMouseListenerToHeaderInTable(eiTable);
		
		return eiTable;
	}
	
	
	public JTable buildStackingInteractionTable(StackingInteractionTableModel stackingTableModel)
	{
		TableSorter tableSorter = new TableSorter(stackingTableModel);
		JTable stackingInteractionTable = new JTable(tableSorter);
		tableSorter.addMouseListenerToHeaderInTable(stackingInteractionTable);
		
		return stackingInteractionTable;
	}
	
	
	public JTable buildVanderWaalsInteractionTable(VanderWaalsInteractionTableModel vanderWaalsTableModel)
	{
		TableSorter tableSorter = new TableSorter(vanderWaalsTableModel);
		JTable vanderWaalsInteractionTable = new JTable(tableSorter);
		tableSorter.addMouseListenerToHeaderInTable(vanderWaalsInteractionTable);
		
		return vanderWaalsInteractionTable;
	}
	
	
	public JTable buildHydrophobicInteractionTable(HydrophobicInteractionTableModel hydrophobicInteractionTableModel)
	{
		TableSorter tableSorter = new TableSorter(hydrophobicInteractionTableModel);
		JTable hydrophobicInteractionTable = new JTable(tableSorter);
		tableSorter.addMouseListenerToHeaderInTable(hydrophobicInteractionTable);
		
		return hydrophobicInteractionTable;
	}
	
	
	public void setContainer(NBInteractionContainer container)
	{
		this.container = container;
	}
	
	
	public void setPDBInformation(PDBInformation pdbInformation)
	{
		this.pdbInformation = pdbInformation;
	}
	
	
    public void readClassification(NBInteractionContainer container)
    {
        this.container = container;
        this.pdbInformation = container.getPDBInformation();
        
		hBondTableModel.setValues(container.getHydrogenBonds(),
					  container.getMacromoleculeA().getChainIdentifier(),
					  container.getMacromoleculeB().getChainIdentifier());
		eiTableModel.setValues(container.getElectrostaticInteractions(),
				      container.getMacromoleculeA().getChainIdentifier(),
				      container.getMacromoleculeB().getChainIdentifier());
		hydrophobicInteractionTableModel.setValues(
					  container.getHydrophobicInteractions(),
					  container.getMacromoleculeA().getChainIdentifier(),
				      container.getMacromoleculeB().getChainIdentifier());
		stackingInteractionTableModel.setValues(
					  container.getStackingInteractions(),
					  container.getMacromoleculeA().getChainIdentifier(),
				      container.getMacromoleculeB().getChainIdentifier());
		vanderWaalsInteractionTableModel.setValues(
					  container.getVanderWaalsInteractions(),
					  container.getMacromoleculeA().getChainIdentifier(),
				      container.getMacromoleculeB().getChainIdentifier());
				      
        // rootString PDBName: Interactions between 
        String pdbName = pdbInformation.getPDBName();
        String firstChain = container.getMacromoleculeA().getChainIdentifier();
        String secondChain = container.getMacromoleculeB().getChainIdentifier();
        String rootString = pdbName + ": Interactions betweeen " + firstChain + " and " + secondChain;
        allResiduesTree.setModel(new InteractionTreeModel(new DefaultMutableTreeNode(rootString,true), container));
    }
}
