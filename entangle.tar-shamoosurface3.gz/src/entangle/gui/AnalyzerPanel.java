/*
 * 1.1 code
 * Last Modified: 07/19/2000 - 00:24:27
 * Author: Jim Allers (jima@rice.edu)
 */
package entangle.gui;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ProgressMonitorInputStream;

import entangle.classification.InteractingGroup;
import entangle.classification.NBInteractionClassifier;
import entangle.classification.NBInteractionContainer;
import entangle.classification.SimpleInteractingGroup;
import entangle.datastructures.Atom;
import entangle.datastructures.BaseInteractions;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.MoleculeLabel;
import entangle.datastructures.PDBInformation;
import entangle.datastructures.PDBModel;
import entangle.datastructures.Residue;
import entangle.gui.actions.AnalyzeAction;
import entangle.gui.actions.SaveInteractionsAction;
import entangle.gui.actions.ViewStructureAction;
import entangle.utils.EntangleProperties;
import entangle.utils.io.InteractionDocumentCreator;
import entangle.utils.io.PDBParser;
import entangle.utils.math.XYZMatrix;

/**
 * This class provides the GUI for the entangle package. It allows the user to view and
 * probe the analysis of the binding between the protein and the rna. This class 
 * also acts as the master of the program holding the data that the user 
 * is current manipulating.
 *
 * <LRM> This class is the contents of the Analyzer window.  The menubar is held in entangle.gui.Analyzer.
 */
public class AnalyzerPanel extends JPanel {
	//FIELDS /////////////////////////////////////////////////////

	Vector pdbModels;
	Hashtable currentMacromolecules;
	String proteinName = "";
	String rnaName = "";
	Macromolecule currentProtein;
	Macromolecule currentRNA;
	Macromolecule currentDNA;

	PDBInformation pdbInformation;
	NBInteractionClassifier nbInteractionClassifier;
	NBInteractionContainer nbInteractionContainer;
	InteractionDocumentCreator interactionDocumentCreator;
	Hashtable moleculeLabels;

	/**
	 * Information about the loaded file
	 */
	JComboBox proteinNamesBox;
	JComboBox proteinChainBox;
	JComboBox nucleicAcidNamesBox;
	JComboBox nucleicAcidChainBox;
	MoleculeInformationPanel moleculePanel;
	boolean loadedFile = false;

	AnalysisTabbedPane analysisTabbedPane;
	AnalysisToolBar analysisToolBar;
	public AnalyzeAction analyzeAction;
	public ViewStructureAction viewStructureAction;
	public SaveInteractionsAction saveInteractionsAction;
	public Analyzer master;

	// END OF FIELDS /////////////////////////////////////////
	//////////////////////////////////////////////////////////

	/**
	 * CONSTRUCTOR
	 *
	 *
	 */

	public AnalyzerPanel(Analyzer master) {
		this.master = master;
		interactionDocumentCreator = new InteractionDocumentCreator();
		Dimension analyzerPanelSize = new Dimension(800, 600);
		Dimension moleculeNameSize = new Dimension(300, 22);
		Dimension chainIdentifierSize = new Dimension(50, 22);
		analysisTabbedPane = new AnalysisTabbedPane(this);
		analyzeAction = new AnalyzeAction(this, analysisTabbedPane);
		analyzeAction.setEnabled(false);
		viewStructureAction = new ViewStructureAction(this);
		viewStructureAction.setEnabled(false);
		saveInteractionsAction = new SaveInteractionsAction(this);
		saveInteractionsAction.setEnabled(false);
		analysisToolBar = new AnalysisToolBar(analyzeAction, viewStructureAction);

		// combo boxes for choosing macromolecules and chains
		proteinNamesBox = new JComboBox();
		proteinNamesBox.setMinimumSize(moleculeNameSize);
		proteinNamesBox.setPreferredSize(moleculeNameSize);
		nucleicAcidNamesBox = new JComboBox();
		nucleicAcidNamesBox.setMinimumSize(moleculeNameSize);
		nucleicAcidNamesBox.setPreferredSize(moleculeNameSize);
		proteinChainBox = new JComboBox();
		nucleicAcidChainBox = new JComboBox();

		proteinNamesBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					String tempString = (String) e.getItem();
					changeChainIDs(proteinChainBox, tempString, Macromolecule.PROTEIN);
				}
			}
		});

		nucleicAcidNamesBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					String tempString = (String) e.getItem();
					changeChainIDs(nucleicAcidChainBox, tempString, Macromolecule.RNA);
				}
			}
		});

		proteinChainBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					String tempString = (String) e.getItem();
				}
			}
		});

		proteinChainBox.setPreferredSize(chainIdentifierSize);

		nucleicAcidChainBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					String tempString = (String) e.getItem();
				}
			}
		});

		nucleicAcidChainBox.setPreferredSize(chainIdentifierSize);
		moleculePanel = new MoleculeInformationPanel(proteinNamesBox, proteinChainBox, nucleicAcidNamesBox, nucleicAcidChainBox);

		createLayout(this);
	}

	// ends constructor //////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////

	/**
	 *  lays out the components for the panel
	 */
	public void createLayout(JPanel jpanel) {
		jpanel.setLayout(new BorderLayout());

		JPanel centerPanel = new JPanel();

		centerPanel.setLayout(new BorderLayout());
		centerPanel.add(moleculePanel, BorderLayout.NORTH);
		centerPanel.add(analysisTabbedPane, BorderLayout.CENTER);

		jpanel.add(analysisToolBar, BorderLayout.NORTH);
		jpanel.add(centerPanel, BorderLayout.CENTER);
	}
	//ends createLayout

	private class MoleculeInformationPanel extends JPanel {
		public MoleculeInformationPanel(
			JComboBox proteinNameBox,
			JComboBox proteinChainBox,
			JComboBox nucleicAcidNameBox,
			JComboBox nucleicAcidChainBox) {
			// do layout stuff
			FlowLayout fl = new FlowLayout(FlowLayout.CENTER, 0, 0);
			setLayout(fl);
			add(proteinNameBox);
			add(proteinChainBox);
			add(nucleicAcidNameBox);
			add(nucleicAcidChainBox);
		}
	}
	//ends MoleculeInformationPanel

	public NBInteractionContainer getNBInteractionContainer(
		Macromolecule macromoleculeA,
		Macromolecule macromoleculeB,
		PDBInformation pdbInformation) {
		//nbInteractionContainer = new NBInteractionContainer(macromoleculeA, macromoleculeB, pdbInformation);
		return nbInteractionContainer;
	}

	public void setNBInteractionContainer(NBInteractionContainer input) {
		nbInteractionContainer = input;
	}

	public Macromolecule getCurrentProtein() {
		currentProtein = (Macromolecule) currentMacromolecules.get(proteinChainBox.getSelectedItem());
		return currentProtein;
	}

	public Macromolecule getCurrentNucleicAcid() {
		currentRNA = (Macromolecule) currentMacromolecules.get(nucleicAcidChainBox.getSelectedItem());
		return currentRNA;
	}

	public PDBInformation getPDBInformation() {
		return pdbInformation;
	}

	public void setCurrentProtein(Macromolecule protein) {
		currentProtein = protein;
	}

	public void setCurrentNucleicAcid(Macromolecule nucleicAcid) {
		currentRNA = nucleicAcid;
	}

	public void setPDBInformation(PDBInformation pdbInformation) {
		this.pdbInformation = pdbInformation;
	}

	public void setClassifier(NBInteractionClassifier classifier) {
		nbInteractionClassifier = classifier;
	}

	/** 
	 * Returns a classifier which will work on the current
	 */
	public NBInteractionClassifier getClassifier() {
		if (nbInteractionClassifier != null) {
			if (!nbInteractionClassifier.getMacromoleculeA().equals(getCurrentProtein())
				|| !nbInteractionClassifier.getMacromoleculeB().equals(getCurrentNucleicAcid())) {
				nbInteractionClassifier.setMacromoleculeA(getCurrentProtein());
				nbInteractionClassifier.setMacromoleculeB(getCurrentNucleicAcid());
				nbInteractionClassifier.setPDBInformation(getPDBInformation());
			}
		}
		else {
			nbInteractionClassifier =
				new NBInteractionClassifier(
					getCurrentProtein(),
					getCurrentNucleicAcid(),
					getPDBInformation());
		}

		return nbInteractionClassifier;
	}

	public void setViewStructureActionEnabled(boolean enabled) {
		viewStructureAction.setEnabled(enabled);
	}

	public void setAnalyzeActionEnabled(boolean enabled) {
		analyzeAction.setEnabled(enabled);
	}

	public AnalysisToolBar getAnalysisToolBar() {
		return analysisToolBar;
	}

	public void changeMacromoleculeNames(String proteinOrRNA, Vector macromoleculeNames) {
		JComboBox comboBox = null;

		if (proteinOrRNA.equals(Macromolecule.PROTEIN)) {
			comboBox = proteinNamesBox;
		}
		else {
			comboBox = nucleicAcidNamesBox;
		}

		comboBox.removeAllItems();

		int size = macromoleculeNames.size();

		for (int i = 0; i < size; i++) {
			comboBox.addItem(macromoleculeNames.elementAt(i));
		}

		setAnalyzeActionEnabled(true);
	}

	/**
	 * method which changes the chainIDs in the chainIDBox
	 */
	public void changeChainIDs(JComboBox chainIDBox, String macromoleculeName, String proteinOrRNA) {
		int size = moleculeLabels.size();
		chainIDBox.removeAllItems();
		MoleculeLabel thisMoleculeLabel = null;
		final String myProteinOrRNA = proteinOrRNA;

		// check to see which moleculeLabel, this name refers to
		if (moleculeLabels.containsKey(macromoleculeName))
			thisMoleculeLabel = (MoleculeLabel) moleculeLabels.get(macromoleculeName);

		if (thisMoleculeLabel != null) {
			int numberOfChainIDs = thisMoleculeLabel.getChainIDs().size();

			for (int i = 0; i < numberOfChainIDs; i++) {
				final String currentChain = (String) thisMoleculeLabel.getChainIDs().elementAt(i);
				chainIDBox.addItem(currentChain);
			}
		}
		else {
			System.out.println("could not find " + macromoleculeName + "among MoleculeLabels");
		}
	}

	public void loadPDB(InputStream inputStream, String pdbID) {
		master.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

		PDBParser pdbParser = new PDBParser(inputStream, pdbID);

		try {
			pdbParser.parse();

			pdbInformation = pdbParser.getPDBInformation();
			pdbModels = pdbParser.getModels();

			currentMacromolecules = ((PDBModel) pdbModels.get(0)).getMacromolecules();
			moleculeLabels = pdbInformation.getMoleculeLabels();

			Vector proteinNamesVector = new Vector();
			Vector rnaNamesVector = new Vector();

			// go through the moleculeLabels and figure out if it is a protein or rna
			for (Enumeration e = moleculeLabels.elements(); e.hasMoreElements();) {
				MoleculeLabel tempMoleculeLabel = (MoleculeLabel) e.nextElement();
				String tempName = tempMoleculeLabel.getMoleculeName();

				String firstChainID;

				if (tempMoleculeLabel.getChainIDs().size() != 0) {
					firstChainID = (String) tempMoleculeLabel.getChainIDs().elementAt(0);
					Macromolecule tempMacromolecule = (Macromolecule) currentMacromolecules.get(firstChainID);

					if (tempMacromolecule.getType().equals(Macromolecule.PROTEIN)) {
						proteinNamesVector.addElement(tempName);
					}
					else {
						rnaNamesVector.addElement(tempName);
					}
				}
			} //ends for

			changeMacromoleculeNames(Macromolecule.PROTEIN, proteinNamesVector);
			changeMacromoleculeNames(Macromolecule.RNA, rnaNamesVector);

			analysisToolBar.changeStatus(pdbInformation.getPDBName() + " loaded");

			setViewStructureActionEnabled(false);
			analysisToolBar.analyzeButton.setEnabled(true);
			loadedFile = true;

			master.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		}
		catch (Exception exc) {
			JOptionPane.showMessageDialog(
				this,
				EntangleProperties.getProperties().getProperty("entangle.parserErrorMessage"),
				"Entangle Error Message",
				JOptionPane.ERROR_MESSAGE);
			exc.printStackTrace(System.out);
		}
	}

	public void loadPDBFile(File pdbFile) {
		try {
			InputStream monitoredStream = new ProgressMonitorInputStream(this, "Loading PDB file", new FileInputStream(pdbFile));
			loadPDB(monitoredStream, truncateFileName(pdbFile.getName()));
		}
		catch (FileNotFoundException fnf) {
			JOptionPane.showMessageDialog(
				this,
				EntangleProperties.getProperties().getProperty("entangle.fileNotFoundErrorMessage"),
				"Entangle Error Message",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	public boolean hasLoadedPDB() {
		return loadedFile;
	}

	/**
	 * truncateFileName loses the extension for a file name
	 */
	public String truncateFileName(String fileName) {
		String periodString = ".";
		int positionOfPeriod = fileName.lastIndexOf(periodString);
		String outputFileName = fileName.substring(0, positionOfPeriod);
		return outputFileName;
	}

	public Analyzer getMaster() {
		return master;
	}

	public void loadPDBFile() {
		// First select the PDB file
		File pdbFile;
		PDBFileFilter pdbff = new PDBFileFilter();
		JFileChooser pdbFileChooser =
			new JFileChooser(
				System.getProperty("user.dir") + File.separator + "pdb");
		pdbFileChooser.setFileFilter(pdbff);
		pdbFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		pdbFileChooser.showDialog(this, "Load");

		if (pdbFileChooser.getSelectedFile() != null) {
			loadPDBFile(pdbFileChooser.getSelectedFile());
		}
	}

	void multipleAnalysis() {
		System.out.println("APanel:MultiA: begin ");

		File[] files;
		PDBFileFilter pdbff = new PDBFileFilter();
        JFileChooser pdbFileChooser =
            new JFileChooser(
                System.getProperty("user.dir") + File.separator + "pdb");
		pdbFileChooser.setFileFilter(pdbff);
		pdbFileChooser.setMultiSelectionEnabled(true);
		pdbFileChooser.showDialog(this, "Select PDB File(s)");

		files = pdbFileChooser.getSelectedFiles();

		if (files != null && files.length > 0) {
			analysisToolBar.analyzeButton.setEnabled(false);
			analysisToolBar.viewButton.setEnabled(false);
			getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
			
			BaseInteractions aInteractions = new BaseInteractions("A");
			BaseInteractions gInteractions = new BaseInteractions("G");
			BaseInteractions cInteractions = new BaseInteractions("C");
			BaseInteractions tInteractions = new BaseInteractions("T");
			BaseInteractions uInteractions = new BaseInteractions("U");
			
			for (int file_index = 0; file_index < files.length; file_index++) {
				System.gc();  // Force Garbage Collection
				
				loadPDBFile(files[file_index]);

				try {
					System.out.println("Analyzing interactions for file " + file_index);
					setNBInteractionContainer(getClassifier().findAndClassifyInteractions());

					getAnalysisToolBar().changeStatus("Processing pdb file " + file_index);

					/*
					 * Macromolecule currentProtein;
					 * Macromolecule currentRNA;
					 * Macromolecule currentDNA;
					 * PDBInformation pdbInformation;
					 * NBInteractionClassifier nbInteractionClassifier;
					 * NBInteractionContainer nbInteractionContainer;
					 */
					Enumeration RNAresidues = currentRNA.getResidueEnumeration();

					Vector Adenines = new Vector();
					Vector Cytosines = new Vector();
					Vector Guanines = new Vector();
					Vector Thymines = new Vector();
					Vector Uracils = new Vector();

					/* Sort the RNA residues by type into separate vectors */
					System.out.println("APanel:MultiA: Sorting RNA residues by type ");

					while (RNAresidues.hasMoreElements()) {
						Residue r = (Residue) RNAresidues.nextElement();
						if (r.getResName().equals("A"))
							Adenines.add(r);
						else if (r.getResName().equals("C"))
							Cytosines.add(r);
						else if (r.getResName().equals("G"))
							Guanines.add(r);
						else if (r.getResName().equals("T"))
							Thymines.add(r);
						else if (r.getResName().equals("U"))
							Uracils.add(r);
						else
							throw new Exception("RNA residue wasn't ACGTU, was named " + r.getResName());
					}

					/**
					 * NOTES TO SELF
					 * 
					 * A,G: N7 N9 N1
					 * T,C,U: N1 N3 C5
					 */

					/*
					 * for each base type, if interactions exist, determine the new coordinate system,
					 * convert all bonds to the new coordinate system
					 */
					sortAndAdd(aInteractions, Adenines);
					sortAndAdd(gInteractions, Guanines);
					sortAndAdd(cInteractions, Cytosines);
					sortAndAdd(tInteractions, Thymines);
					sortAndAdd(uInteractions, Uracils);

					System.out.println("AP: multiA: finished transforming and compiling.");
				}
				catch (Exception exc) {
					JOptionPane.showMessageDialog(
						this,
						EntangleProperties.getProperties().getProperty("entangle.analysisErrorMessage") + "\n" + exc,
						"Entangle Error Message",
						JOptionPane.ERROR_MESSAGE);
					exc.printStackTrace(System.out);
					getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
				}
			}// end for: done going through all the pdb files
			
			System.gc(); // force garbage collection
			
			getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			System.out.println("**********************************************");
			System.out.println("* Done analyzing PDB files.  Outputting HTML *");
			System.out.println("**********************************************");
			
			getAnalysisToolBar().changeStatus("Done processing PDB files.  Outputting HTML...");

			// Save multiple interactions analysis to file
			String Axml = aInteractions.buildXML();
			String Ahtml = aInteractions.buildHTML();
			String Chtml = cInteractions.buildHTML();
			String Ghtml = gInteractions.buildHTML();
			String Thtml = tInteractions.buildHTML();
			String Uhtml = uInteractions.buildHTML();

			try{
				File htmlDir;
				JFileChooser htmlFileChooser = new JFileChooser("C://Windows//Desktop");
				htmlFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				htmlFileChooser.showDialog(this, "Select an Output Directory");
				htmlDir = htmlFileChooser.getSelectedFile();
				if (htmlDir != null) {
					File outputFile = new File(htmlDir.getCanonicalPath() + "//" + "adenine.xml");
					if (outputFile.exists())
						outputFile.delete();
					FileOutputStream fos = new FileOutputStream(outputFile);
					fos.write(Axml.getBytes());
					fos.flush();
					fos.close();
	
					outputFile = new File(htmlDir.getCanonicalPath() + "//" + "adenine.html");
					if (outputFile.exists())
						outputFile.delete();
					fos = new FileOutputStream(outputFile);
					fos.write(Ahtml.getBytes());
					fos.flush();
					fos.close();

					outputFile = new File(htmlDir.getCanonicalPath() + "//" + "cytosine.html");
					if (outputFile.exists())
						outputFile.delete();
					fos = new FileOutputStream(outputFile);
					fos.write(Chtml.getBytes());
					fos.flush();
					fos.close();
	
					outputFile = new File(htmlDir.getCanonicalPath() + "//" + "guanine.html");
					if (outputFile.exists())
						outputFile.delete();
					fos = new FileOutputStream(outputFile);
					fos.write(Ghtml.getBytes());
					fos.flush();
					fos.close();
	
					outputFile = new File(htmlDir.getCanonicalPath() + "//" + "thymine.html");
					if (outputFile.exists())
						outputFile.delete();
					fos = new FileOutputStream(outputFile);
					fos.write(Thtml.getBytes());
					fos.flush();
					fos.close();
	
					outputFile = new File(htmlDir.getCanonicalPath() + "//" + "uracil.html");
					if (outputFile.exists())
						outputFile.delete();
					fos = new FileOutputStream(outputFile);
					fos.write(Uhtml.getBytes());
					fos.flush();
					fos.close();
				}
				else {
					System.out.println("********** You didn't select a file! ************");
				}
			}
			catch(Exception e){
				System.out.println("An exception occurred while attempting to write HTML output files.");
				e.printStackTrace();
			}
		} // end if: there were files, and we're done processing and outputting data

		getAnalysisToolBar().changeStatus("Finished outputting HTML.");
		System.out.println("APanel:MultiA: END");
	}

	/**
	 * Given a BaseInteracctions and a Vector of InteractingGroups for a single NA base type,
	 * convert the coordinates for the residues and then add to the BaseInteractions
	 */
	public void sortAndAdd(BaseInteractions ints, Vector residues) {
		String a1;
		String a2;
		String a3;
		/*
		 * for each Residue, if interactions exist, determine the new coordinate system,
		 * convert all bonds to the new coordinate system
		 */
		System.out.println("APanel:MultiA:ResidueLoop: begin.  Residue = " + ints.baseType);

		if (ints.baseType.equals("A") || ints.baseType.equals("G")) {
			a1 = "N7";
			a2 = "N9";
			a3 = "N1";
		}
		else if (ints.baseType.equals("C") || ints.baseType.equals("U") || ints.baseType.equals("T")) {
			a1 = "N1";
			a2 = "N3";
			a3 = "C5";
		}
		else
			throw new IllegalArgumentException("Base type for the given BaseInteractions is not a valid type.  Received " + ints.baseType);

		while (residues.size() > 0) {

			Residue r = (Residue) residues.remove(0);
			InteractingGroup ig = nbInteractionContainer.getInteractingGroup(r);

			if ((ig != null) && ig.containsAnInteraction()) {
				// get the three new coordinate atoms
				Atom N7 = r.getAtom(a1);
				Atom N9 = r.getAtom(a2);
				Atom N1 = r.getAtom(a3);

				XYZMatrix A = new XYZMatrix(N7.getX(), N7.getY(), N7.getZ());
				XYZMatrix B = new XYZMatrix(N9.getX(), N9.getY(), N9.getZ());
				XYZMatrix C = new XYZMatrix(N1.getX(), N1.getY(), N1.getZ());

				/* first transformation is translation from A to the origin */
				XYZMatrix translation = A;
				//A = (XYZMatrix) A.subtract(translation);
				B = (XYZMatrix) B.subtract(translation);
				C = (XYZMatrix) C.subtract(translation);

				/**
				 * ROTATIONS 
				 *
				 * Spherical coordinates:
				 * x,y,z -> r,theta,phi
				 * 
				 * r = length
				 * theta = angle in x-y plane from positive x-axis, [0,2pi)
				 * phi = angle from positive z-axis, [0,pi]
				 *
				 * double r = Math.sqrt(x*x + y*y + z*z);
				 * double theta = Math.atan2(y,x);
				 * double phi = Math.acos(z/r);
				 */
				double rotation1 = 0 - B.getXYTheta();
				B.applyXYRotation(rotation1);
				C.applyXYRotation(rotation1);
				double rotation2 = Math.PI / 2 - B.getZXTheta();
				//B.applyZXRotation(rotation2);
				C.applyZXRotation(rotation2);
				double rotation3 = 0 - C.getYZTheta();
				//B.applyYZRotation(rotation3);
				//C.applyYZRotation(rotation3);

				//NOW, apply the transformation
				SimpleInteractingGroup sig = ig.simpleCopy();

				sig.transform(translation, rotation1, rotation2, rotation3);

				// add new adenine interaction information to the previous record
				if (ints.genericBase == null)
					ints.genericBase = sig.nucleicAcidResidue;
				ints.Proteins.addAll(sig.interactingProteinResidues);
				ints.Hbonds.addAll(sig.hydrogenBonds);
				ints.Hinter.addAll(sig.hydrophobicInteractions);
				ints.Einter.addAll(sig.electrostaticInteractions);
				ints.Vinter.addAll(sig.vanderWaalsInteractions);
				ints.Sinter.addAll(sig.stackingInteractions);
				ints.CPinter.addAll(sig.cationPiInteractions);
			}
		}
	}
}