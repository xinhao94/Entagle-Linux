/*
 * StackingInteractionTableModel.java
 *
 * Created on December 14, 2000, 10:25 PM
 */

package entangle.gui.interactionsTable;

import java.util.Vector;

import entangle.classification.stacking.StackingInteraction;
import entangle.datastructures.Residue;


/**
 *
 * @author  Jim Allers
 * @version 
 */
public class StackingInteractionTableModel extends javax.swing.table.AbstractTableModel
{
	String[] columnNames = {
				"Protein Residue", 
				"Nucleic Acid Residue",
				"Center-to-Center Distance",
				"Dihedral Angle",
				"Degree of Staggeredness"
				};
				
	String proteinChainID;
	String nucleicAcidChainID;
	Vector stackingInteractions;
	final int PROTEIN_RESIDUE_NAME = 0;
	final int NUCLEIC_ACID_RESIDUE_NAME = 1;
	final int CENTER_TO_CENTER_DISTANCE = 2;
	final int DIHEDRAL_ANGLE = 3;
	final int DEGREE_OF_STAGGEREDNESS = 4;
	
	
	
	/** Creates new StackingInteractionTableModel */
	public StackingInteractionTableModel() 
	{
	}
    	/** Creates new StackingInteractionTableModel */
	public StackingInteractionTableModel(Vector stackingInteractions,String proteinChainID, String nucleicAcidChainID)
	{
		this.stackingInteractions = stackingInteractions;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
	}
	
	
	
	
	
	public void setValues(Vector stackingInteractions, String proteinChainID, String nucleicAcidChainID)
	{
		this.stackingInteractions = stackingInteractions;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
		
		fireTableDataChanged();
	}
	
	
	
	public void addStackingInteraction(StackingInteraction stackingInteraction)
	{
		stackingInteractions.add(stackingInteraction);
		
		fireTableRowsInserted(stackingInteractions.size(),stackingInteractions.size());
	}
	
	
	
	public int getRowCount()
	{
		int numberOfStackingInteractions = 0;
		if(stackingInteractions!=null)
			numberOfStackingInteractions = stackingInteractions.size();
			
		return numberOfStackingInteractions;
	}



	public String getColumnName(int column)
	{
		return columnNames[column];
	}



	public int getColumnCount()
	{
		return columnNames.length;
	}



	public Object getValueAt(int row, int column)
	{
		StackingInteraction tempStackingInteraction = getStackingInteractionAtRow(row);
		Object value = null;
		Residue proteinResidue = null;
		Residue nucleicAcidResidue = null;
		
		switch(column)
		{
			case PROTEIN_RESIDUE_NAME:
				proteinResidue = getProteinResidue(tempStackingInteraction);
				value = proteinResidue.getResName() + " " + proteinResidue.getResidueSequenceNumber();
				break;
				
			case NUCLEIC_ACID_RESIDUE_NAME:
				nucleicAcidResidue = getNucleicAcidResidue(tempStackingInteraction);
				value = nucleicAcidResidue.getResName() + " " + nucleicAcidResidue.getResidueSequenceNumber();
				break;
				
			case CENTER_TO_CENTER_DISTANCE:
				value = doubleToRoundedString(tempStackingInteraction.getCenterToCenterDistance(), 5);
				break;
				
			case DEGREE_OF_STAGGEREDNESS:
				value = doubleToRoundedString(tempStackingInteraction.getDegreeOfStaggeredness(), 5);
				break;
				
			case DIHEDRAL_ANGLE:
				value = doubleToRoundedString(tempStackingInteraction.getDihedralAngle(), 5);
				break;
				
			default:
		}
		
		
		return value;
	}



	public String doubleToRoundedString(double value, int length)
	{
		StringBuffer stringBuffer = new StringBuffer(Double.toString(value));
		String roundedString = "";
		int lastNumber = 0;
		int afterLastNumber = 0;
		
		try
		{
			lastNumber = Integer.parseInt(stringBuffer.substring(length-1,length));
			afterLastNumber = Integer.parseInt(stringBuffer.substring(length,length+1));
		}
		catch(NumberFormatException e)
		{
			e.printStackTrace(System.out);
		}
		
		if(afterLastNumber<5)
		{
			roundedString = stringBuffer.substring(0,length);
		}
		else
		{
			 roundedString = stringBuffer.replace(length-1,length, Integer.toString(++lastNumber)).substring(0,length);
		}
		
		
		return roundedString; 
	}
	
	
	
	public StackingInteraction getStackingInteractionAtRow(int r)
	{
		return (StackingInteraction)stackingInteractions.get(r);
	}
	
	
	
	public Residue getProteinResidue(StackingInteraction stackingInteraction)
	{
		return whichIsProteinResidue(stackingInteraction.getResidueA(), stackingInteraction.getResidueB());
	}
	
	
	
	public Residue getNucleicAcidResidue(StackingInteraction stackingInteraction)
	{
		return whichIsNucleicAcidResidue(stackingInteraction.getResidueA(), stackingInteraction.getResidueB());
	}
	
	
	
	public Residue whichIsProteinResidue(Residue residueA, Residue residueB)
	{
		Residue proteinResidue;
		
		if(residueA.getChainID().equals(proteinChainID))
		{
			proteinResidue = residueA;
		}
		else
		{
			proteinResidue = residueB;
		}
		
		
		return proteinResidue;
	}



	public Residue whichIsNucleicAcidResidue(Residue residueA, Residue residueB)
	{
		Residue nucleicAcidResidue;
		
		if(residueA.getChainID().equals(nucleicAcidChainID))
		{
			nucleicAcidResidue = residueA;
		}
		else
		{
			nucleicAcidResidue = residueB;
		}
		
		
		return nucleicAcidResidue;
	}
}