/*
 * ElectrostaticInteractionTableModel.java
 *
 * Created on December 14, 2000, 9:27 PM
 */

package entangle.gui.interactionsTable;

import java.util.Vector;

import entangle.classification.electrostatic.ElectrostaticInteraction;
import entangle.datastructures.Atom;




/**
 *
 * @author  Jim Allers
 * @version 
 */
public class ElectrostaticInteractionTableModel extends javax.swing.table.AbstractTableModel 
{
	String[] columnNames = {"Protein Residue", "Protein Atom", "Nucleic Acid Residue","Nucleic Acid Atom", "Distance"};
	String proteinChainID;
	String nucleicAcidChainID;
	Vector electrostaticInteractions;
	final int PROTEIN_RESIDUE_NAME = 0;
	final int PROTEIN_ATOM_NAME = 1;
	final int NUCLEIC_ACID_RESIDUE_NAME = 2;
	final int NUCLEIC_ACID_ATOM = 3;
	final int DISTANCE = 4;
	
	
	
	public ElectrostaticInteractionTableModel()
	{
	}
	
	
	
    /** Creates new ElectrostaticInteractionTableModel */
	public ElectrostaticInteractionTableModel(Vector electrostaticInteractions, String proteinChainID, String nucleicAcidChainID)
	{
		this.electrostaticInteractions = electrostaticInteractions;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
	}
	
	
	public void setValues(Vector electrostaticInteractions, String proteinChainID, String nucleicAcidChainID)
	{
		this.electrostaticInteractions = electrostaticInteractions;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
		fireTableDataChanged();
	}
	
	
	public void addElectrostaticInteraction(ElectrostaticInteraction electrostaticInteraction)
	{
		electrostaticInteractions.add(electrostaticInteraction);
		fireTableRowsInserted(electrostaticInteractions.size(),electrostaticInteractions.size());
	}
	
	
	public int getRowCount()
	{
		int numberOfElectrostaticInteractions = 0;
		if(electrostaticInteractions!=null)
			numberOfElectrostaticInteractions = electrostaticInteractions.size();
			
		return numberOfElectrostaticInteractions;
	}


	public String getColumnName(int column)
	{
		return columnNames[column];
	}


	public int getColumnCount()
	{
		return columnNames.length;
	}


	public Object getValueAt(int row, int column)
	{
		ElectrostaticInteraction tempElectrostaticInteraction = getElectrostaticInteractionAtRow(row);
		Object value = null;
		Atom proteinAtom = null;
		Atom nucleicAcidAtom = null;
		
		switch(column)
		{
			case PROTEIN_RESIDUE_NAME:
				proteinAtom = getProteinAtom(tempElectrostaticInteraction);
				value = proteinAtom.getResName() + " " + proteinAtom.getResSeq();
				break;
			case PROTEIN_ATOM_NAME:
				proteinAtom = getProteinAtom(tempElectrostaticInteraction);
				value = proteinAtom.getName();
				break;
			case NUCLEIC_ACID_RESIDUE_NAME:
				nucleicAcidAtom = getNucleicAcidAtom(tempElectrostaticInteraction);
				value = nucleicAcidAtom.getResName() + " " + nucleicAcidAtom.getResSeq();
				break;
			case NUCLEIC_ACID_ATOM:
				nucleicAcidAtom = getNucleicAcidAtom(tempElectrostaticInteraction);
				value = nucleicAcidAtom.getName();
				break;
			case DISTANCE:
				value = doubleToRoundedString(tempElectrostaticInteraction.getDistance(), 5);
				break;
			default:
		}
		
		return value;
	}

	public String doubleToRoundedString(double value, int length)
	{
		StringBuffer stringBuffer = new StringBuffer(Double.toString(value));
		String roundedString = "";
		int lastNumber = 0;
		int afterLastNumber = 0;
		
		try
		{
			lastNumber = Integer.parseInt(stringBuffer.substring(length-1,length));
			afterLastNumber = Integer.parseInt(stringBuffer.substring(length,length+1));
		}
		catch(NumberFormatException e)
		{
			e.printStackTrace(System.out);
		}
		
		if(afterLastNumber<5)
		{
			roundedString = stringBuffer.substring(0,length);
		}
		else
		{
			 roundedString = stringBuffer.replace(length-1,length, Integer.toString(++lastNumber)).substring(0,length);
		}
		
		return roundedString; 
	}
	
	
	
	public ElectrostaticInteraction getElectrostaticInteractionAtRow(int r)
	{
		return (ElectrostaticInteraction)electrostaticInteractions.get(r);
	}
	
	
	public Atom getProteinAtom(ElectrostaticInteraction electrostaticInteraction)
	{
		return whichIsProteinAtom(electrostaticInteraction.getPositiveAtom(), electrostaticInteraction.getNegativeAtom());
	}
	
	
	public Atom getNucleicAcidAtom(ElectrostaticInteraction electrostaticInteraction)
	{
		return whichIsNucleicAcidAtom(electrostaticInteraction.getPositiveAtom(), electrostaticInteraction.getNegativeAtom());
	}
	
	
	public Atom whichIsProteinAtom(Atom positive, Atom negative)
	{
		Atom proteinAtom;
		
		if(positive.getChainID().equals(proteinChainID))
		{
			proteinAtom = positive;
		}
		else
		{
			proteinAtom = negative;
		}
		
		return proteinAtom;
	}


	public Atom whichIsNucleicAcidAtom(Atom positive, Atom negative)
	{
		Atom nucleicAcidAtom;
		
		if(positive.getChainID().equals(nucleicAcidChainID))
		{
			nucleicAcidAtom = positive;
		}
		else
		{
			nucleicAcidAtom = negative;
		}
		
		return nucleicAcidAtom;
	}
}