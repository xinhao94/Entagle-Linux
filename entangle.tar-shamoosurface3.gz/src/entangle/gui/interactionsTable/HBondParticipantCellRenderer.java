/*
 * HBondParticipantCellRenderer.java
 *
 * Created on September 28, 2000, 12:44 PM
 */

package entangle.gui.interactionsTable;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;


/**
 *
 * @author  Jim Allers
 * @version 
 */
public class HBondParticipantCellRenderer extends javax.swing.table.DefaultTableCellRenderer
{
    HydrogenBondTableModel hydrogenBondTableModel;
    TableSorter tableSorter;
    
    
    /** Creates new HBondParticipantCellRenderer */
    public HBondParticipantCellRenderer(HydrogenBondTableModel hydrogenBondTableModel, TableSorter tableSorter) 
    {
		this.hydrogenBondTableModel = hydrogenBondTableModel;
		this.tableSorter = tableSorter;
    }



    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
		Color foregroundColor = new Color(50,50,150);
		
		if(value.equals(hydrogenBondTableModel.getHydrogenBondAtRow(tableSorter.indexes[row]).getAcceptor().getName()))
		{
			foregroundColor = new Color(150,50,50);
		}
		
		setForeground(foregroundColor);
		
		return super.getTableCellRendererComponent(table,value,isSelected,hasFocus,row,column);
    }
}