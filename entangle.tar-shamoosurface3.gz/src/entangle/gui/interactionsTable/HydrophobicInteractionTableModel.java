/*
 * HydrophobicInteractionTableModel.java
 *
 * Created on December 14, 2000, 10:26 PM
 */

package entangle.gui.interactionsTable;

import java.util.Vector;

import entangle.classification.hydrophobic.HydrophobicInteraction;
import entangle.datastructures.Atom;



/**
 *
 * @author  Jim Allers
 * @version 
 */
public class HydrophobicInteractionTableModel extends javax.swing.table.AbstractTableModel
{
	String[] columnNames = {
				"Protein Residue", "Protein Atom", 
				"Nucleic Acid Residue","Nucleic Acid Atom",
				"Distance",
				};
				
	String proteinChainID;
	String nucleicAcidChainID;
	Vector hydrophobicInteractions;
	final int PROTEIN_RESIDUE_NAME = 0;
	final int PROTEIN_ATOM_NAME = 1;
	final int NUCLEIC_ACID_RESIDUE_NAME = 2;
	final int NUCLEIC_ACID_ATOM = 3;
	final int DISTANCE = 4;
	
	
	public HydrophobicInteractionTableModel()
	{
	}
	
    /** Creates new HydrophobicInteractionTableModel */
	public HydrophobicInteractionTableModel(Vector hydrophobicInteractions, String proteinChainID, String nucleicAcidChainID)
	{
		this.hydrophobicInteractions = hydrophobicInteractions;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
	}
	
	
	
	
	public void setValues(Vector hydrophobicInteractions, String proteinChainID, String nucleicAcidChainID)
	{
		this.hydrophobicInteractions = hydrophobicInteractions;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
		
		fireTableDataChanged();
	}
	
	
	
	public void addHydrophobicInteraction(HydrophobicInteraction hydrophobicInteraction)
	{
		hydrophobicInteractions.add(hydrophobicInteraction);
		
		fireTableRowsInserted(hydrophobicInteractions.size(), hydrophobicInteractions.size());
	}
	
	
	
	public int getRowCount()
	{
		int numberOfHydrophobicInteractions = 0;
		if(hydrophobicInteractions!=null)
			numberOfHydrophobicInteractions = hydrophobicInteractions.size();
			
		return numberOfHydrophobicInteractions;
	}



	public String getColumnName(int column)
	{
		return columnNames[column];
	}



	public int getColumnCount()
	{
		return columnNames.length;
	}



	public Object getValueAt(int row, int column)
	{
		HydrophobicInteraction tempHydrophobicInteraction = getHydrophobicInteractionAtRow(row);
		Object value = null;
		Atom proteinAtom = null;
		Atom nucleicAcidAtom = null;
		
		switch(column)
		{
			case PROTEIN_RESIDUE_NAME:
				proteinAtom = getProteinAtom(tempHydrophobicInteraction);
				value = proteinAtom.getResName() + " " + proteinAtom.getResSeq();
				break;
				
			case PROTEIN_ATOM_NAME:
				proteinAtom = getProteinAtom(tempHydrophobicInteraction);
				value = proteinAtom.getName();
				break;
				
			case NUCLEIC_ACID_RESIDUE_NAME:
				nucleicAcidAtom = getNucleicAcidAtom(tempHydrophobicInteraction);
				value = nucleicAcidAtom.getResName() + " " + nucleicAcidAtom.getResSeq();
				break;
				
			case NUCLEIC_ACID_ATOM:
				nucleicAcidAtom = getNucleicAcidAtom(tempHydrophobicInteraction);
				value = nucleicAcidAtom.getName();
				break;
				
			case DISTANCE:
				value = doubleToRoundedString(tempHydrophobicInteraction.distance, 5);
				break;
				
			default:
		}
		
		return value;
	}



	public String doubleToRoundedString(double value, int length)
	{
		StringBuffer stringBuffer = new StringBuffer(Double.toString(value));
		String roundedString = "";
		int lastNumber = 0;
		int afterLastNumber = 0;
		
		try
		{
			lastNumber = Integer.parseInt(stringBuffer.substring(length-1,length));
			afterLastNumber = Integer.parseInt(stringBuffer.substring(length,length+1));
		}
		catch(NumberFormatException e)
		{
			e.printStackTrace(System.out);
		}
		
		if(afterLastNumber<5)
		{
			roundedString = stringBuffer.substring(0,length);
		}
		else
		{
			 roundedString = stringBuffer.replace(length-1,length, Integer.toString(++lastNumber)).substring(0,length);
		}
		
		
		return roundedString; 
	}
	
	
	
	public HydrophobicInteraction getHydrophobicInteractionAtRow(int r)
	{
		return (HydrophobicInteraction)hydrophobicInteractions.get(r);
	}
	
	
	
	public Atom getProteinAtom(HydrophobicInteraction hydrophobicInteraction)
	{
		return whichIsProteinAtom(hydrophobicInteraction.getNonPolarAtomA(), hydrophobicInteraction.getNonPolarAtomB());
	}
	
	
	
	public Atom getNucleicAcidAtom(HydrophobicInteraction hydrophobicInteraction)
	{
		return whichIsNucleicAcidAtom(hydrophobicInteraction.getNonPolarAtomA(), hydrophobicInteraction.getNonPolarAtomB());
	}
	
	
	
	public Atom whichIsProteinAtom(Atom atomA, Atom atomB)
	{
		Atom proteinAtom;
		
		if(atomA.getChainID().equals(proteinChainID))
		{
			proteinAtom = atomA;
		}
		else
		{
			proteinAtom = atomB;
		}
		
		
		return proteinAtom;
	}



	public Atom whichIsNucleicAcidAtom(Atom atomA, Atom atomB)
	{
		Atom nucleicAcidAtom;
		
		if(atomA.getChainID().equals(nucleicAcidChainID))
		{
			nucleicAcidAtom = atomA;
		}
		else
		{
			nucleicAcidAtom = atomB;
		}
		
		
		return nucleicAcidAtom;
	}
}