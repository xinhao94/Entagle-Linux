/*
 * HydrogenBondTableModel.java
 *
 * Created on September 28, 2000, 10:25 AM
 */

package entangle.gui.interactionsTable;

import java.util.Vector;

import entangle.classification.hbonds.HydrogenBond;
import entangle.datastructures.Atom;


/**
 *
 * @author  Jim Allers
 * @version 
 */
public class HydrogenBondTableModel extends javax.swing.table.AbstractTableModel
{
	String[] columnNames = {
				"Protein Residue", "Protein Atom", 
				"Nucleic Acid Residue","Nucleic Acid Atom",
				"Donor To Acceptor Distance",
				"Hydrogen To Acceptor Distance",
				"Donor-Hydrogen-Acceptor Angle"
				};
				
	String proteinChainID;
	String nucleicAcidChainID;
	Vector hydrogenBonds;
	
	final int PROTEIN_RESIDUE_NAME = 0;
	final int PROTEIN_ATOM_NAME = 1;
	final int NUCLEIC_ACID_RESIDUE_NAME = 2;
	final int NUCLEIC_ACID_ATOM = 3;
	final int DONOR_TO_ACCEPTOR_DISTANCE = 4;
	final int HYDROGEN_TO_ACCEPTOR_DISTANCE = 5;
	final int D_H_A_ANGLE = 6;
	
	
	public HydrogenBondTableModel()
	{
	}
	

    /** Creates new HydrogenBondTableModel */
	public HydrogenBondTableModel(Vector hydrogenBonds,String proteinChainID, String nucleicAcidChainID)
	{
		this.hydrogenBonds = hydrogenBonds;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
	}
	
	
	
	
	
	public void setValues(Vector hydrogenBonds, String proteinChainID, String nucleicAcidChainID)
	{
		this.hydrogenBonds = hydrogenBonds;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
		
		fireTableDataChanged();
	}
	
	
	
	public void addHydrogenBond(HydrogenBond hydrogenBond)
	{
		hydrogenBonds.add(hydrogenBond);
		
		fireTableRowsInserted(hydrogenBonds.size(),hydrogenBonds.size());
	}
	
	
	
	public int getRowCount()
	{
		int numberOfHydrogenBonds = 0;
		if(hydrogenBonds!=null)
			numberOfHydrogenBonds = hydrogenBonds.size();
			
		return numberOfHydrogenBonds;
	}



	public String getColumnName(int column)
	{
		return columnNames[column];
	}



	public int getColumnCount()
	{
		return columnNames.length;
	}



	public Object getValueAt(int row, int column)
	{
		HydrogenBond tempHydrogenBond = getHydrogenBondAtRow(row);
		Object value = null;
		Atom proteinAtom = null;
		Atom nucleicAcidAtom = null;
		
		switch(column)
		{
			case PROTEIN_RESIDUE_NAME:
				proteinAtom = getProteinAtom(tempHydrogenBond);
				value = proteinAtom.getResName() + " " + proteinAtom.getResSeq();
				break;
			
			case PROTEIN_ATOM_NAME:
				proteinAtom = getProteinAtom(tempHydrogenBond);
				value = proteinAtom.getName();
				break;
			
			case NUCLEIC_ACID_RESIDUE_NAME:
				nucleicAcidAtom = getNucleicAcidAtom(tempHydrogenBond);
				value= nucleicAcidAtom.getResName() + " " + nucleicAcidAtom.getResSeq();
				break;
			
			case NUCLEIC_ACID_ATOM:
				nucleicAcidAtom = getNucleicAcidAtom(tempHydrogenBond);
				value= nucleicAcidAtom.getName();
				break;
			
			case DONOR_TO_ACCEPTOR_DISTANCE:
				value = doubleToRoundedString(tempHydrogenBond.getDonorToAcceptorDistance(), 5);
				break;
			
			case HYDROGEN_TO_ACCEPTOR_DISTANCE:
				value = doubleToRoundedString(tempHydrogenBond.getHydrogenToAcceptorDistance(), 5);
				break;
			
			case D_H_A_ANGLE:
				value = doubleToRoundedString(tempHydrogenBond.getD_H_A_Angle(),5);
				break;
			
			default:
		}
		
		
		return value;
	}
	
	
	
	public String doubleToRoundedString(double value, int length)
	{
		StringBuffer stringBuffer = new StringBuffer(Double.toString(value));
		String roundedString = "";
		int lastNumber = 0;
		int afterLastNumber = 0;
		
		try
		{
			lastNumber = Integer.parseInt(stringBuffer.substring(length-1,length));
			afterLastNumber = Integer.parseInt(stringBuffer.substring(length,length+1));
		}
		catch(NumberFormatException e)
		{
			e.printStackTrace(System.out);
		}
		
		if(afterLastNumber<5)
		{
			roundedString = stringBuffer.substring(0,length);
		}
		else
		{
			 roundedString = stringBuffer.replace(length-1,length, Integer.toString(++lastNumber)).substring(0,length);
		}
		
		
		return roundedString; 
	}
	
	
	
	public HydrogenBond getHydrogenBondAtRow(int r)
	{
		return (HydrogenBond)hydrogenBonds.get(r);
	}
	
	
	
	public Atom getProteinAtom(HydrogenBond hydrogenBond)
	{
		return whichIsProteinAtom(hydrogenBond.getDonor(), hydrogenBond.getAcceptor());
	}
	
	
	
	public Atom getNucleicAcidAtom(HydrogenBond hydrogenBond)
	{
		return whichIsNucleicAcidAtom(hydrogenBond.getDonor(), hydrogenBond.getAcceptor());
	}
	
	
	
	public Atom whichIsProteinAtom(Atom donor, Atom acceptor)
	{
		Atom proteinAtom;
		
		if(donor.getChainID().equals(proteinChainID))
		{
			proteinAtom = donor;
		}
		else
		{
			proteinAtom = acceptor;
		}
		
		return proteinAtom;
	}



	public Atom whichIsNucleicAcidAtom(Atom donor, Atom acceptor)
	{
		Atom nucleicAcidAtom;
		
		if(donor.getChainID().equals(nucleicAcidChainID))
		{
			nucleicAcidAtom = donor;
		}
		else
		{
			nucleicAcidAtom = acceptor;
		}
		
		return nucleicAcidAtom;
	}
}