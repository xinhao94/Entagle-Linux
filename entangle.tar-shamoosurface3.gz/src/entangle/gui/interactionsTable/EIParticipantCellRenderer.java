/*
 * EIParticipantCellRenderer.java
 *
 * Created on December 14, 2000, 9:47 PM
 */

package entangle.gui.interactionsTable;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;




/**
 *
 * @author  Jim Allers
 * @version 
 */
public class EIParticipantCellRenderer extends javax.swing.table.DefaultTableCellRenderer
{
	ElectrostaticInteractionTableModel electrostaticInteractionTableModel;
    TableSorter tableSorter;
   	
   	
   	
   	/** Creates new EIParticipantCellRenderer */
	public EIParticipantCellRenderer(ElectrostaticInteractionTableModel electrostaticInteractionTableModel, TableSorter tableSorter) 
	{
		this.electrostaticInteractionTableModel = electrostaticInteractionTableModel;
		this.tableSorter = tableSorter;
	}
	
    
    
    
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
		Color foregroundColor = new Color(50,50,150);
		
		if(value.equals(electrostaticInteractionTableModel.getElectrostaticInteractionAtRow(tableSorter.indexes[row]).getNegativeAtom().getName()))
		{
			foregroundColor = new Color(150,50,50);
		}
		
		setForeground(foregroundColor);
		
		return super.getTableCellRendererComponent(table,value, isSelected,hasFocus, row, column);
	}
}