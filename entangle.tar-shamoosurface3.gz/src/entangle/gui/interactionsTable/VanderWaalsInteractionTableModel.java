/*
 * VanderWaalTableModel.java
 *
 * Created on December 14, 2000, 10:27 PM
 */

package entangle.gui.interactionsTable;

import java.util.Vector;

import entangle.classification.vanderwaals.VanderWaalsInteraction;
import entangle.datastructures.Atom;


/**
 *
 * @author  Jim Allers
 * @version 
 */
public class VanderWaalsInteractionTableModel extends javax.swing.table.AbstractTableModel
{
	String[] columnNames = {
				"Protein Residue", "Protein Atom", 
				"Nucleic Acid Residue","Nucleic Acid Atom",
				"Distance",
				"Effective Distance",
				};
				
	String proteinChainID;
	String nucleicAcidChainID;
	Vector vanderWaalsInteractions;
	final int PROTEIN_RESIDUE_NAME = 0;
	final int PROTEIN_ATOM_NAME = 1;
	final int NUCLEIC_ACID_RESIDUE_NAME = 2;
	final int NUCLEIC_ACID_ATOM = 3;
	final int DISTANCE = 4;
	final int EFFECTIVE_DISTANCE = 5;
	
	
	public VanderWaalsInteractionTableModel()
	{
	}
	
    /** Creates new VanderWaalsInteractionTableModel */
	public VanderWaalsInteractionTableModel(Vector vanderWaalsInteractions, String proteinChainID, String nucleicAcidChainID)
	{
		this.vanderWaalsInteractions = vanderWaalsInteractions;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
	}
	
	
	
	
	
	public void setValues(Vector vanderWaalsInteractions, String proteinChainID, String nucleicAcidChainID)
	{
		this.vanderWaalsInteractions = vanderWaalsInteractions;
		this.proteinChainID = proteinChainID;
		this.nucleicAcidChainID = nucleicAcidChainID;
		fireTableDataChanged();
	}
	
	
	
	public void addVanderWaalsInteraction(VanderWaalsInteraction vanderWaalsInteraction)
	{
		vanderWaalsInteractions.add(vanderWaalsInteraction);
		fireTableRowsInserted(vanderWaalsInteractions.size(),
				      vanderWaalsInteractions.size());
	}
	
	
	
	public int getRowCount()
	{
		int numberOfVanderWaalsInteractions = 0;
		
		if(vanderWaalsInteractions!=null)
			numberOfVanderWaalsInteractions = vanderWaalsInteractions.size();
			
		return numberOfVanderWaalsInteractions;
	}



	public String getColumnName(int column)
	{
		return columnNames[column];
	}



	public int getColumnCount()
	{
		return columnNames.length;
	}



	public Object getValueAt(int row, int column)
	{
		VanderWaalsInteraction tempVanderWaalsInteraction = getVanderWaalsInteractionAtRow(row);
		Object value = null;
		Atom proteinAtom = null;
		Atom nucleicAcidAtom = null;
		
		switch(column)
		{
			case PROTEIN_RESIDUE_NAME:
				proteinAtom = getProteinAtom(tempVanderWaalsInteraction);
				value = proteinAtom.getResName() + " " + proteinAtom.getResSeq();
				break;
				
			case PROTEIN_ATOM_NAME:
				proteinAtom = getProteinAtom(tempVanderWaalsInteraction);
				value = proteinAtom.getName();
				break;
				
			case NUCLEIC_ACID_RESIDUE_NAME:
				nucleicAcidAtom = getNucleicAcidAtom(tempVanderWaalsInteraction);
				value = nucleicAcidAtom.getResName() + " " + nucleicAcidAtom.getResSeq();
				break;
				
			case NUCLEIC_ACID_ATOM:
				nucleicAcidAtom = getNucleicAcidAtom(tempVanderWaalsInteraction);
				value = nucleicAcidAtom.getName();
				break;
				
			case DISTANCE:
				value = doubleToRoundedString(tempVanderWaalsInteraction.distanceBetweenAtoms, 5);
				break;
				
			case EFFECTIVE_DISTANCE:
				value = doubleToRoundedString(tempVanderWaalsInteraction.effectiveDistance, 5);
				break;
				
			default:
		}
		
		return value;
	}



	public String doubleToRoundedString(double value, int length)
	{
		StringBuffer stringBuffer = new StringBuffer(Double.toString(value));
		String roundedString = "";
		int lastNumber = 0;
		int afterLastNumber = 0;
		
		try
		{
			lastNumber = Integer.parseInt(stringBuffer.substring(length-1,length));
			afterLastNumber = Integer.parseInt(stringBuffer.substring(length,length+1));
		}
		catch(NumberFormatException e)
		{
			e.printStackTrace(System.out);
		}
		
		if(afterLastNumber<5)
		{
			roundedString = stringBuffer.substring(0,length);
		}
		else
		{
			 roundedString = stringBuffer.replace(length-1, length, Integer.toString(++lastNumber)).substring(0,length);
		}
		
		return roundedString; 
	}
	
	
	
	public VanderWaalsInteraction getVanderWaalsInteractionAtRow(int r)
	{
		return (VanderWaalsInteraction)vanderWaalsInteractions.get(r);
	}
	
	
	
	public Atom getProteinAtom(VanderWaalsInteraction vanderWaalsInteraction)
	{
		return whichIsProteinAtom(vanderWaalsInteraction.getAtomA(), vanderWaalsInteraction.getAtomB());
	}
	
	
	
	public Atom getNucleicAcidAtom(VanderWaalsInteraction vanderWaalsInteraction)
	{
		return whichIsNucleicAcidAtom(vanderWaalsInteraction.getAtomA(), vanderWaalsInteraction.getAtomB());
	}
	
	
	
	public Atom whichIsProteinAtom(Atom atomA, Atom atomB)
	{
		Atom proteinAtom;
		
		if(atomA.getChainID().equals(proteinChainID))
		{
			proteinAtom = atomA;
		}
		else
		{
			proteinAtom = atomB;
		}
		
		return proteinAtom;
	}



	public Atom whichIsNucleicAcidAtom(Atom atomA, Atom atomB)
	{
		Atom nucleicAcidAtom;
		
		if(atomA.getChainID().equals(nucleicAcidChainID))
		{
			nucleicAcidAtom = atomA;
		}
		else
		{
			nucleicAcidAtom = atomB;
		}
		
		return nucleicAcidAtom;
	}
}