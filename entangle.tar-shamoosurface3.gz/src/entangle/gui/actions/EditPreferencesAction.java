/*
 * EditPreferencesAction.java
 *
 * Created on November 2, 2000, 12:07 AM
 */

package entangle.gui.actions;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.AbstractAction;
import javax.swing.JDialog;

import entangle.gui.Analyzer;
import entangle.gui.AnalyzerPanel;
import entangle.gui.ClassifierPropertiesEditorPane;


/**
 *
 * @author  Jim Allers
 * @version 
 */
public class EditPreferencesAction extends AbstractAction 
{
	final Analyzer myAnalyzer;
	final AnalyzerPanel myAnalyzerPanel;
	final ClassifierPropertiesEditorPane classifierPane;
	
	
	
    /** Creates new EditPreferencesAction */
   	public EditPreferencesAction(Analyzer analyzer, AnalyzerPanel analyzerPanel) 
   	{
		super("Preferences...");
		myAnalyzer = analyzer;
		myAnalyzerPanel = analyzerPanel;
		classifierPane = new ClassifierPropertiesEditorPane();
	}
	
	
	
	
	public void actionPerformed(ActionEvent evt)
	{
		JDialog dialog = new JDialog(myAnalyzer,"Classifier Properties",true);
		
		dialog.addWindowListener(
			new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					classifierPane.setProperties();
					
					if(myAnalyzerPanel.hasLoadedPDB())
					{
						System.out.println("Changing values");
						myAnalyzerPanel.getClassifier().updateProperties();
					}
				}
			});
			
		dialog.setContentPane(classifierPane);
		dialog.setSize(new Dimension(600,300));
		dialog.setVisible(true);
	}
}