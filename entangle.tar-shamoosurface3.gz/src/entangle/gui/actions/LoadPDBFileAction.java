/*
 * LoadPDBFileAction.java
 *
 * Created on October 11, 2000, 3:15 PM
 */

package entangle.gui.actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import entangle.gui.AnalyzerPanel;




/**
 *
 * @author  Jim Allers
 * @version 
 */
public class LoadPDBFileAction extends AbstractAction 
{
	final AnalyzerPanel analyzerPanel;
	
	
	
	/** Creates new LoadPDBFileAction */
	public LoadPDBFileAction(AnalyzerPanel analyzerPanel) 
	{
		super("Load PDB File...");
		this.analyzerPanel = analyzerPanel;
	}
	
	
	
	public void actionPerformed(ActionEvent e)
	{
		analyzerPanel.loadPDBFile();
	}
}