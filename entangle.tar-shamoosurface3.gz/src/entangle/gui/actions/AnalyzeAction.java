/*
 * AnalyzeAction.java
 *
 * Created on October 11, 2000, 3:00 PM
 */

package entangle.gui.actions;
import java.awt.Cursor;
import java.awt.Event;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import entangle.gui.AnalysisTabbedPane;
import entangle.gui.AnalyzerPanel;
import entangle.utils.EntangleProperties;

/**
 * AnalyzeAction triggers the analysis of the interactions between the
 * two selected atoms
 * and displays the interactions
 */
public class AnalyzeAction extends AbstractAction
{
	final AnalyzerPanel analyzerPanel;
	final AnalysisTabbedPane analysisTabbedPane;
	
	
	public AnalyzeAction(AnalyzerPanel analyzerPanel, AnalysisTabbedPane analysisTabbedPane)
	{
		super("Analyze");
		this.analyzerPanel = analyzerPanel;
		this.analysisTabbedPane = analysisTabbedPane;
		putValue(AbstractAction.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_A,Event.CTRL_MASK));
	}


	public void actionPerformed(ActionEvent e)
	{
		try
		{
			System.out.println("Analyzing interactions");
			analyzerPanel.getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
			analyzerPanel.setNBInteractionContainer(analyzerPanel.getClassifier().findAndClassifyInteractions());
			
			analysisTabbedPane.readClassification(analyzerPanel.getNBInteractionContainer(
					analyzerPanel.getCurrentProtein(),
					analyzerPanel.getCurrentNucleicAcid(),
					analyzerPanel.getPDBInformation()));
			
			analyzerPanel.setViewStructureActionEnabled(true);
			
			analyzerPanel.getAnalysisToolBar().changeStatus(
				"Interactions between " + "Protein: " +
				analyzerPanel.getCurrentProtein().getChainIdentifier() + " and " + " Nucleic Acid: " +
				analyzerPanel.getCurrentNucleicAcid().getChainIdentifier());
			
			analyzerPanel.saveInteractionsAction.setEnabled(true);
			analyzerPanel.getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		}
		catch(Exception exc)
		{
			JOptionPane.showMessageDialog(analyzerPanel, EntangleProperties.getProperties().getProperty(
					"entangle.analysisErrorMessage") + "\n" + exc, "Entangle Error Message", JOptionPane.ERROR_MESSAGE);
			exc.printStackTrace(System.out);
			analyzerPanel.getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		}
	}
}
