/*
 * ViewStructureAction.java
 *
 * Created on October 11, 2000, 3:14 PM
 */

package entangle.gui.actions;

import java.awt.Cursor;
import java.awt.Event;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

import entangle.classification.NBInteractionContainer;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.PDBInformation;
import entangle.gui.AnalyzerPanel;
import entangle.j3d.PDBViewerFrame;

 

/**
* ViewStructureAction creates a PDBViewerFrame to view the selected chains
* and interactions
* @see entangle.j3d.PDBViewerFrame PDBViewerFrame
*/
public class ViewStructureAction extends AbstractAction
{
	final AnalyzerPanel analyzerPanel;
	
	
	public ViewStructureAction(AnalyzerPanel analyzerPanel)
	{
		this.analyzerPanel = analyzerPanel;
		putValue(AbstractAction.ACCELERATOR_KEY,KeyStroke.getKeyStroke(KeyEvent.VK_V,Event.CTRL_MASK));
	}
	
	
	
	public void actionPerformed(ActionEvent e)
	{
		analyzerPanel.getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		Macromolecule currentProtein = analyzerPanel.getCurrentProtein();
		Macromolecule currentNucleicAcid = analyzerPanel.getCurrentNucleicAcid();
		PDBInformation pdbInformation = analyzerPanel.getPDBInformation();
		
		if((currentProtein!=null)&&(currentNucleicAcid!=null))
		{
			try
			{
				NBInteractionContainer container =
					analyzerPanel.getNBInteractionContainer(currentProtein, currentNucleicAcid, pdbInformation);
					
				PDBViewerFrame pdbViewerFrame = new PDBViewerFrame("Viewing " + currentProtein.getName()	+ " & " + 
												currentNucleicAcid.getName(), currentProtein, currentNucleicAcid, container);
			}
			catch(Exception ex)
			{
				ex.printStackTrace(System.out);
			}
		}
		
		analyzerPanel.getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}
}