/*
 * LoadPDBFromRCSB.java
 *
 * Created on October 11, 2000, 3:16 PM
 */

package entangle.gui.actions;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.io.IOException;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;
import javax.swing.ProgressMonitorInputStream;

import entangle.gui.AnalyzerPanel;
import entangle.utils.io.PDBGetter;



/**
 *
 * @author  Jim Allers
 * @version 
 */
public class LoadPDBFromRCSBAction extends AbstractAction 
{
	final AnalyzerPanel analyzerPanel;
	
	
    /** Creates new LoadPDBFromRCSB */
	public LoadPDBFromRCSBAction(AnalyzerPanel analyzerPanel)
	{
		super("Load PDB From pdb.org...");
		this.analyzerPanel = analyzerPanel;
	}
	
	
	
	
	
	public void actionPerformed(ActionEvent e)
	{
		analyzerPanel.getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		String pdbID = JOptionPane.showInputDialog(analyzerPanel,"Enter PDB ID");
		
        if(pdbID!=null)
        {
            try
            {
                PDBGetter pdbGetter = new PDBGetter(pdbID);
				ProgressMonitorInputStream monitoredStream = 
				new ProgressMonitorInputStream(analyzerPanel,"Loading " + pdbID + " from pdb.org", pdbGetter.openPDBStream());
				System.out.println("millisecondsToPopup" + monitoredStream.getProgressMonitor().getMillisToPopup());
				analyzerPanel.loadPDB(monitoredStream, pdbID.toUpperCase());
            }
            catch(IOException exc)
            {
				JOptionPane.showMessageDialog(analyzerPanel,"Error occurred while attempting to PDB from pdb.org",
						      "Entangle Error Message",JOptionPane.ERROR_MESSAGE);
            }
        }
		
		analyzerPanel.getMaster().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}
}