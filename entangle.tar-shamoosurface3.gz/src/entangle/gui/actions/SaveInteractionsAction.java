/*
 * LoadPDBFileAction.java
 *
 * Created on October 11, 2000, 3:15 PM
 */

package entangle.gui.actions;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import entangle.classification.NBInteractionContainer;
import entangle.gui.AnalyzerPanel;
import entangle.utils.io.InteractionDocumentCreator;



/**
 *
 * @author  Jim Allers
 * @version 
 */
public class SaveInteractionsAction extends AbstractAction 
{
	final AnalyzerPanel analyzerPanel;
	
	
	
	/** Creates new LoadPDBFileAction */
	public SaveInteractionsAction(AnalyzerPanel analyzerPanel) 
	{
		super("Save Interactions...");
		this.analyzerPanel = analyzerPanel;
	}
	
	
	
	
	public void actionPerformed(ActionEvent e)
	{
		File htmlDirectory = new File(System.getProperty("user.dir") + File.separator + "html");
		final JFileChooser fileChooser = new JFileChooser(htmlDirectory);
		fileChooser.setDialogType(JFileChooser.SAVE_DIALOG);

		fileChooser.showDialog(analyzerPanel,"Save as .HTML File");
		
		try
		{
			FileOutputStream out = new FileOutputStream(fileChooser.getSelectedFile());
			
			NBInteractionContainer nbInteractionContainer =
					analyzerPanel.getNBInteractionContainer( analyzerPanel.getCurrentProtein(),
					analyzerPanel.getCurrentNucleicAcid(), analyzerPanel.getPDBInformation());
						
			InteractionDocumentCreator creator =
					new InteractionDocumentCreator(nbInteractionContainer, analyzerPanel.getPDBInformation(), out);
						
			creator.startSending(InteractionDocumentCreator.ALL_INTERACTIONS);
		}
		catch(FileNotFoundException ex)
		{
			JOptionPane.showMessageDialog(analyzerPanel, "Could not create file", "Entangle Error Message", JOptionPane.ERROR_MESSAGE);
		}
		/*catch(IOException exc)
		{
			JOptionPane.showMessageDialog(analyzerPanel, "Could not write to file", "Entangle Error Message", JOptionPane.ERROR_MESSAGE);
		}*/
		catch(NullPointerException ex)
		{
			System.out.println("You cancelled that, didn't you?  Silly you.  You should have gone ahead and saved those interactions.  You might need them someday.");
		}
	}
}