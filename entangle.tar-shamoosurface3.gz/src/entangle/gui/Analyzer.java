/* 1.2 code
 * Last Modified:07/19/2000 - 00:24:49
 * @author Jim Allers (jima@rice.edu)
 *
 *
 * ENTANGLE GUI PROGRAM MAIN ENTRY CLASS
 */

package entangle.gui;

import java.awt.Event;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

import entangle.gui.actions.EditPreferencesAction;
import entangle.gui.actions.LoadPDBFileAction;
import entangle.gui.actions.LoadPDBFromRCSBAction;

/**
 * The entry class for the entangle package. It provides a frame
 * for AnalyzerPanel.
 */
public class Analyzer extends JFrame
{
	JMenuBar menuBar;
	JMenu fileMenu;
	JMenu editMenu;
	JMenu aboutMenu;
	JMenuItem[] pdbItems;
	final AnalyzerPanel analyzerPanel;

	/**
	 * Constructor.  Sets up the menubar for Entangle, then sets up AnalyzerPanel
	 * as the main contents panel of the program.
	 */
	public Analyzer(String title)
	{
		setTitle(title); // from java.awt.Frame

		JMenuBar menuBar = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		JMenu editMenu = new JMenu("Edit");
		JMenu aboutMenu = new JMenu("About Entangle");

		fileMenu.setMnemonic('f');
		editMenu.setMnemonic('e');
		aboutMenu.setMnemonic('a');

		analyzerPanel = new AnalyzerPanel(this);

		JMenuItem editPreferencesItem = editMenu.add(new EditPreferencesAction(this, analyzerPanel));
		editPreferencesItem.setMnemonic('p');

		JMenuItem loadPDBFileItem = fileMenu.add(new LoadPDBFileAction(analyzerPanel));
		loadPDBFileItem.setMnemonic('l');

		JMenuItem getPDBFromDatabaseItem = fileMenu.add(new LoadPDBFromRCSBAction(analyzerPanel));
		getPDBFromDatabaseItem.setMnemonic('p');

		JMenuItem saveDocumentItem = fileMenu.add(analyzerPanel.saveInteractionsAction);
		saveDocumentItem.setMnemonic('s');

		JMenuItem multipleAnalysisItem = new JMenuItem("Generalized Base Analysis");
		multipleAnalysisItem.setMnemonic('m');
		multipleAnalysisItem.addActionListener(new ActionListener ()
		{
			public void actionPerformed(ActionEvent e)
			{
				analyzerPanel.multipleAnalysis();
			}
		});

		JMenuItem closeWindowItem = new JMenuItem("Exit");
		closeWindowItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, Event.CTRL_MASK));
		closeWindowItem.setMnemonic('x');

		closeWindowItem.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		});

		JMenuItem aboutItem = new JMenuItem("About...");
		aboutItem.setMnemonic('a');
		aboutItem.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				aboutEntangle();
			}
		});

		fileMenu.add(multipleAnalysisItem);
		fileMenu.addSeparator();
		fileMenu.add(saveDocumentItem);
		fileMenu.addSeparator();
		fileMenu.add(closeWindowItem);

		aboutMenu.add(aboutItem);

		menuBar.add(fileMenu);
		menuBar.add(editMenu);
		menuBar.add(aboutMenu);
		setJMenuBar(menuBar);

		setContentPane(analyzerPanel);
	}

	private void aboutEntangle()
	{
		JFrame frame = new JFrame("About Entangle");

		JPanel panel = new JPanel();

		JLabel label =
			new JLabel("<html><center><font size=5 color=red><p>Entangle:</font><p><font size=4 color=red>A Tool For The Analysis of Nucleic Acid-Protein Complexes</font><hr width=200 align=center><p><font size=2 color=black>Entangle is a JAVA program that reads a PDB file <br>containing a nucleic-acid protein complex and gives a listing of <br>interactions that occur at the interface between the nucleic-acid/protein <br>complex. These interactions are then classified into hydrogen bonds, <br>electrostatic, hydrophobic, and Van der Waals. Entangle also recognizes <br>when a stacking interaction occurs between two aromatic residues. In <br>addition to a listing, Entangle allows the user to probe the interface in <br>three dimensions.</font><p><hr width=200 align=center><p><font size=2 color=blue>Questions? Comments? Contact us at shamoo@rice.edu.</font><p><font size=2 color=black>Entangle is free to academic users. One-time license fees are required for<br>industrial or for-profit use.  Contact shamoo@rice.edu for a licensing <br>agreement.</font><p><hr width=200 align=center><font color=blue size=1></center><p>Developed by Jim Allers, Lowell Meyer, and Yousif Shamoo<br>Shamoo Laboratory, Department of Biochemistry and Cell Biology<br>Rice University, Houston, Texas<p>http://www.bioc.rice.edu/~shamoo</font></html>");

		panel.add(label);

		frame.setContentPane(panel);
		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) throws IOException
	{
		try
		{
			try
			{
//				UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			}
			catch (Exception ex)
			{
				System.out.println("Failed loading Metal");
				System.out.println(ex);
			}

			Analyzer analyzer = new Analyzer("ENTANGLE");

			/**
			 * Causes this Window to be sized to fit the preferred size and layouts of its 
			 * subcomponents. If the window and/or its owner are not yet displayable, both 
			 * are made displayable before calculating the preferred size. The Window will 
			 * be validated after the preferredSize is calculated.
			 *
			 * Method inherited from java.awt.Window
			 */
			analyzer.pack();

			analyzer.setVisible(true); //Inherited from java.awt.Component

			/**
			 * Adds the specified window listener to receive window events from this window. 
			 * If input is null, no exception is thrown and no action is performed.
			 *
			 * Inherited from java.awt.Window
			 */
			analyzer.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
			});
		}
		catch (Exception e)
		{
			e.printStackTrace(System.out);
		}
	}
}
