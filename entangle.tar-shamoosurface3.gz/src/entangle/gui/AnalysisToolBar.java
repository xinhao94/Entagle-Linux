package entangle.gui;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JToolBar;


public class AnalysisToolBar extends JToolBar
{
	JButton analyzeButton;
	JButton viewButton;
	JProgressBar analysisProgressBar;
	JLabel statusLabel;
    
    public AnalysisToolBar(Action analyzeAction,Action viewStructureAction)
    {
	       analysisProgressBar = new JProgressBar(0,1000);
           
           analyzeButton = add(analyzeAction);
           analyzeButton.setText("Analyze");
           
           viewButton = add(viewStructureAction);
           viewButton.setText("View Structure");
	       
	       addSeparator();
           
           add(new JLabel("Status:"));
           
	       addSeparator();
	       
	       statusLabel = new JLabel("Load a PDB File");
	       statusLabel.setHorizontalAlignment(JLabel.CENTER);
	       
	       add(statusLabel);
    }
	
	
	
	public void changeStatus(String status)
	{
		statusLabel.setText(status);
	}
	
	
	
	public void setProgress(int value)
	{
		analysisProgressBar.setValue(value);
		repaint();
	}
	
	
	
	
	public int getProgress()
	{
		return analysisProgressBar.getValue();
	}
}
