/*
 * ClassName.java
 *
 * Created on September 23, 2000, 10:20 AM
 */

package entangle.gui;

import java.io.File;

import javax.swing.filechooser.FileFilter;



/**
 * @author  Jim Allers
 * @version 
 *
 * filename filter to find only pdb files
 */
public class PDBFileFilter extends FileFilter
{
	public boolean accept(File file)
	{
		String pdbID = file
		.getName()
		.substring(file.getName().length() - 4, file.getName().length());
		return pdbID.equalsIgnoreCase(".pdb") || file.isDirectory();
		
	}


	public String getDescription()
	{
		return "PDB files";
	}
}