/*
 * InteractionTreeModel.java
 *
 * Created on December 28, 2000, 6:14 PM
 */

package entangle.gui.interactionsTree;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

import javax.swing.tree.DefaultMutableTreeNode;

import entangle.classification.InteractingGroup;
import entangle.classification.NBInteractionContainer;
import entangle.classification.electrostatic.ElectrostaticInteraction;
import entangle.classification.hbonds.HydrogenBond;
import entangle.classification.hydrophobic.HydrophobicInteraction;
import entangle.classification.stacking.StackingInteraction;
import entangle.classification.vanderwaals.VanderWaalsInteraction;



/**
 *
 * @author  Jim Allers
 * @version 
 */
public class InteractionTreeModel extends javax.swing.tree.DefaultTreeModel 
{
    NBInteractionContainer interactionContainer;
    Hashtable interactingGroups;
    
    
    /**
     * InteractionTreeModel creates an outline view of the interactions occuring
     * in a complex of macromolecules. This view is a tree structure which looks
     * at interacting groups, a reference residue and the interactions which the
     * interacting macromolecule makes with this reference residue. 
     */
    public InteractionTreeModel(DefaultMutableTreeNode node, NBInteractionContainer interactionContainer)
    {
        super(node,true);
        this.interactionContainer = interactionContainer;
        interactingGroups = interactionContainer.getInteractingGroups();
        
        // building the tree, beginning with the hashtable of interacting groups
        DefaultMutableTreeNode root = (DefaultMutableTreeNode)getRoot();
        
        try
		{        
        	for(Enumeration e = interactingGroups.elements(); e.hasMoreElements();)
        	{
            	root.add(buildInteractingGroupNode((InteractingGroup)e.nextElement()));
        	}
    	}
    	catch(Exception e)
    	{
    		System.out.println("ERROR IN INTERACTION TREE MODEL, line 49-51");
    		System.out.println("NBInteractionContainer interactionContainer contains = " + interactionContainer);
    		System.out.println("interactingGroups contains = " + interactingGroups);
    		System.out.println("interactingGroups.elements() returns = " + interactingGroups.elements() );
    	}
    }
    
    
    
    /**
     * buildInteractingGroupNode builds interactingGroupNodes, but also throws
     * in the appropriate interaction nodes as well
     */
    public DefaultMutableTreeNode buildInteractingGroupNode(InteractingGroup interactingGroup)
    {
        DefaultMutableTreeNode interactingGroupNode = new DefaultMutableTreeNode(interactingGroup,true);
        DefaultMutableTreeNode stackingInteractionsNode = new DefaultMutableTreeNode("Stacking Interactions", true);
        
        
        // go through stacking interactions
        for(Iterator stackingInteractionsIterator = interactingGroup.getStackingInteractions().iterator(); stackingInteractionsIterator.hasNext();)
        {
            DefaultMutableTreeNode stackingNode = new DefaultMutableTreeNode((StackingInteraction) stackingInteractionsIterator.next(), false);
            stackingInteractionsNode.add(stackingNode); 
        }
        
        if(stackingInteractionsNode.getChildCount()>0)
            interactingGroupNode.add(stackingInteractionsNode);
            
            
        // go through hydrogen bonds
        DefaultMutableTreeNode hydrogenBondsNode = new DefaultMutableTreeNode("Hydrogen Bonds", true);
        for(Iterator hydrogenBondIterator = interactingGroup.getHydrogenBonds().iterator(); hydrogenBondIterator.hasNext();)
        {
            DefaultMutableTreeNode hydrogenBondNode = new DefaultMutableTreeNode((HydrogenBond) hydrogenBondIterator.next(),false);
            hydrogenBondsNode.add(hydrogenBondNode);
        }
        
        if(hydrogenBondsNode.getChildCount()>0)
            interactingGroupNode.add(hydrogenBondsNode);
            
            
        // go through the electrostatic interactions
        DefaultMutableTreeNode electrostaticsNode = new DefaultMutableTreeNode("Electrostatic Interactions", true);
        
        for(Iterator electrostaticIterator = interactingGroup.getElectrostaticInteractions().iterator(); electrostaticIterator.hasNext();)
        {
            DefaultMutableTreeNode electrostaticNode = new DefaultMutableTreeNode((ElectrostaticInteraction) electrostaticIterator.next(),false);
            electrostaticsNode.add(electrostaticNode);
        }
        
        if(electrostaticsNode.getChildCount()>0)
            interactingGroupNode.add(electrostaticsNode);
            
            
        // go through the hydrophobic interactions
        DefaultMutableTreeNode hydrophobicsNode = new DefaultMutableTreeNode("Hydrophobic Interactions", true);
        
        for(Iterator hydrophobicIterator = interactingGroup.getHydrophobicInteractions().iterator(); hydrophobicIterator.hasNext();)
        {
            DefaultMutableTreeNode hydrophobicNode = new DefaultMutableTreeNode((HydrophobicInteraction) hydrophobicIterator.next(),false);
            hydrophobicsNode.add(hydrophobicNode);
        }
        
        if(hydrophobicsNode.getChildCount()>0)
            interactingGroupNode.add(hydrophobicsNode);
            
            
        // go through the Van der Waals interactions
        DefaultMutableTreeNode vanderWaalsInteractionsNode = new DefaultMutableTreeNode("Van der Waals Interactions",true);
        
         for(Iterator vanderWaalsIterator = interactingGroup.getVanderWaalsInteractions().iterator(); vanderWaalsIterator.hasNext();)
         {
            DefaultMutableTreeNode vanderWaalsNode = new DefaultMutableTreeNode((VanderWaalsInteraction) vanderWaalsIterator.next(),false);
            vanderWaalsInteractionsNode.add(vanderWaalsNode);
        }
        
        if(vanderWaalsInteractionsNode.getChildCount()>0)
            interactingGroupNode.add(vanderWaalsInteractionsNode);
            
            
        return interactingGroupNode;
    }
}