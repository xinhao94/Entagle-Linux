/*
 * InteractionTreeCellRenderer.java
 *
 * Created on December 28, 2000, 5:34 PM
 */

package entangle.gui.interactionsTree;

import java.awt.Component;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

import entangle.classification.electrostatic.ElectrostaticInteraction;
import entangle.classification.hbonds.HydrogenBond;
import entangle.classification.hydrophobic.HydrophobicInteraction;
import entangle.classification.stacking.StackingInteraction;
import entangle.classification.vanderwaals.VanderWaalsInteraction;


/**
 *
 * @author  unknown
 * @version 
 */
public class InteractionTreeCellRenderer extends javax.swing.tree.DefaultTreeCellRenderer 
{
    ImageIcon smallHydrophobicIcon = new ImageIcon(System.getProperty("user.dir") + File.separator +
                        "images" + File.separator + "SmallHydrophobicIcon.gif");
    ImageIcon smallElectrostaticIcon = new ImageIcon(System.getProperty("user.dir") + File.separator + 
                        "images" + File.separator + "SmallElectrostaticIcon.gif");
    ImageIcon smallHydrogenBondIcon = new ImageIcon(System.getProperty("user.dir") + File.separator + 
                        "images" + File.separator + "SmallHydrogenBondIcon.gif");
    ImageIcon smallStackingInteractionIcon = new ImageIcon(System.getProperty("user.dir") + File.separator + 
                        "images" + File.separator + "SmallStackingInteractionIcon.gif");
    ImageIcon smallVanderWaalsIcon = new ImageIcon(System.getProperty("user.dir") + File.separator + 
                        "images" + File.separator + "SmallVanderWaalsIcon.gif");
                        
                        
    /** Creates new InteractionTreeCellRenderer */ 
    public InteractionTreeCellRenderer() 
    {
    }
    
    
    
    /**
     * Overrides the getTreeCellRendererComponent to set the appropriate icons 
     * to be rendered with the object values
     */
    public Component getTreeCellRendererComponent(JTree tree,Object value, boolean sel, boolean expanded,
                                                  boolean leaf, int row, boolean hasFocus)
    {
           super.selected = sel;
           super.hasFocus = hasFocus;
           
           /* have the tree convert the value to text*/                                     
           String stringValue = tree.convertValueToText(value, selected, expanded, leaf, row, hasFocus);
           
           /* Set the text */
           setText(stringValue);
           
           /* Tooltips used by the tree */
           setToolTipText(stringValue);
           
           if(sel)
                setForeground(getTextSelectionColor());
           else
                setForeground(getTextNonSelectionColor());
                
           Object userObject = ((DefaultMutableTreeNode)value).getUserObject();
           
           
           if(userObject instanceof HydrophobicInteraction)
           {
               setIcon(smallHydrophobicIcon);
           }
           else if(userObject instanceof ElectrostaticInteraction)
           {
               setIcon(smallElectrostaticIcon);
           }
           else if(userObject instanceof HydrogenBond)
           {
               setIcon(smallHydrogenBondIcon);
           }
           else if(userObject instanceof StackingInteraction)
           {
               setIcon(smallStackingInteractionIcon);
           }
           else if(userObject instanceof VanderWaalsInteraction)
           {
               setIcon(smallVanderWaalsIcon);
           }
           else
           {
               setIcon(null);
           }
           
           
           return this;
   }
}
