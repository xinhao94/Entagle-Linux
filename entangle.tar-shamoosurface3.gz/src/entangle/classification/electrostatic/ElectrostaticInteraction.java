package entangle.classification.electrostatic;

import entangle.datastructures.Atom;



public class ElectrostaticInteraction
{
    private Atom positiveAtom;
    private Atom negativeAtom;
    private double distance;
    
    
    public ElectrostaticInteraction(Atom positiveAtom,Atom negativeAtom, double distance)
    {
        this.positiveAtom = positiveAtom;
        this.negativeAtom = negativeAtom;
        this.distance = distance;
    }
        
        
    public SimpleEInteraction simpleCopy(){
    	return new SimpleEInteraction(this);
    }
       
       
    public double getDistance()
    {
        return distance;
    }
        
    public void setDistance(double distance)
    {
        this.distance = distance;
    }
        
    public Atom getPositiveAtom()
    {
        return positiveAtom;
    }
        
    public Atom getNegativeAtom()
    {
        return negativeAtom;
    }
        
    public void setPositiveAtom(Atom positiveAtom)
    {
        this.positiveAtom = positiveAtom;
    }
        
    public void setNegativeAtom(Atom negativeAtom)
    {
        this.negativeAtom = negativeAtom;
    }
        
    
    public String toString()
    {
        String string = "Positive: " + positiveAtom.toString() + " Negative: " + negativeAtom.toString();
        return string;
    }
}
