package entangle.classification.electrostatic;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import entangle.datastructures.Atom;
import entangle.datastructures.AtomPair;


/**
 * ElectrostaticInteractionLocator takes in a Vector of atom pairs (atoms between a protein and a
 * nucleic acid that are less than some maximum distance apart) and creates a vector of electrostatic interactions
 */
public class ElectrostaticInteractionLocator
{
    Vector electrostaticInteractions;
    Vector closeAtomPairs;
    Hashtable positiveResidues;
    Hashtable negativeResidues;
    
    boolean foundElectrostaticInteractions = false;
    double maximumDistanceForElectrostaticInteraction = 8.0;



    public ElectrostaticInteractionLocator(Vector closeAtomPairs)
    {
        this.closeAtomPairs = closeAtomPairs;
        positiveResidues = constructPositiveResidues();
        negativeResidues = constructNegativeResidues();
    }
    
    
    
    public void setMaximumDistanceForElectrostaticInteraction(double maximumDistance)
    {
		this.maximumDistanceForElectrostaticInteraction = maximumDistance;
    }

    public double getMaximumDistanceForElectrostaticInteraction()
    {
		return maximumDistanceForElectrostaticInteraction;
    }
    
    
    /**
     * iterates through the close atom pairs and builds a vector of ElectrostaticInteractions
     * from those atom pairs that are electrostatic interactions (not hydrogen bonds)
     */
    public void findElectrostaticInteractions()
    {
        electrostaticInteractions = new Vector();
		
		Vector duplicateContacts = (Vector)closeAtomPairs.clone();
		
		System.out.println("Number of close atom pairs: " + closeAtomPairs.size());
        
        
        //System.out.println("Going through the interatom pairs");
        for(Enumeration e = closeAtomPairs.elements();e.hasMoreElements();)
        {
            AtomPair tempAtomPair = (AtomPair)e.nextElement();
            ElectrostaticInteraction tempEI;
            
            Atom macromoleculeAAtom = tempAtomPair.getMacromoleculeAAtom();
            Atom macromoleculeBAtom = tempAtomPair.getMacromoleculeBAtom();
            
            double distance = tempAtomPair.getDistance();
            
            if((isAtomPositive(macromoleculeAAtom)&& isAtomNegative(macromoleculeBAtom))
                ||(isAtomPositive(macromoleculeBAtom)&&isAtomNegative(macromoleculeAAtom)))
            {
                if(distance<maximumDistanceForElectrostaticInteraction)
                {
                    tempEI = new ElectrostaticInteraction(macromoleculeAAtom,macromoleculeBAtom, distance);
                    electrostaticInteractions.addElement(tempEI);
		    		closeAtomPairs.remove(tempAtomPair);
                }
            }
        }
	
		System.out.println("Number of close atom pairs after: " + closeAtomPairs.size());
	}



    public Vector getElectrostaticInteractions()
    {
        if(!(foundElectrostaticInteractions)){
			findElectrostaticInteractions();
        }
        return electrostaticInteractions;
    }

    public boolean isAtomPositive(Atom atom)
    {
        boolean isAtomPositive = false;
        
        //System.out.println("Checking to see if " + atom.getName() + " is positive");
        if(positiveResidues.containsKey("AnyResidue"))
        {
            for(Enumeration e = ((Vector)positiveResidues.get("AnyResidue")).elements(); e.hasMoreElements();)
            {
                if(atom.getName().equals((String)e.nextElement()))
                	isAtomPositive = true;
            }
        }
        
        // go through the whole hashtable of residues and check to see if atom is a
        // positive residue
        for(Enumeration e = positiveResidues.keys(); e.hasMoreElements();)
        {
            String tempString = (String)e.nextElement();
            
            if(!(isAtomPositive))
            {
                Vector atomNames = (Vector)positiveResidues.get(tempString);
                isAtomPositive = isAtomPositive(atomNames,atom);
            }
        }
        
        //System.out.println("Atom Positive: " + isAtomPositive);
        return isAtomPositive;
    }


    public boolean isAtomNegative(Atom atom)
    {
        boolean isAtomNegative = false;
        
        //System.out.println("Checking to see if " + atom.getName() + " is negative");
        if(negativeResidues.containsKey("AnyResidue"))
        {
            for(Enumeration e = ((Vector)negativeResidues.get("AnyResidue")).elements(); e.hasMoreElements();)
            {
                if(atom.getName().equals((String)e.nextElement()))
                	isAtomNegative = true;
            }
        }
        
        // go through the whole hashtable of residues and check to see if atom is a
        // positive residue
        for(Enumeration e = negativeResidues.keys(); e.hasMoreElements();)
        {
            String tempString = (String)e.nextElement();
            
            if(!(isAtomNegative))
            {
                Vector atomNames = (Vector)negativeResidues.get(tempString);
                isAtomNegative = isAtomNegative(atomNames,atom);
            }
        }
        
        //System.out.println("Atom Negative: " + isAtomNegative);
        return isAtomNegative;
    }


    public boolean isAtomPositive(Vector positiveAtomNames,Atom atom)
    {
        boolean isAtomPositive = false;
        
        //System.out.println("checking to see if atom is positive");
        for(Enumeration e = positiveAtomNames.elements(); e.hasMoreElements();)
        {
            if(atom.getName().equals((String)e.nextElement()))
            	isAtomPositive = true;
        }
        
        //System.out.println("done");
        return isAtomPositive;
    }


    public boolean isAtomNegative(Vector negativeAtomNames,Atom atom)
    {
        boolean isAtomNegative = false;
        for(Enumeration e = negativeAtomNames.elements(); e.hasMoreElements();)
        {
            if(atom.getName().equals((String)e.nextElement()))
            	isAtomNegative = true;
        }
        
        return isAtomNegative;
    }


    /**
     * Returns a hashtable that contains a residue name and a vector of the positive atoms within
     * it. If all residues have the positive atom, then the key will be "AnyResidue".
     */
    public Hashtable constructPositiveResidues()
    {
        Hashtable positiveResidues = new Hashtable();
        Vector tempAtomVector = new Vector();
        
        tempAtomVector.addElement("NH1");
        tempAtomVector.addElement("NH2");
        
        positiveResidues.put("ARG",tempAtomVector);
        
        tempAtomVector = new Vector();
        
        tempAtomVector.addElement("NZ");
        
        positiveResidues.put("LYS",tempAtomVector);
        
        return positiveResidues;
    }


    /**
     * Returns a hashtable that contains a residue name and a vector of the negative atoms within
     * it. If all residues have the negative atom, then the key will be "AnyResidue".
     */
    public Hashtable constructNegativeResidues()
    {
        Hashtable negativeResidues = new Hashtable();
        Vector tempAtomVector = new Vector();
        
        tempAtomVector.addElement("O1P");
        tempAtomVector.addElement("O2P");
        
        negativeResidues.put("AnyResidue",tempAtomVector);
        
        return negativeResidues;
    }
}

