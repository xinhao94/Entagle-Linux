package entangle.classification.electrostatic;

import entangle.datastructures.SimpleAtom;
import entangle.utils.Transformable;
import entangle.utils.XMLEnabled;
import entangle.utils.math.XYZMatrix;


public class SimpleEInteraction implements Transformable, XMLEnabled{
    public SimpleAtom positiveAtom;
    public SimpleAtom negativeAtom;
    public double distance;
    
    
    public SimpleEInteraction(ElectrostaticInteraction esi)
    {
    	positiveAtom = esi.getPositiveAtom().simpleCopy();
        negativeAtom = esi.getNegativeAtom().simpleCopy();
        distance = esi.getDistance();
    }
    
    public void transform(XYZMatrix t, double r1, double r2, double r3){
		positiveAtom.transform(t,r1,r2,r3);
		negativeAtom.transform(t,r1,r2,r3);
	}
	
	public String buildXML(){
		String atomXML = "        <ElectrostaticInteraction>";
		
		atomXML += ("\n" + positiveAtom.buildXML());
		atomXML += ("\n" + negativeAtom.buildXML());
				
		atomXML += "\n        </ElectrostaticInteraction>";
		
		return   atomXML;
	}
	
	public String buildHTML(){
		return "<tr>" + positiveAtom.buildHTML() + negativeAtom.buildHTML() + "</tr>\n";
	}
}