/*
 * PDBInteractionContainers.java
 *
 * Created on February 25, 2001, 8:00 PM
 */

package entangle.classification;
import java.util.Hashtable;

/**
 * This group contains all of the interacting groups found within a
 * PDB file.
 * @author  Jim Allers
 * @version 
 */
 
public class PDBInteractionContainers extends java.lang.Object 
{
    private Hashtable interactionContainers;
    
    /** Creates new PDBInteractionContainers */
    public PDBInteractionContainers() 
    {
    }

}
