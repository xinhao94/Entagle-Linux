/*
 * 1.2 code.
 * Last Modified: 06/29/2000 - 19:42:08
 * Author: Jim Allers (jima@rice.edu)
 */

package entangle.classification.hbonds;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.vecmath.Vector3d;

import entangle.datastructures.Atom;
import entangle.datastructures.AtomLabel;
import entangle.datastructures.AtomPair;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.PDBInformation;
import entangle.utils.io.HB2FileParser;
import entangle.utils.math.AngleTransformer;

/**
 * Hydrogen bond locator uncovers the hydrogen bonds between a macromoleculeA 
 * and an macromoleculeB
 */

public class HydrogenBondLocator
{
    // vectors which will contain the labels for 
    // all the hydrogen bond acceptors and donors
    Vector closeAtomPairs;
    Vector hydrogenBondAcceptors;
    Vector hydrogenBondDonors;
    
    Macromolecule macromoleculeA;
    Macromolecule macromoleculeB;
    PDBInformation pdbInformation;
    
    public double maximumDistanceForHydrogenBond = 3.9;
    public double maximumAcceptorToHydrogenDistance = 2.5;
    public double minimumD_H_A_Angle = 90.0;
    public double minimumH_A_AA_Angle = 90.0;
    
    File donorsFile = new File(System.getProperty("user.dir")+File.separator+
				  "data" + File.separator + "hbonds" + File.separator + "hydrogenBondDonors");
    File acceptorsFile = new File(System.getProperty("user.dir")+File.separator+
				  "data" + File.separator + "hbonds" + File.separator + "hydrogenBondAcceptors");
    
    
    
    
    public HydrogenBondLocator(Macromolecule macromoleculeA,Macromolecule macromoleculeB, 
    												Vector atomPairs,PDBInformation pdbInformation)
    {
		this.macromoleculeA= macromoleculeA;
		this.macromoleculeB = macromoleculeB;
		this.pdbInformation = pdbInformation;
		
		hydrogenBondAcceptors = new Vector();
		hydrogenBondDonors = new Vector();
		
		closeAtomPairs = atomPairs;
        getDonors();
        getAcceptors();
    }




    public void setMacromoleculeA(Macromolecule macromoleculeA)
    {
		this.macromoleculeA = macromoleculeA;
    }
    
    
    public void setMacromoleculeB(Macromolecule macromoleculeB)
    {
		this.macromoleculeB = macromoleculeB;
    }
    
    
    public void setPDBInformation(PDBInformation pdbInformation)
    {
		this.pdbInformation = pdbInformation;
    }


    public void setMaximumDistanceForHydrogenBond(double maximumDistanceForHydrogenBond)
    {
		this.maximumDistanceForHydrogenBond = maximumDistanceForHydrogenBond;
    }


    public void setMaximumAcceptorToHydrogenDistance(double maximumAcceptorToHydrogenDistance)
    {
		this.maximumAcceptorToHydrogenDistance = maximumAcceptorToHydrogenDistance;
    }
    
    
    public void setMinimumD_H_A_Angle(double minimumD_H_A_Angle)
    {
		this.minimumD_H_A_Angle = minimumD_H_A_Angle;
    }


    public void setMinimumH_A_AA_Angle(double minimumH_A_AA_Angle)
    {
		this.minimumH_A_AA_Angle = minimumH_A_AA_Angle;
    }


    public void setParameters(double distance, double aToHDistance, double minimumD_H_A_Angle, double minimumH_A_AA_Angle)
	{
		setMaximumDistanceForHydrogenBond(distance);
		setMaximumAcceptorToHydrogenDistance(aToHDistance);
		setMinimumD_H_A_Angle(minimumD_H_A_Angle);
		setMinimumD_H_A_Angle(minimumH_A_AA_Angle);
    }
    
    
    /**
    * Gets the hydrogen bond donors in a PDB file
    */
    private void getDonors()
    {
		try
		{
	    	BufferedReader br = new BufferedReader(new FileReader(donorsFile));
            String str = br.readLine();
	    	
	    	while(str!=null)
	    	{
				StringTokenizer st = new StringTokenizer(str);
				AtomLabel atomLabel = new AtomLabel(st.nextToken(),st.nextToken());
				hydrogenBondDonors.add(atomLabel);
                str = br.readLine();
	    	}
		}
		catch(IOException e)
		{
	    	e.printStackTrace(System.out);
		}
    }
    
    
    /**
    * Gets the hydrogen bond acceptors in macromolecules from file
    */
    private void getAcceptors()
    {
		try
		{
	    	BufferedReader br = new BufferedReader(new FileReader(acceptorsFile));
            String str = br.readLine();
	    	
	    	while(str!=null)
	    	{
				StringTokenizer st = new StringTokenizer(str);
				AtomLabel atomLabel = new AtomLabel(st.nextToken(),st.nextToken());
				hydrogenBondAcceptors.add(atomLabel);
                str = br.readLine();
	    	}
		}
		catch(IOException e)
		{
	    	e.printStackTrace(System.out);
		}
    }
    
    

    public Vector getHBPLUSHydrogenBonds()
    {
		File hb2Directory = new File(System.getProperty("user.dir")+File.separator+ "hb2");
		String[] hb2List = hb2Directory.list();
		
		Vector hydrogenBonds = new Vector();
		
		Arrays.sort(hb2List);
        
        //find out if hb2 file exists
		System.out.println("Searching for " + pdbInformation.getPDBName() + ".hb2");
		
		int hb2FileIndex = Arrays.binarySearch(hb2List,pdbInformation.getPDBName()+".hb2");
		
		if(hb2FileIndex>=0)
		{
            System.out.println("Found HB2 file. Beginning parsing");
	    	HB2FileParser parser = new HB2FileParser(new File(hb2Directory, hb2List[hb2FileIndex]), macromoleculeA,macromoleculeB);
	    	parser.parseFile();
	    	hydrogenBonds = parser.getHydrogenBonds();
		}
		else
		{
			hydrogenBonds = getSimpleHydrogenBonds();
		}
		
		return hydrogenBonds;
    }
    
    
    
    public Vector getHydrogenBonds()
    {
		Vector hydrogenBonds = new Vector();
		Vector duplicateContacts = (Vector)closeAtomPairs.clone();
		
		for(Iterator iterator = duplicateContacts.iterator(); iterator.hasNext();)
		{
			AtomPair currentAtomPair = (AtomPair)iterator.next();
			HydrogenBond tempHydrogenBond = getSimpleHydrogenBondIfOne(currentAtomPair);
		
			if(tempHydrogenBond!=null)
			{
				if(isRealHydrogenBond(tempHydrogenBond))
				{
					hydrogenBonds.add(tempHydrogenBond);
					closeAtomPairs.remove(currentAtomPair);
				}
			}
		}
		
		return hydrogenBonds;
    }



    public Vector getSimpleHydrogenBonds()
    {
        Vector hydrogenBonds = new Vector();
		Vector duplicateContacts = (Vector)closeAtomPairs.clone();
		
		for(Iterator iterator = duplicateContacts.iterator(); iterator.hasNext();)
		{
			AtomPair currentAtomPair = (AtomPair)iterator.next();
			HydrogenBond hydrogenBond = getSimpleHydrogenBondIfOne(currentAtomPair);
			
			if(hydrogenBond!=null)
			{
                hydrogenBonds.addElement(hydrogenBond);
		    	closeAtomPairs.remove(currentAtomPair);
			}
        }
        
        return hydrogenBonds;
    }
    
    
    
    /* returns a hashtable of close atom pairs keyed by the possible hydrogen 
       bond they might be a part of */
    public Hashtable getSimpleHydrogenBondsInTable()
    {
		Hashtable hydrogenBonds = new Hashtable();
		Vector duplicateContacts = (Vector)closeAtomPairs.clone();
		
		for(Iterator iterator = duplicateContacts.iterator(); iterator.hasNext();)
		{
			AtomPair currentAtomPair = (AtomPair)iterator.next();
			HydrogenBond hydrogenBond = getSimpleHydrogenBondIfOne(currentAtomPair);
			
			if(hydrogenBond!=null)
			{
                hydrogenBonds.put(hydrogenBond,currentAtomPair);
			}
        }
        
        return hydrogenBonds;
    }



    /**
     * getSimpleHydrogenBondIfOne determines whether a pair of atoms could be a hydrogen
     * bond if the pair is a donor and an acceptor, and if the distance is right
     */
    public HydrogenBond getSimpleHydrogenBondIfOne(AtomPair atomPair)
    {
        double distance = atomPair.getDistance();
		boolean isHydrogenBondValue = false;
        HydrogenBond hydrogenBond = null;
		
		if(distance < maximumDistanceForHydrogenBond)
		{
	    	Atom macromoleculeAAtom = atomPair.getMacromoleculeAAtom();
	    	Atom macromoleculeBAtom = atomPair.getMacromoleculeBAtom();
            
            if(isDonor(macromoleculeAAtom)&&isAcceptor(macromoleculeBAtom))
            {
                hydrogenBond = new HydrogenBond(macromoleculeAAtom,macromoleculeBAtom);
                hydrogenBond.setDonorToAcceptorDistance(distance);
            }
            
            if(isAcceptor(macromoleculeAAtom)&&isDonor(macromoleculeBAtom))
            {
                hydrogenBond = new HydrogenBond(macromoleculeBAtom,macromoleculeAAtom);
                hydrogenBond.setDonorToAcceptorDistance(distance);
            }
        }
        
        return hydrogenBond;
    }
    
    
    
    /**
     * isRealHydrogenBond takes the hydrogen bond produced by simple hydrogen bond
     * and 
     */
    public boolean isRealHydrogenBond(HydrogenBond hydrogenBond)
    {
        boolean isRealHydrogenBond = false;
        
        double H_A_AA_Angle;
        double D_H_A_Angle = 0;
        double hydrogenToAcceptorDistance;
        
        Atom bestHydrogen = null;
        Atom donor = hydrogenBond.getDonor();
        Atom acceptor = hydrogenBond.getAcceptor();
        
        Vector donorBondedAtoms = donor.getBondedAtoms();
        Vector acceptorBondedAtoms = acceptor.getBondedAtoms();
        Vector hydrogens = new Vector();
        
        for(Iterator iterator1 = donorBondedAtoms.iterator();iterator1.hasNext();)
        {
            Atom bondedAtom = (Atom)iterator1.next();
            if(bondedAtom.getAtomType().equals("H"))
                hydrogens.add(bondedAtom);
        }
        
        
        //check all the hydrogens and see if a hydrogen bond is form
        // find the minimum angle and distance
        Vector3d dToHVector = new Vector3d();
        Vector3d aToHVector = new Vector3d();
        Vector3d AAToAVector = new Vector3d();
        
        for(Iterator iterator = hydrogens.iterator();iterator.hasNext();)
        {
            Atom currentHydrogen = (Atom)iterator.next();
            
            dToHVector.x = currentHydrogen.x-donor.x;
            dToHVector.y = currentHydrogen.y-donor.y;
            dToHVector.z = currentHydrogen.z-donor.z;
            aToHVector.x = currentHydrogen.x-acceptor.x;
            aToHVector.y = currentHydrogen.y-acceptor.y;
            aToHVector.z = currentHydrogen.z-acceptor.z;
            
            double currentD_H_A_Angle = dToHVector.angle(aToHVector);
            currentD_H_A_Angle = AngleTransformer.radiansToDegrees(currentD_H_A_Angle);
            
            double currentHydrogenToAcceptorDistance = currentHydrogen.getDistance(acceptor);
            
            if(currentD_H_A_Angle>D_H_A_Angle && currentD_H_A_Angle>minimumD_H_A_Angle
                 && currentHydrogenToAcceptorDistance<maximumAcceptorToHydrogenDistance)
            {
                D_H_A_Angle = currentD_H_A_Angle;
                hydrogenToAcceptorDistance = currentHydrogenToAcceptorDistance;
                bestHydrogen = currentHydrogen;
                hydrogenBond.setHydrogen(bestHydrogen);
				hydrogenBond.setHydrogenToAcceptorDistance(hydrogenToAcceptorDistance);
                hydrogenBond.setD_H_A_Angle(D_H_A_Angle);
                
                isRealHydrogenBond = true;
            }
        }
        
        return isRealHydrogenBond;
    }
    
    
    
    /**
     * 
     */
    public boolean isAcceptor(Atom atom)
    {
        String atomName = atom.getName();
	    String atomResidue = atom.getResName();
        
        boolean isAcceptor = false;
	    
	    int numberOfAcceptors = hydrogenBondAcceptors.size();
        
        for(int i = 0;i<numberOfAcceptors;i++)
        {
            AtomLabel currentAtomLabel = (AtomLabel)hydrogenBondAcceptors.elementAt(i);
			
			if(atomResidue.equals(currentAtomLabel.getResidueName()))
			{
			    if(atomName.equals(currentAtomLabel.getAtomName()))
			    {
					isAcceptor = true;
			    }
			}
			
			if((currentAtomLabel.getResidueName()).equals("AnyResidue"))
			{
			    if(atomName.equals(currentAtomLabel.getAtomName()))
			    {
					isAcceptor = true;
			    }
			}
         }
         
         return isAcceptor;
    }
    
    
    
    public boolean isDonor(Atom atom)
    {
        String atomName = atom.getName();
	    String atomResidue = atom.getResName();
	    
        boolean isDonor = false;
        
	    int numberOfDonors = hydrogenBondDonors.size();
        
        for(int i = 0;i<numberOfDonors;i++)
        {
            AtomLabel currentAtomLabel = (AtomLabel)hydrogenBondDonors.elementAt(i);
			
			if(atomResidue.equals(currentAtomLabel.getResidueName()))
			{
			    if(atomName.equals(currentAtomLabel.getAtomName()))
			    {
					isDonor = true;
			    }
			}
			
			if((currentAtomLabel.getResidueName()).equals("AnyResidue"))
			{
			    if(atomName.equals(currentAtomLabel.getAtomName()))
			    {
					isDonor = true;
			    }
			}
        }
        
        return isDonor;
    }
}