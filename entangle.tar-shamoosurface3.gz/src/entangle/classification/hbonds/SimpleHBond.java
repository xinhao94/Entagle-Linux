package entangle.classification.hbonds;

import entangle.datastructures.SimpleAtom;
import entangle.utils.Transformable;
import entangle.utils.XMLEnabled;
import entangle.utils.math.XYZMatrix;

/**
 * HydrogenBond includes much of the information about the hydrogen bond
 * including the Atoms corresponding to the donor and acceptor
 *
 * Angles are in degrees
 * @author Lowell Meyer
 */
public class SimpleHBond implements Transformable, XMLEnabled{
    SimpleAtom donor;
    SimpleAtom acceptor;
    SimpleAtom hydrogen;

    
    public SimpleHBond(HydrogenBond hb)
    {
		donor = hb.donor.simpleCopy();
		acceptor = hb.acceptor.simpleCopy();
		hydrogen = hb.hydrogen.simpleCopy();
    }

	
	public void transform(XYZMatrix t, double r1, double r2, double r3){
		donor.transform(t,r1,r2,r3);
		acceptor.transform(t,r1,r2,r3);
		hydrogen.transform(t,r1,r2,r3);
	}
	
	public String buildXML(){
		String atomXML = "        <ElectrostaticInteraction>";
		
		atomXML += ("\n" + donor.buildXML());
		atomXML += ("\n" + acceptor.buildXML());
		atomXML += ("\n" + hydrogen.buildXML());
				
		atomXML += "\n        </ElectrostaticInteraction>";
		
		return   atomXML;
	}
	
	public String buildHTML(){
		return "<tr>" + donor.buildHTML() + acceptor.buildHTML() + hydrogen.buildHTML() + "</tr>\n";
	}
}