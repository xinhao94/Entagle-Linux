package entangle.classification.hbonds;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import javax.media.j3d.Transform3D;
import javax.vecmath.Matrix3d;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import entangle.datastructures.Atom;
import entangle.datastructures.AtomLabel;
import entangle.datastructures.DonorGroupGeometry;
import entangle.datastructures.HydrogenInfo;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.PDBInformation;
import entangle.datastructures.Residue;
import entangle.utils.io.DonorGroupGeometriesDOMParser;
import entangle.utils.math.AngleTransformer;
import entangle.utils.math.CoordinateTransformer;
import entangle.utils.math.SphericalPoint3d;


/**
 * HydrogenAtomAdder takes a PDB file and adds hydrogen atoms.
 * Right now it will only hydrogen atoms to those atoms that are possible donors
 * involved in hydrogen bonding
 * It uses the algorithm described for the program HBPlus
 */
public class HydrogenAtomAdder
{
    private File donorGeometryFile= new File(System.getProperty("user.dir") +  File.separator
				+ "data" + File.separator + "hbonds" + File.separator + "donorGroupGeometries.xml");
				
    private Vector macromolecules;
    private Vector hydrogenBonds;
    private Vector possibleHydrogenBondsWithFlexibleHydrogenDonors;
    private Vector possibleHydrogensBondsWithFixedHydrogenDonors;
    private Hashtable interMolecularContactsTable; 	// Vector of closeAtomPairs between
    												// the two macromolecules keyed by the
    												// concatenation of their chainIDs
    private HydrogenBondLocator hbondLocator;
    private Hashtable donorGroupGeometries;
    private PDBInformation pdbInformation;
    
    private final int FIRST_POSITION = 81;
    private final int SECOND_POSITION = 82;
    private final int THIRD_POSITION = 83;
    private final int NO_POSITION = 84;
    double maximumDistanceForHydrogenBond = 3.9;
    double maximumAcceptorToHydrogenDistance = 2.5;
    double minimumD_H_A_Angle = 90.0;
    double minimumH_A_AA_Angle = 90.0;
    
    
    /**
     * Constructor for HydrogenAtomAdder
     * interMolecularContactsTable; 
     * 
     */
    public HydrogenAtomAdder(Vector macromolecules, Hashtable interMolecularContactsTable, PDBInformation pdbInformation)
	   throws ParserConfigurationException, IOException, SAXException
	{
       this.macromolecules = macromolecules;
       this.interMolecularContactsTable = interMolecularContactsTable;
       this.pdbInformation = pdbInformation;
	   
	   hydrogenBonds = new Vector();
       getDonorGroupGeometries();
    }
    
    
    
    public void setMaximumDistanceForHydrogenBond(double maximumDistanceForHydrogenBond)
    {
		this.maximumDistanceForHydrogenBond = maximumDistanceForHydrogenBond;
    }

    public void setMaximumAcceptorToHydrogenDistance(double maximumAcceptorToHydrogenDistance)
    {
		this.maximumAcceptorToHydrogenDistance = maximumAcceptorToHydrogenDistance;
    }
    
    public void setMinimumD_H_A_Angle(double minimumD_H_A_Angle)
    {
		this.minimumD_H_A_Angle = minimumD_H_A_Angle;
    }

    public void setMinimumH_A_AA_Angle(double minimumH_A_AA_Angle)
    {
		this.minimumH_A_AA_Angle = minimumH_A_AA_Angle;
    }
    
    
    public void setParameters(double maximumDistanceForHydrogenBond, double maximumAcceptorToHydrogenDistance,
			      double minimumD_H_A_Angle, double minimumH_A_AA_Angle)
	{
		setMaximumDistanceForHydrogenBond(maximumDistanceForHydrogenBond);
		setMaximumAcceptorToHydrogenDistance(maximumAcceptorToHydrogenDistance);
		setMinimumD_H_A_Angle(minimumD_H_A_Angle);
		setMinimumH_A_AA_Angle(minimumH_A_AA_Angle);
    }
    
    
    public void setParameters(HydrogenBondLocator hbLocator)
    {
		hbLocator.setParameters(maximumDistanceForHydrogenBond, maximumAcceptorToHydrogenDistance,
				minimumD_H_A_Angle, minimumH_A_AA_Angle);
    }


    private Vector getInterMolecularContacts(Macromolecule macromoleculeA, Macromolecule macromoleculeB)
    {
        // get the intermolecularcontacts between the two
        // macromolecules from the hashtable of interMolecularContacts
        
        Vector interMolecularContacts = null;
        
        String keyA = macromoleculeA.getChainIdentifier() + macromoleculeB.getChainIdentifier();
        String keyB = macromoleculeB.getChainIdentifier() + macromoleculeA.getChainIdentifier();
        
        if(interMolecularContactsTable.containsKey(keyA))
            interMolecularContacts = (Vector)interMolecularContactsTable.get(keyA);
            
        if(interMolecularContactsTable.containsKey(keyB))
            interMolecularContacts = (Vector)interMolecularContactsTable.get(keyB);
            
        if(interMolecularContacts==null)
            System.out.println("Mistake occurred when attempting to get intermolecular contacts");
            
        return interMolecularContacts;
    }
    
    
    
    public Vector getModifiedHydrogenBonds()
    {
		return hydrogenBonds;
    }



    /**
     * adds donor hydrogen atoms to the inputted macromolecule using the appropriate
     * donor geometry.
     * if atom can have multiple hydrogen positions, then some assumptions
     * are made as to what position the hydrogens will take
     */
    public void addDonorHydrogenAtoms(Macromolecule macromoleculeA,Macromolecule macromoleculeB)
    {
        /* get the first pass possible hydrogen bonds
           which is just a matter of whether a hydrogen bond acceptor or donor
           around */
        Vector interMolecularContacts = getInterMolecularContacts(macromoleculeA, macromoleculeB);
        hbondLocator = new HydrogenBondLocator(macromoleculeA,macromoleculeB, interMolecularContacts,pdbInformation);
		setParameters(hbondLocator);
		
        // The largest set of possible hydrogen bonds
		// donors + acceptors which meet a distance cut off
        Hashtable possibleHydrogenBonds = hbondLocator.getSimpleHydrogenBondsInTable();
        possibleHydrogenBondsWithFlexibleHydrogenDonors = new Vector();
        possibleHydrogensBondsWithFixedHydrogenDonors = new Vector();
        
        /* go through and add atoms to all hydrogen bond donors
           this is a first pass, placing hydrogen atoms in intial positions
           for those hydrogen atoms that do not have a "fixed" position */
        for(Enumeration e = possibleHydrogenBonds.keys();e.hasMoreElements();)
        {
			HydrogenBond tempHydrogenBond = (HydrogenBond)e.nextElement();
			Atom hydrogenDonor = tempHydrogenBond.getDonor();
			DonorGroupGeometry donorGeometry = getDonorGeometry(hydrogenDonor);
			
			try
			{
				if(!donorGeometry.areHydrogensFixed())
				{
					possibleHydrogenBondsWithFlexibleHydrogenDonors.add(tempHydrogenBond);
				}
				else
				{
					possibleHydrogensBondsWithFixedHydrogenDonors.add(tempHydrogenBond);
				}
			
				addHydrogens(hydrogenDonor,donorGeometry);
			}
			catch(Exception exc)
			{
				System.out.println("Could not find donor geometry for " + hydrogenDonor);
			}
		}
        
        /* go through all the hydrogen bonds with fixed hydrogen donors
           isRealHydrogenBond actually modifies the instance of the 
           HydrogenBond object when it checks to see if it is a real hydrogen
           bond */
        for(Iterator fixedHydrogenBondIterator = possibleHydrogensBondsWithFixedHydrogenDonors.iterator();
                  fixedHydrogenBondIterator.hasNext();)
        {
            HydrogenBond tempHydrogenBond = (HydrogenBond)fixedHydrogenBondIterator.next();
            
            // if hydrogen bond is not a real hydrogen bond remove it from 
            // list
            if(!hbondLocator.isRealHydrogenBond(tempHydrogenBond))
            {
            }
            else
            {
				hydrogenBonds.add(tempHydrogenBond);
				interMolecularContacts.remove(possibleHydrogenBonds.get(tempHydrogenBond));
                //System.out.println(tempHydrogenBond + " is a hydrogen bond");
            }
        }
	
		for(Iterator flexibleHydrogenBondIterator = possibleHydrogenBondsWithFlexibleHydrogenDonors.iterator();
	    		flexibleHydrogenBondIterator.hasNext();)
	    {
			HydrogenBond tempHydrogenBond = (HydrogenBond)flexibleHydrogenBondIterator.next();
			
			if(!isFlexibleHydrogenBond(tempHydrogenBond))
			{
				hydrogenBonds.remove(tempHydrogenBond);
			}
			else
			{
				hydrogenBonds.add(tempHydrogenBond);
				interMolecularContacts.remove(possibleHydrogenBonds.get(tempHydrogenBond));
			}
		}
    }


    /**
     * analyzeFlexibleHydrogenBonds goes through hydrogen donors with flexible 
     * hydrogens and outputs those hydrogen bonds that fit the criteria for 
     * a hydrogen bond when all of the possible hydrogen positions are analyzed
     */ 
    private boolean isFlexibleHydrogenBond(HydrogenBond flexibleHydrogenBond)
    {
		boolean isHydrogenBond = false;
		DonorGroupGeometry donorGeometry = getDonorGeometry(flexibleHydrogenBond.getDonor());
	
		if(donorGeometry.getHybridization().equals(DonorGroupGeometry.SP2))
		{
			isHydrogenBond = isSwitchableHydrogenBond(flexibleHydrogenBond, donorGeometry);
		}
	
		if(donorGeometry.getHybridization().equals(DonorGroupGeometry.SP3))
		{
			isHydrogenBond = isRotatableHydrogenBond(flexibleHydrogenBond, donorGeometry);
		}
	
		return isHydrogenBond;
    }
    
    
    
    private boolean isSwitchableHydrogenBond(HydrogenBond switchableHydrogenBond, DonorGroupGeometry donorGeometry)
    {
		boolean isSwitchableHydrogenBond = false;
		int whichPositionIsHydrogenBond = NO_POSITION;
		
		Atom donor = switchableHydrogenBond.getDonor();
		Atom acceptor = switchableHydrogenBond.getAcceptor();
		HydrogenInfo hydrogenInfo = donorGeometry.getHydrogenInfoAt(0);
		double angle = AngleTransformer.degreesToRadians(hydrogenInfo.getAngle());
		Atom hydrogen = donor.getParentResidue().getAtom(hydrogenInfo.getName());
		Atom antecedent = donor.getParentResidue().getAtom(donorGeometry.getAntecedent());
		Atom antecedentAntecedent = donor.getParentResidue().getAtom(donorGeometry.getAntecedentAntecedent());
	
		Transform3D outOfLocalCoordinates = generateTransformFromLocalCoordinates(donor,antecedent,antecedentAntecedent);
	
		SphericalPoint3d sphericalPoint = new SphericalPoint3d(hydrogenInfo.getDistance(), 0,angle);
		Point3d firstHydrogenPosition = new Point3d();
	
		outOfLocalCoordinates.transform(CoordinateTransformer.sphericalToCartesian(sphericalPoint),firstHydrogenPosition);
	
		sphericalPoint.theta = Math.PI;
		Point3d secondHydrogenPosition = new Point3d();
		outOfLocalCoordinates.transform(CoordinateTransformer.sphericalToCartesian(sphericalPoint),secondHydrogenPosition);
	
		// test first position
		hydrogen.setX(firstHydrogenPosition.x);
		hydrogen.setY(firstHydrogenPosition.y);
		hydrogen.setZ(firstHydrogenPosition.z);
	
		//check first position
		if(hbondLocator.isRealHydrogenBond(switchableHydrogenBond))
			whichPositionIsHydrogenBond = FIRST_POSITION;
	
		// check second position
		hydrogen.setX(secondHydrogenPosition.x);
		hydrogen.setY(secondHydrogenPosition.y);
		hydrogen.setZ(secondHydrogenPosition.z);
	
		if(hbondLocator.isRealHydrogenBond(switchableHydrogenBond))
			whichPositionIsHydrogenBond = SECOND_POSITION;
		if(whichPositionIsHydrogenBond!= NO_POSITION)
		{
			isSwitchableHydrogenBond = true;
			
			if(whichPositionIsHydrogenBond==FIRST_POSITION)
			{
				hydrogen.setX(firstHydrogenPosition.x);
				hydrogen.setY(firstHydrogenPosition.y);
				hydrogen.setZ(firstHydrogenPosition.z);
			}
		
			if(whichPositionIsHydrogenBond==SECOND_POSITION)
			{
				hydrogen.setX(secondHydrogenPosition.x);
				hydrogen.setY(secondHydrogenPosition.y);
				hydrogen.setZ(secondHydrogenPosition.z);
			}	
		}
		
		return isSwitchableHydrogenBond;
    }
    
    
    
    /**
     * Determines if the donor-acceptor is a hydrogen bond by determining the 
     * closest point on the hydrogen locus to the acceptor and whether the 
     * geometry at the point fits the criteria for a hydrogen bond
     * It does this by determining the perpendicular intersector from the acceptor 
     * to the plane of the hydrogen's circular locus
     * Using that intersection with the plane and a local polar coordinate system, 
     * the closest point on the hydrogen's circular locus is found
     */
    private boolean isRotatableHydrogenBond(HydrogenBond rotatableHydrogenBond, DonorGroupGeometry donorGeometry)
    {
		boolean isRotableHydrogenBond = false;
		
		Atom donor = rotatableHydrogenBond.getDonor();
		Atom acceptor = rotatableHydrogenBond.getAcceptor();
		HydrogenInfo hydrogenInfo = donorGeometry.getHydrogenInfoAt(0);
		
		double angle = AngleTransformer.degreesToRadians(hydrogenInfo.getAngle());
		Atom hydrogen = donor.getParentResidue().getAtom(hydrogenInfo.getName());
		Atom antecedent = donor.getParentResidue().getAtom(donorGeometry.getAntecedent());
		Atom antecedentAntecedent = donor.getParentResidue().getAtom(donorGeometry.getAntecedentAntecedent());
		
		// get three points along the hydrogens circular locus
		SphericalPoint3d hydrogenSphericalPoint = new SphericalPoint3d(hydrogenInfo.getDistance(),0,angle);
		Transform3D outOfLocalCoordinatesTransform = generateTransformFromLocalCoordinates(donor,antecedent, antecedentAntecedent);
		Point3d firstPointOnLocus = new Point3d();
		outOfLocalCoordinatesTransform.transform(CoordinateTransformer.sphericalToCartesian(hydrogenSphericalPoint), firstPointOnLocus);
	
		hydrogenSphericalPoint.theta = Math.PI;
        Point3d acrossFromFirstPoint = CoordinateTransformer.sphericalToCartesian(hydrogenSphericalPoint);
		outOfLocalCoordinatesTransform.transform(acrossFromFirstPoint);
		
		// get center of circular locus and transform acceptor point to local coordinates
		Point3d centerOfLocus = new Point3d((firstPointOnLocus.x + acrossFromFirstPoint.x)/2.0,
			    							(firstPointOnLocus.y + acrossFromFirstPoint.y)/2.0,
			    							(firstPointOnLocus.z + acrossFromFirstPoint.z)/2.0);
		Matrix3d rotationMatrix = generateRotationFromLocalCoordinates(donor,antecedent, antecedentAntecedent);
		Vector3d translation = new Vector3d(centerOfLocus.x,centerOfLocus.y,centerOfLocus.z);
		Transform3D toLocalCoordinates = new Transform3D(rotationMatrix,translation,1.0);
		toLocalCoordinates.invert();
	
		// get the point on the locus that is closest to the acceptor
		// we know that the perpendicular intersector of the x-y plane will be 
		// the x and y of the acceptor position
		// determine polar angle for intersection that gives us the closest point
		Point3d acceptorPoint = 
		new Point3d(acceptor.x,acceptor.y,acceptor.z);
		toLocalCoordinates.transform(acceptorPoint);
		double theta = Math.atan2(acceptorPoint.y, acceptorPoint.x);
		hydrogenSphericalPoint.theta = theta;
		Point3d closestPointOnLocus = new Point3d();
		outOfLocalCoordinatesTransform.transform(CoordinateTransformer.sphericalToCartesian(hydrogenSphericalPoint), closestPointOnLocus);
		hydrogen.x = closestPointOnLocus.x;
		hydrogen.y = closestPointOnLocus.y;
		hydrogen.z = closestPointOnLocus.z;
		isRotableHydrogenBond = hbondLocator.isRealHydrogenBond(rotatableHydrogenBond);
		
		return isRotableHydrogenBond;
    }



    /*
     * addHydrogens takes a hydrogen donor and a donor geometry and adds hydrogens
     * to the structure. The method used to add hydrogens as I see it is somewhat 
     * conditional on the hybridization of the atom and the number of heavy atoms
     * bonded to it.
     */
    private void addHydrogens(Atom hydrogenDonor, DonorGroupGeometry donorGeometry)
    {
        Residue parentResidue = hydrogenDonor.getParentResidue();
        Residue previousResidue = null;
        
        if(parentResidue.getParentMacromolecule().containsPreviousResidue(parentResidue))
        {
            previousResidue = parentResidue.getParentMacromolecule().getPreviousResidue(parentResidue);
        }
        
        int numberOfHydrogens = donorGeometry.getNumberOfHydrogens();
        int numberOfBondedAtoms = donorGeometry.getNumberOfBondedAtoms();
        
        String hybridization = donorGeometry.getHybridization();
        
        // handle everything but sp2, 2 bonded atoms, and 1 hydrogen atom
        // the same way, even the backbone but that might need to change
        if(hybridization.equals(DonorGroupGeometry.SP2) && numberOfHydrogens==1 && numberOfBondedAtoms==3 
                                        && (!(donorGeometry.getAtomName().equals("N"))))
        {
            // the bond to the hydrogen negates the bisector 
            // of the two heavy antecedent bonds
            Atom dd1 = null; Atom dd2 = null;
            
            for(int i=0;i<numberOfBondedAtoms;i++)
            {
                AtomLabel bondedAtom = donorGeometry.getBondedAtomAt(i);
                if(parentResidue.containsAtom(bondedAtom))
                {
                    Atom tempAtom = parentResidue.getAtom(bondedAtom);
                    
                    if(tempAtom.getAtomType().equals("H"))
                        tempAtom = null;
                    
                    if(tempAtom!=null)
                    {
                        if(dd1==null)
                            dd1 = tempAtom;
                        if(dd1!=null && dd2==null && !(dd1.getName().equals(tempAtom.getName())))
                            dd2 = tempAtom;
                    }
                }
            }
            
            addHydrogenBySP2_1H_2DD_STANDARD(dd1,dd2,hydrogenDonor, parentResidue,donorGeometry);
        }
        else
        {
            // handle all other atoms with the specified donor geometry
            // I suppose the idea is that these donor geometries can be modified
            // by the user
            Atom antecedent = null;
            
            if(parentResidue.containsAtom(donorGeometry.getAntecedent()))
                antecedent = parentResidue.getAtom(donorGeometry.getAntecedent());
                
            Atom antecedentAntecedent = null;
            
            if(parentResidue.containsAtom(donorGeometry.getAntecedentAntecedent()))
                antecedentAntecedent = parentResidue.getAtom(donorGeometry.getAntecedentAntecedent());
                
            // We know can use the antecedent and the antecedentAntecedent to get
            // the appropritate local coordinate system
            // It may become necessary to make a guess as to where the hydrogen
            // should go if the antecedent and antecedentAntecedent coordinates are 
            // unknown
            // The backbone nitrogen is only taken care for trans configurations
            // and not cis configurations
            if(antecedent!=null&&antecedentAntecedent!=null)
            {
                for(int j=0;j<numberOfHydrogens;j++)
                {
                    Atom hydrogen = getHydrogen(donorGeometry.getHydrogenInfoAt(j),hydrogenDonor, antecedent,antecedentAntecedent);
                    if(hydrogen!=null && !(parentResidue.containsAtom(hydrogen.getName())))
                    {
                        parentResidue.addAtom(hydrogen);
                        hydrogen.setParentResidue(parentResidue);
                    }
                }
            }
        }
    }
    
    
    
    
    private void addHydrogenBySP2_1H_2DD_STANDARD(Atom dd1, Atom dd2, Atom hydrogenDonor,
                                                 Residue parentResidue, DonorGroupGeometry donorGeometry)
    {
        if(dd1!=null && dd2!=null)
        {
            Vector3d a = new Vector3d(dd1.x-hydrogenDonor.x, dd1.y-hydrogenDonor.y, dd1.z-hydrogenDonor.z);
            Vector3d b = new Vector3d(dd2.x-hydrogenDonor.x, dd2.y-hydrogenDonor.y, dd2.z-hydrogenDonor.z);
            
            Vector3d crossProduct = new Vector3d();
            crossProduct.cross(a,b);
            
            Vector3d differenceVector = new Vector3d();
            a.negate();
            differenceVector.add(b,a);
            
            Vector3d hydrogenDirection = new Vector3d();
            hydrogenDirection.cross(crossProduct,differenceVector);
            hydrogenDirection.normalize();
            
            String hydrogenName = donorGeometry.getHydrogenInfoAt(0).getName();
            
            Atom hydrogen = new Atom(0,hydrogenName,parentResidue.getResName(), hydrogenDonor.getChainID(),hydrogenDonor.getResSeq(),
                            hydrogenDonor.x +hydrogenDirection.x, hydrogenDonor.y +hydrogenDirection.y, hydrogenDonor.z +hydrogenDirection.z);
            parentResidue.addAtom(hydrogen);
            hydrogen.setParentResidue(parentResidue);
        }
    }
    
    
    
    
    private Point3d getHydrogenPositionInLocalCoordinates(double distanceFromDonor, double torsionAngle, double angle)
    {
       SphericalPoint3d hydrogenSphericalPoint = new SphericalPoint3d(1.0,torsionAngle,angle);
       return getHydrogenPositionInLocalCoordinates(hydrogenSphericalPoint);
    }
    
    
    private Point3d getHydrogenPositionInLocalCoordinates(SphericalPoint3d hydrogenSphericalPosition)
    {
        Point3d hydrogenRelativeToDonorLocalCoordinates = CoordinateTransformer.sphericalToCartesian(hydrogenSphericalPosition);
        return hydrogenRelativeToDonorLocalCoordinates;
    }
    
    
    private Atom getHydrogen(HydrogenInfo hydrogenInfo, Atom donorAtom, Atom donorAntecedent, Atom antecedentAntecedent)
    {
        double distance = hydrogenInfo.getDistance();
        double torsionAngle = AngleTransformer.degreesToRadians(hydrogenInfo.getTorsionAngle());
        double angle = AngleTransformer.degreesToRadians(hydrogenInfo.getAngle());
        
        SphericalPoint3d  hydrogenSphericalPosition = new SphericalPoint3d(hydrogenInfo.getDistance(),
                                      AngleTransformer.degreesToRadians(hydrogenInfo.getTorsionAngle()),
                                      AngleTransformer.degreesToRadians(hydrogenInfo.getAngle()));
        Point3d hydrogenPosition = getHydrogenPositionInGlobalCoordinates(hydrogenSphericalPosition,
                                                    donorAtom, donorAntecedent, antecedentAntecedent);
                                                    
        String hydrogenName = hydrogenInfo.getName();
        Atom hydrogen = new Atom(0,hydrogenName,donorAtom.getParentResidue().getResName(), donorAtom.getChainID(),
        						donorAtom.getResSeq(), hydrogenPosition.x,hydrogenPosition.y,hydrogenPosition.z);
        
        return hydrogen;
    }
    
    
    private Point3d getHydrogenPositionInGlobalCoordinates(SphericalPoint3d hydrogenSphericalPosition,
                                       Atom donorAtom, Atom donorAntecedent, Atom antecedentAntecedent)
    {
        Point3d relativeHydrogenPosition = getHydrogenPositionInLocalCoordinates(hydrogenSphericalPosition);
        return getHydrogenPositionInGlobalCoordinates(relativeHydrogenPosition, donorAtom, donorAntecedent, antecedentAntecedent);
    }
       
                                                       
    private Point3d getHydrogenPositionInGlobalCoordinates(Point3d relativeHydrogenPosition,
                           Atom donorAtom, Atom donorAntecedent, Atom antecedentAntecedent)
    {
           Transform3D outOfLocalCoordinatesTransform = generateTransformFromLocalCoordinates(donorAtom,
                                                          donorAntecedent, antecedentAntecedent);
           Point3d hydrogenPosition = new Point3d();
           outOfLocalCoordinatesTransform.transform(relativeHydrogenPosition, hydrogenPosition);
           return hydrogenPosition;
    }
    
    
    
    /**
     * This method generates a transform3D that transforms to a coordinate system
     * where the atom being looked at is at the origin, the antecedent atom
     * is along the z-axis, and the antecedentAntecedent atom has its component 
     * perpendicular to the new z-axis and along the plane formed by two bonds,
     * the antecedent-to-atom, and antecedentAntecedent-to-antecedent
     * antecedentAntecedent -- antecedent -- atom
     */
    private Transform3D generateTransformToLocalCoordinates(Atom atom,Atom antecedent, Atom antecedentAntecedent)
    {
        Vector3d translation = new Vector3d(atom.x,atom.y,atom.z);
        Matrix3d rotationMatrix = generateRotationFromLocalCoordinates(atom, antecedent, antecedentAntecedent);
        Transform3D transform3D = new Transform3D(rotationMatrix,translation,1.0);
		transform3D.invert();
        
        return transform3D;
    }
    
    
    private Matrix3d generateRotationFromLocalCoordinates(Atom atom,Atom antecedent, Atom antecedentAntecedent)
    {
        Vector3d atomToAntecedent = new Vector3d(antecedent.x-atom.x, antecedent.y-atom.y, antecedent.z-atom.z);
        Vector3d antecedentToAntecedentAntecedent = new Vector3d(antecedentAntecedent.x-antecedent.x,
                                      antecedentAntecedent.y-antecedent.y, antecedentAntecedent.z-antecedent.z);
        
        atomToAntecedent.normalize();
        antecedentToAntecedentAntecedent.normalize();
        
        Vector3d toBeYAxis = new Vector3d();
        toBeYAxis.cross(atomToAntecedent,antecedentToAntecedentAntecedent);
        toBeYAxis.normalize();
        
        Vector3d toBeZAxis = atomToAntecedent;
        toBeZAxis.normalize();
        
        Vector3d toBeXAxis = new Vector3d();
        toBeXAxis.cross(toBeYAxis,toBeZAxis);
        
        //   -                                     -
        //  |  toBeXAxis.x toBeYAxis.x toBeZAxis.x  |
        //  |  toBeXAxis.y toBeYAxis.y toBeZAxis.y  |
        //  |  toBeXAxis.z toBeYAxis.z toBeZAxis.z  |
        //   -                                     -
        Matrix3d rotationMatrix = 
            new Matrix3d(toBeXAxis.x, toBeYAxis.x, toBeZAxis.x,
                         toBeXAxis.y, toBeYAxis.y, toBeZAxis.y,
                         toBeXAxis.z, toBeYAxis.z, toBeZAxis.z);
        
        return rotationMatrix;
    }
    
    
    /**
     * You should not use this method if you already used 
     * generateTransformToLocalCoordinates as this will only return
     * the inverse of that
     */
    private Transform3D generateTransformFromLocalCoordinates(Atom atom,Atom antecedent, Atom antecedentAntecedent)
    {
        Vector3d translation = new Vector3d(atom.x,atom.y,atom.z);
        Matrix3d rotationMatrix = generateRotationFromLocalCoordinates( atom, antecedent, antecedentAntecedent);
        Transform3D transform3D = new Transform3D(rotationMatrix,translation,1.0);
        
        return transform3D;
    }



    private void getDonorGroupGeometries() throws ParserConfigurationException, IOException, SAXException
    {
        DonorGroupGeometriesDOMParser donorGroupGeometryParser = 
            			new DonorGroupGeometriesDOMParser(donorGeometryFile);
        donorGroupGeometries = donorGroupGeometryParser.getDonorGroupGeometries();
    }


    private void addDonorGeometry(DonorGroupGeometry donorGeometry)
    {
        donorGroupGeometries.put(donorGeometry.getResidueName() + donorGeometry.getAtomName(), donorGeometry);
    }


    private DonorGroupGeometry getDonorGeometry(Atom atom)
    {
        String key = atom.getResName() + atom.getName();
        DonorGroupGeometry donorGeometry = null;
        
        if(donorGroupGeometries.containsKey(key))
        {
            donorGeometry = (DonorGroupGeometry)donorGroupGeometries.get(key);
        }
        else
        {
            donorGeometry = (DonorGroupGeometry)donorGroupGeometries.get("AnyResidue" + atom.getName());
        }
        
        return donorGeometry;
    }
}
