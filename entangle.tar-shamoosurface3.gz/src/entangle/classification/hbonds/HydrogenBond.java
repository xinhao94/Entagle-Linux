package entangle.classification.hbonds;

import entangle.datastructures.Atom;

/**
 * HydrogenBond includes much of the information about the hydrogen bond
 * including the Atoms corresponding to the donor and acceptor
 *
 * Angles are in degrees
 */
public class HydrogenBond
{
    Atom donor;
    Atom acceptor;
    Atom hydrogen;
    double donorToAcceptorDistance;
    String atomCategories; 				// M(ain-chain), S(ide-chain) or H(etatm) - of D & A
    int gapBetweenResidues; 			// -1 or -2 if not applicable
    double D_H_A_Angle; 				// angle formed by the donor and acceptor at hydrogen(degrees) 
    double hydrogenToAcceptorDistance; 	// -1 if not applicable
    double carbonAlphaToCarbonAlphaDistance;
    double H_A_AA_Angle; 				/* The smaller angle at the Acceptor formed by the hydrogen and an
      										acceptor antecedent (-1 if the hydrogen, or the acceptor antecedent,
      										is not defined) */
    
    
    public String toString()
    {
        String str = "Donor: " + donor.toString() + " Acceptor: " + acceptor.toString();
        return str;
    }
    
    
    public HydrogenBond(Atom donor, Atom acceptor)
    {
		this.donor = donor;
		this.acceptor = acceptor;
    }
    
    public SimpleHBond simpleCopy(){
    	return new SimpleHBond(this);
    }


    public Atom getDonor()
    {
		return donor;
    }


    public Atom getAcceptor()
    {
		return acceptor;
    }


    public void setHydrogen(Atom hydrogen)
    {
        this.hydrogen = hydrogen;
    }
    
    
    public Atom getHydrogen()
    {
        return hydrogen;
    }
    
    
    public void setHydrogenToAcceptorDistance(double distance)
    {
		hydrogenToAcceptorDistance = distance;
    }
    
    public double getHydrogenToAcceptorDistance()
    {
		return hydrogenToAcceptorDistance;
    }


    public void setCarbonAlphaToCarbonAlphaDistance(double distance)
    {
		carbonAlphaToCarbonAlphaDistance = distance;
    }
    
    
    public double getCarbonAlphaToCarbonAlphaDistance(double distance)
    {
		return carbonAlphaToCarbonAlphaDistance;
    }


    public void setH_A_AA_Angle(double angle)
    {
		H_A_AA_Angle = angle;
    }


    public double getH_A_AA_Angle()
    {
		return H_A_AA_Angle;
    }


    public void setGapBetweenResidues(int gap)
    {
		gapBetweenResidues = gap;
    }


    public int getGapBetweenResidues()
    {
		return gapBetweenResidues;
    }
    
    
    /**
     * angle is in degrees
     */
    public void setD_H_A_Angle(double angle)
    {
		D_H_A_Angle = angle;
    }
    
    
    public double getD_H_A_Angle()
    {
		return D_H_A_Angle;
    }

    
    
    public void setDonorToAcceptorDistance(double distance)
    {
		donorToAcceptorDistance = distance;
    }


    public double getDonorToAcceptorDistance()
    {
		return donorToAcceptorDistance;
    }
    
    
    /**
     * <pre>
     * sets the atom categories for the hydrogen bond
     * M(ain-chain), S(ide-chain) or H(etatm) - of D & A
     * e.g.
     *    MM means donor is on main chain and acceptor is on the main chain
     * </pre>
     */
    public void setAtomCategories(String atomCategories)
    {
		this.atomCategories = atomCategories;
    }



    public String getAtomCategories()
    {
		return atomCategories;
    }
}