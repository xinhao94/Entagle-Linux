/*
 * 1.2 code.
 * Last Modified: 8.7.2000
 * Author: Jim Allers (jima@rice.edu)
 */
package entangle.classification;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import entangle.classification.cationpi.CationPiInteractionFinder;
import entangle.classification.electrostatic.ElectrostaticInteractionLocator;
import entangle.classification.hbonds.HydrogenAtomAdder;
import entangle.classification.hbonds.HydrogenBondLocator;
import entangle.classification.hydrophobic.HydrophobicInteractionFinder;
import entangle.classification.stacking.StackingInteractionFinder;
import entangle.classification.vanderwaals.VanderWaalsInteractionFinder;
import entangle.datastructures.Atom;
import entangle.datastructures.AtomPair;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.PDBInformation;
import entangle.datastructures.Residue;

/**
 * N(on)B(onding)InteractionClassifier is a collection of methods that find and classify
 * the interactions between two macromolecules.
 * It instantiates other classes that take care of the dirty work for it, like a hydrogen
 * bond locator or a stacking interaction finder.
 */

public class NBInteractionClassifier
{

    Macromolecule macromoleculeA; // assumed to be a protein
    Macromolecule macromoleculeB; //  assumed to be a nucleic acid
    PDBInformation pdbInformation;
    
    // properties 
    double maximumDistanceForHydrogenBond = 3.9;
    double maximumAcceptorToHydrogenDistance = 2.5;
    double minimumD_H_A_Angle = 90.0;
    double minimumH_A_AA_Angle = 90.0;
    double maximumInteractionDistance = 8.0;
    double maximumStackingDistance = 5.0;
    double maximumStackingAngle = 30.0;
    double maximumDistanceForElectrostaticInteraction = 7.0;
    double maximumDistanceForHydrophobicInteraction = 5.0;
    double maximumVanderWaalsDistance = .8;
    String hydrogenBondFindingMethod = BEST_ENTANGLE_METHOD;
    
    // constants
    final String A = "A";
    final String B = "B";
    final static String BEST_ENTANGLE_METHOD = "Best Entangle Method";
    final static String SIMPLE_METHOD = "Simple Method";


    public NBInteractionClassifier()
    {
		updateProperties();
    }
    
    public NBInteractionClassifier(Macromolecule macromoleculeA, Macromolecule macromoleculeB, PDBInformation pdbInformation)
    {
		this.macromoleculeA = macromoleculeA;
		this.macromoleculeB = macromoleculeB;
		this.pdbInformation = pdbInformation;
		updateProperties();
    }
   
   
    public void updateProperties()
    {
		Properties classifierProperties = ClassifierProperties.getProperties();
		maximumDistanceForHydrogenBond = 
				Double.parseDouble(classifierProperties.getProperty("maximumDistanceForHydrogenBond"));
		maximumAcceptorToHydrogenDistance = 
				Double.parseDouble(classifierProperties.getProperty("maximumAcceptorToHydrogenDistance"));
		maximumDistanceForElectrostaticInteraction = 
				Double.parseDouble(classifierProperties.getProperty("maximumDistanceForElectrostaticInteraction"));
		maximumDistanceForHydrophobicInteraction = 
				Double.parseDouble(classifierProperties.getProperty("maximumDistanceForHydrophobicInteraction"));
		maximumVanderWaalsDistance = 
				Double.parseDouble(classifierProperties.getProperty("maximumVanderWaalsDistance"));
		minimumD_H_A_Angle = 
				Double.parseDouble(classifierProperties.getProperty("minimumD_H_A_Angle"));
		minimumH_A_AA_Angle = 
				Double.parseDouble(classifierProperties.getProperty("minimumH_A_AA_Angle"));
		maximumInteractionDistance = 
				Double.parseDouble(classifierProperties.getProperty("maximumInteractionDistance"));
		maximumStackingDistance = 
				Double.parseDouble(classifierProperties.getProperty("maximumStackingDistance"));
		maximumStackingAngle = 
				Double.parseDouble(classifierProperties.getProperty("maximumStackingAngle"));
		hydrogenBondFindingMethod = 
				classifierProperties.getProperty("hydrogenBondFindingMethod").trim();
    }


    /**
    * This method goes through the two specified macromolecules and looks at the 
    * interactions between the two macromolecules, it has an order so that interactions
    * will not get categorized into two different categories. 
    * - find hydrogen bonds
    * - find electrostatic interactions
    * - find hydrophobic interactions
    * - find VanderWaals interactions
    */
    public NBInteractionContainer findAndClassifyInteractions() 
    	throws ParserConfigurationException, IOException, SAXException
    {
        NBInteractionContainer container =
            new NBInteractionContainer(
                macromoleculeA,
                macromoleculeB,
                pdbInformation);
	
		// first get the interatomic contacts
		AtomToAtomDistances atomToAtomDistances = new AtomToAtomDistances(macromoleculeA,macromoleculeB);
		atomToAtomDistances.setMaximumInteractionDistance(maximumInteractionDistance);
		Vector closeAtomPairs = atomToAtomDistances.getCloseAtomPairs();
		Hashtable interactingGroups = getInteractingGroups(closeAtomPairs);
		container.setInteractingGroups(interactingGroups);
		container.setMacromoleculeAInteractingResidues(getInteractingResidues(closeAtomPairs,A));
		container.setMacromoleculeBInteractingResidues(getInteractingResidues(closeAtomPairs,B));
		container.setPDBInformation(pdbInformation);
		
		// intialize hydrogen bond locator and hydrogen atom adder
        HydrogenBondLocator hydrogenBondLocator =
            new HydrogenBondLocator(
                macromoleculeA,
                macromoleculeB,
                closeAtomPairs,
                pdbInformation);
        Vector macromoleculeVector = new Vector();
        macromoleculeVector.add(macromoleculeA);
        macromoleculeVector.add(macromoleculeB);
        Hashtable intermolecularContactsTable = new Hashtable();
        intermolecularContactsTable.put(macromoleculeA.getChainIdentifier() + macromoleculeB.getChainIdentifier(), closeAtomPairs);
        HydrogenAtomAdder hydrogenAdder = new HydrogenAtomAdder(macromoleculeVector,intermolecularContactsTable, pdbInformation);
		hydrogenBondLocator.maximumAcceptorToHydrogenDistance =
		maximumAcceptorToHydrogenDistance;
		hydrogenBondLocator.maximumDistanceForHydrogenBond = maximumDistanceForHydrogenBond;
		hydrogenBondLocator.minimumD_H_A_Angle = minimumD_H_A_Angle;
		hydrogenBondLocator.minimumH_A_AA_Angle = minimumH_A_AA_Angle;

		// get hydrogen bonds
        container.setHydrogenBonds(
            findHydrogenBonds(
                hydrogenBondLocator,
                hydrogenAdder,
                hydrogenBondFindingMethod));
	
		// get electrostatic interactions
        ElectrostaticInteractionLocator electrostaticInteractionLocator =
            new ElectrostaticInteractionLocator(closeAtomPairs);
        electrostaticInteractionLocator
            .setMaximumDistanceForElectrostaticInteraction(
            maximumDistanceForElectrostaticInteraction);

        container.setElectrostaticInteractions(
            electrostaticInteractionLocator.getElectrostaticInteractions());
	
		// get cation pi interactions
		CationPiInteractionFinder cationPiInteractionFinder = 
			new CationPiInteractionFinder(interactingGroups);
        container.setCationPiInteractions(
            cationPiInteractionFinder.getCationPIInteractions());
		
		// get stacking interactions
        StackingInteractionFinder stackingInteractionFinder =
            new StackingInteractionFinder(
                macromoleculeA,
                macromoleculeB,
                container.getInteractingGroups());
		stackingInteractionFinder.setMaximumStackingAngle(maximumStackingAngle);
		stackingInteractionFinder.setMaximumStackingDistance(maximumStackingDistance);
		
        container.setStackingInteractions(stackingInteractionFinder.getStackingInteractions());
	
	
		// get hydrophobic interactions
		
        HydrophobicInteractionFinder hydrophobicInteractionFinder =
            new HydrophobicInteractionFinder(closeAtomPairs);
        hydrophobicInteractionFinder
            .setMaximumDistanceForHydrophobicInteraction(
            maximumDistanceForHydrophobicInteraction);
	
        container.setHydrophobicInteractions(
            hydrophobicInteractionFinder.getHydrophobicInteractions());
	
		// get vanderwaals interactions
		
        VanderWaalsInteractionFinder vanderWaalsInteractionFinder =
            new VanderWaalsInteractionFinder(closeAtomPairs);
        vanderWaalsInteractionFinder.setMaximumVanderWaalsDistance(
            maximumVanderWaalsDistance);
	
        container.setVanderWaalsInteractions(
            vanderWaalsInteractionFinder.getVanderWaalsInteractions());

		
		// HACK the first of two validation steps which should never have been there in the first
		// place, suggests a better implementation, this checks to see if any of the interacting
		// groups placed into the container don't have any interactions
		// the reason why this is done is because any close atom contacts as determined initially
		// may not fit the criteria of any of the specific interactions
		container.validateInteractingGroups();
		
		// HACK goes through each interacting group and removes any protein residues that are 
		// not participating in an interaction with the nucleic acid residue
		// this should not be necessary
		// the reason why this is done is because any close atom contacts as determined initially
		// may not fit the criteria of any of the specific interactions
		for(Enumeration interactingGroupEnumeration = interactingGroups.elements();
			interactingGroupEnumeration.hasMoreElements();)
		{
			InteractingGroup interactingGroup = (InteractingGroup)interactingGroupEnumeration.nextElement();
			interactingGroup.validateInteractingProteinResidues();
		}
		
		container.maximumAcceptorToHydrogenDistance = maximumAcceptorToHydrogenDistance;
		container.maximumDistanceForElectrostaticInteraction = maximumDistanceForElectrostaticInteraction;
		container.maximumDistanceForHydrogenBond = maximumDistanceForHydrogenBond;
		container.maximumDistanceForHydrophobicInteraction = maximumDistanceForHydrophobicInteraction;
		container.maximumInteractionDistance = maximumInteractionDistance;
		container.maximumStackingAngle = maximumStackingAngle;
		container.maximumStackingDistance = maximumStackingDistance;
		container.maximumVanderWaalsDistance = maximumVanderWaalsDistance;
		container.minimumD_H_A_Angle = minimumD_H_A_Angle;
		container.minimumH_A_AA_Angle = minimumH_A_AA_Angle;

		return container;
     }
 
 
 
   
    /**
     * Builds a hashtable of interacting groups (a nucleic acid residue and all interacting
     * protein residues)
     * @param atompairs the vector of interacting atom pairs
     */
    public Hashtable getInteractingGroups(Vector atomPairs)
    {
	    int size = atomPairs.size();
	    Hashtable interactingGroupsTable = new Hashtable();
	    
	    // go through atom pairs and get the rna atom
	    for(int i = 0;i<size;i++)
	    {
	        AtomPair tempAtomPair = (AtomPair)atomPairs.elementAt(i);
	        Atom tempAtom = tempAtomPair.getMacromoleculeBAtom();
	        Integer resSeqInteger = new Integer(tempAtom.getResSeq());
	        
	        if(!(interactingGroupsTable.containsKey(resSeqInteger)))
	        {
		        Residue nucleicAcidResidue = macromoleculeB.getResidue(resSeqInteger);
				Hashtable interactingMacromoleculeAResidues = new Hashtable();
		
				//find all of the atomPairs that contains this residue
                for(int j = 0;j<size;j++)
                {
		    		AtomPair currentPair = (AtomPair)atomPairs.elementAt(j);
		    		Atom currentMacromoleculeAAtom = currentPair.getMacromoleculeAAtom();
		    		Atom currentMacromoleculeBAtom = currentPair.getMacromoleculeBAtom();
		    		
		    		if(nucleicAcidResidue.containsAtom(currentMacromoleculeBAtom))
		    		{
						Integer tempResSeqInteger = new Integer(currentMacromoleculeAAtom.getResSeq());
						
						if(!(interactingMacromoleculeAResidues.containsKey(tempResSeqInteger)))
			    			interactingMacromoleculeAResidues.put(tempResSeqInteger, macromoleculeA.getResidue(tempResSeqInteger));
		    		}
                }
		
				InteractingGroup interactingGroup = new InteractingGroup(nucleicAcidResidue,interactingMacromoleculeAResidues);
				interactingGroupsTable.put(resSeqInteger,interactingGroup);
	    	}
		}
	
		return interactingGroupsTable;
    }



    /**
    * This method gets all of the residues that are involved in intermolecular interactions.
    * @param atomPairs the pair of atoms
    * @param aOrB
    */
    public Hashtable getInteractingResidues(Vector atomPairs,String aOrB)
    {
        Hashtable interactingResiduesTable = new Hashtable();
        
        for(int i = 0;i<atomPairs.size();i++)
        {
            AtomPair tempAtomPair = (AtomPair)atomPairs.elementAt(i);
            Atom tempAtom;
            
            if(aOrB.equals(A))
            {
                tempAtom = tempAtomPair.getMacromoleculeAAtom();
                Integer resSeqInteger = new Integer(tempAtom.getResSeq());
                
                if(macromoleculeA.containsResidue(resSeqInteger))
                    interactingResiduesTable.put(resSeqInteger, (Residue)macromoleculeA.getResidue(resSeqInteger));
            }
            
            if(aOrB.equals(B))
            {
                tempAtom = tempAtomPair.getMacromoleculeBAtom();
                Integer resSeqInteger = new Integer(tempAtom.getResSeq());
                
                if(macromoleculeB.containsResidue(resSeqInteger))
                    interactingResiduesTable.put(resSeqInteger, (Residue)macromoleculeB.getResidue(resSeqInteger));
            }
        }
        
        return interactingResiduesTable;
    }
    
    
    
    
    public void setMacromoleculeA(Macromolecule protein)
    {
		this.macromoleculeA = protein;
    }

    public Macromolecule getMacromoleculeA()
    {
		return macromoleculeA;
    }

    public void setMacromoleculeB(Macromolecule rna)
    {
		this.macromoleculeB = rna;
    }
    
    public Macromolecule getMacromoleculeB()
    {
		return macromoleculeB;
    }

    public void setPDBInformation(PDBInformation pdbInformation)
    {
		this.pdbInformation = pdbInformation;
    }

    public PDBInformation getPDBInformation()
    {
		return pdbInformation;
    }



    /**
     * Method which uses the hydrogenBondLocator to locate the hydrogen bonds
     */
    public Vector findHydrogenBonds(HydrogenBondLocator hydrogenBondLocator, HydrogenAtomAdder hydrogenAdder, String hydrogenBondFindingMethod)
	{
		Vector hydrogenBonds = null;
		
		if(hydrogenBondFindingMethod.equals(BEST_ENTANGLE_METHOD))
		{
			// find out if macromolecule already has hydrogen coordinates
			Residue testResidue = (Residue)macromoleculeA.getResidueEnumeration().nextElement();
		    
		    boolean containsHydrogens = false;
		    
		    // check every residue and check to see if one of the atoms is a 
		    // hydrogen.
			for(Enumeration e = testResidue.getAtomEnumeration(); e.hasMoreElements();)
			{
				Atom tempAtom = (Atom)e.nextElement();
				
				if(tempAtom.getAtomType().equals("H"))
					containsHydrogens = true;
			}
			
			if(containsHydrogens)
			{
				hydrogenBonds = hydrogenBondLocator.getHydrogenBonds();
			}
			else
			{
				hydrogenAdder.addDonorHydrogenAtoms(macromoleculeA,macromoleculeB);
				hydrogenBonds = hydrogenAdder.getModifiedHydrogenBonds();
			}
		}
		
		if(hydrogenBondFindingMethod.equals(SIMPLE_METHOD))
		{
			hydrogenBonds = hydrogenBondLocator.getSimpleHydrogenBonds();
		}
	
		return hydrogenBonds;
    }
}