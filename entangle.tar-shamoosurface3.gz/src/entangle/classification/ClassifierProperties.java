/*
 * ClassificatierProperties.java
 *
 * Created on October 5, 2000, 2:12 AM
 */

package entangle.classification;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Singleton which represents the properties of the classifier
 * maximumDistanceForHydrogenBond = 3.9
 * maximumAcceptorToHydrogenDistance = 2.5
 * maximumDistanceForElectrostaticInteraction = 8.0
 * maximumDistanceForHydrophobicInteraction = 5.0
 * minimumD_H_A_Angle = 90.0
 * minimumH_A_AA_Angle = 90.0
 * maximumInteractionDistance = 7.0
 * maximumStackingDistance = 5.0
 * maximumStackingAngle = 30.0
 * hydrogenBondFindingMethod = Best Entangle Method
 * maximumVanderWaalsDistance = .8
 * @author  Jim Allers
 * @version 
 */
 
public class ClassifierProperties extends Properties 
{
	static ClassifierProperties properties = null;
	static File classifierPropertiesFile = new File(System.getProperty("user.dir") + 
					File.separator + "classifier.properties");
	
	
	private ClassifierProperties() 
	{
	}
	
	
	public static ClassifierProperties getProperties()
	{
		if(properties == null)
		{
			init();
		}
		return properties;
	}
	
	
	static void init()
	{
		properties = new ClassifierProperties();
		
		try
		{
			properties.load(new FileInputStream(classifierPropertiesFile));
		}
		catch(IOException e)
		{
			System.out.println("Could not load properties file");
			System.out.println(e);
		}
	}
	
	public String getClassifierProperty(String key)
	{
		if(properties==null)
		{
			init();
		}
		return properties.getProperty(key);
	}
}