package entangle.classification;

import java.util.Enumeration;
import java.util.Vector;

import entangle.classification.cationpi.CationPiInteraction;
import entangle.classification.cationpi.SimpleCPInteraction;
import entangle.classification.electrostatic.ElectrostaticInteraction;
import entangle.classification.hbonds.HydrogenBond;
import entangle.classification.hydrophobic.HydrophobicInteraction;
import entangle.classification.stacking.StackingInteraction;
import entangle.classification.vanderwaals.VanderWaalsInteraction;
import entangle.datastructures.Residue;
import entangle.datastructures.SimplePResidue;
import entangle.datastructures.SimpleRNAResidue;
import entangle.utils.Transformable;
import entangle.utils.math.XYZMatrix;

/**
 * @author LRM
 *
 * Represents a much simpler, more memory efficient Interacting Group with all pertinent info
 * Used primarily for multiple file analysis for Nucleic Acid base generalization
 */
public class SimpleInteractingGroup implements Transformable{

	public SimpleRNAResidue nucleicAcidResidue;
    public Vector interactingProteinResidues;		// list of SimplePResidue
    
    // All lists of simple interactions
    public Vector hydrogenBonds;
    public Vector hydrophobicInteractions;
    public Vector vanderWaalsInteractions;
    public Vector electrostaticInteractions;
    public Vector stackingInteractions;
	public Vector cationPiInteractions;
	
	public SimpleInteractingGroup(InteractingGroup ig){
		System.out.println("Creating a new SimpleInteractingGroup");
		
		System.out.println("....copying RNA");
		nucleicAcidResidue = ig.nucleicAcidResidue.simpleRNACopy();
		
		System.out.println("....copying Protein Residues");
		interactingProteinResidues = new Vector();
		Enumeration e = ig.interactingProteinResidues.elements();
		while(e.hasMoreElements()){
			Residue r = (Residue)e.nextElement();
			interactingProteinResidues.add(new SimplePResidue(r));
		}
		
		
		System.out.println("....copying Hydrogen Bonds");
		hydrogenBonds = new Vector();
		e = ig.hydrogenBonds.elements();
		while(e.hasMoreElements()){
			HydrogenBond hb = (HydrogenBond)e.nextElement();
			hydrogenBonds.add(hb.simpleCopy() );
		}
		
		System.out.println("....copying Hydrophobic Interactions");
		hydrophobicInteractions = new Vector();
		e = ig.hydrophobicInteractions.elements();
		while(e.hasMoreElements()){
			HydrophobicInteraction hi = (HydrophobicInteraction)e.nextElement();
			hydrophobicInteractions.add(hi.simpleCopy() );
		}
		
		System.out.println("....copying VanderWaals Interactions");
		vanderWaalsInteractions = new Vector();
		e = ig.vanderWaalsInteractions.elements();
		while(e.hasMoreElements()){
			VanderWaalsInteraction vi = (VanderWaalsInteraction)e.nextElement();
			vanderWaalsInteractions.add(vi.simpleCopy() );
		}
		
		System.out.println("....copying Electrostatic Interactions");
		electrostaticInteractions = new Vector();
		e = ig.electrostaticInteractions.elements();
		while(e.hasMoreElements()){
			ElectrostaticInteraction ei = (ElectrostaticInteraction)e.nextElement();
			electrostaticInteractions.add(ei.simpleCopy() );
		}
		
		System.out.println("....copying Stacking Interactions");
		stackingInteractions = new Vector();
		e = ig.stackingInteractions.elements();
		while(e.hasMoreElements()){
			StackingInteraction si = (StackingInteraction)e.nextElement(); 
			stackingInteractions.add(si.simpleCopy() );
		}
		
		System.out.println("...copying Cation Pi Interactions");
		cationPiInteractions = new Vector();
		e = ig.cationPiInteractions.elements();
		while(e.hasMoreElements()){
			CationPiInteraction cpi = (CationPiInteraction)e.nextElement();
			cationPiInteractions.add(new SimpleCPInteraction(cpi));
		}
		
		System.out.println("....DONE creating new SIG");
	}
	
	
	public void transform(XYZMatrix t, double r1, double r2, double r3){
		nucleicAcidResidue.transform(t,r1,r2,r3);
		
		Vector v = hydrogenBonds;
		Enumeration e = v.elements();
		while(e.hasMoreElements()){
			Transformable element = (Transformable)e.nextElement();
			element.transform(t,r1,r2,r3);
		}
		
		v = hydrophobicInteractions;
		e = v.elements();
		while(e.hasMoreElements()){
			Transformable element = (Transformable)e.nextElement();
			element.transform(t,r1,r2,r3);
		}
		
		v = electrostaticInteractions;
		e = v.elements();
		while(e.hasMoreElements()){
			Transformable element = (Transformable)e.nextElement();
			element.transform(t,r1,r2,r3);
		}
		
		v = vanderWaalsInteractions;
		e = v.elements();
		while(e.hasMoreElements()){
			Transformable element = (Transformable)e.nextElement();
			element.transform(t,r1,r2,r3);
		}
		
		v = stackingInteractions;
		e = v.elements();
		while(e.hasMoreElements()){
			Transformable element = (Transformable)e.nextElement();
			element.transform(t,r1,r2,r3);
		}
		
		v = cationPiInteractions;
		e = v.elements();
		while(e.hasMoreElements()){
			Transformable element = (Transformable)e.nextElement();
			element.transform(t,r1,r2,r3);
		}
	}
}