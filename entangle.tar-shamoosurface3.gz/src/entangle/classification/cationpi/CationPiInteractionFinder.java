/*
 * Created on May 30, 2003
 */
package entangle.classification.cationpi;

import java.io.File;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import javax.vecmath.Point3d;

import entangle.classification.InteractingGroup;
import entangle.datastructures.Atom;
import entangle.datastructures.AtomPair;
import entangle.datastructures.Residue;
import entangle.utils.EntangleProperties;
import entangle.utils.io.AromaticRingDOMParser;

/**
 * Uses a simple distance anyalysis to find potential cation pi interactions.
 * It calculates four distances from potential cation atoms to the center
 * of the aromatic ring to the members of the aromatic ring.
 * 
 * @author Jim Allers
 */
public class CationPiInteractionFinder {	
	/**
	 * table of <code>InteractingGroup</code>s keyed by their residue sequence
	 * number
	 */
	private Hashtable interactingGroups;
	
	private Vector cationPiInteractions = new Vector(); 
	
	/**
	 * the table of aromatic rings inside of the residues keyed by their residue
	 * name
	 */
	private Hashtable rings;
	
	private double maximumCationToCenterDistance = 11.0;
	private double maximumDistanceToRingAtom = 7.0;
	
    private String[][] cationicResidueArray =
        new String[][] {
            new String[] { "ARG", "CD", "CZ" },
            new String[] { "LYS", "CE", "NZ" }
    };
	
	private boolean foundCationPiInteractions = false;
	
	public CationPiInteractionFinder(Hashtable interactingGroups)
	{
		this.interactingGroups = interactingGroups;
		this.getRings();
	}
	
	
	/**
	 * This method goes through all of the interacting groups and determines if any of them contain a stacking interaction
	 * These stacking interactions are then depositing into a vector of StackingInteractions
	 */
	private void findCationPiInteractions()
	{
		// iterate through the interacting groups and determine if one of the
		// interacting groups has one of the recognized cations and whether one
		// of them has an aromatic ring
		Enumeration interactingGroupsEnumeration = interactingGroups.elements();
		
		while (interactingGroupsEnumeration.hasMoreElements()) {
            InteractingGroup interactingGroup =
                (InteractingGroup) interactingGroupsEnumeration.nextElement();
			// now iterate through each of the protein residues that are
			// potentially interacting with the residue
			Residue nucleicAcidResidue = interactingGroup.getNucleicAcidResidue();
			
			// get the Vector ring atom names for the nucleic acid residue
			// all nucleic acids are aromatic, so we don't need to do the test.
			Vector ringAtomNames = (Vector)rings.get(nucleicAcidResidue.getResName());
			if(ringAtomNames == null){
                System.err.println(
                    "Error: no ring atoms for "
                        + nucleicAcidResidue.getResName());
				System.err.println("All nucleic acids should be considered aromatic!");
				continue;
			}
			
			// go through the list of interacting protein residues to figure out whether a cationic residue
			// was found to be interacting with this nucleic acid residue.
			Hashtable interactingPRTable =
				(Hashtable) interactingGroup.getInteractingProteinResidues();
			Enumeration interactingProteinResidues = (Enumeration)interactingPRTable.elements();
			while (interactingProteinResidues.hasMoreElements()) {
				Residue proteinResidue = (Residue) interactingProteinResidues.nextElement();
				String resName = proteinResidue.getResName();
				
				String[] cationicResInfo = null;
				for(int i=0;i<cationicResidueArray.length;i++){
					String[] tempCationicResInfo = cationicResidueArray[i];
					if(tempCationicResInfo[0].equals(resName.toUpperCase())){
						cationicResInfo = tempCationicResInfo;
						// interacting protein residue is cationic
						break;
					}
				}
				
				if(cationicResInfo != null){
					addIfCationPiInteraction(
						nucleicAcidResidue,
						ringAtomNames,
						proteinResidue,
						cationicResInfo);
				}
			}
        }
        foundCationPiInteractions = true;
	}


    private void addIfCationPiInteraction(
        Residue nucleicAcidResidue,
        Vector ringAtomNames,
        Residue proteinResidue,
        String[] cationicResInfo) {
    	// if the two residues can form a possible cation-PI interaction
    	// they meet some distance requirement between the cationic
    	// atoms and the ring atoms, a distance requirment to the 
    	// center of the ring is also somewhat valuable
    	AtomPair[] atomPairs = new AtomPair[3];
    	
    	// find three threshold contacts between the 
    	// three cations and atom pairs
        find3ThresholdContacts(
            nucleicAcidResidue,
            ringAtomNames,
            proteinResidue,
            cationicResInfo,
            atomPairs);
    	
    	// if there are 3 atom pairs that meet the distance criteria
    	// we have a potential cation pi interaciton
    	if(areNoNull(atomPairs)){
    		// figure out the center of the ring
            Point3d centerOfRing =
               getCenterOfRing(nucleicAcidResidue, ringAtomNames);
    		Atom cationAtom = atomPairs[0].getMacromoleculeBAtom();
            Point3d cationPoint =
                new Point3d(
                    cationAtom.x,
                    cationAtom.y,
                    cationAtom.z);
            double distanceToCenter =
                cationPoint.distance(centerOfRing);
            CationPiInteraction cationPiInteraction =
                new CationPiInteraction(cationAtom,
                                        nucleicAcidResidue,
                                        distanceToCenter,
                                        atomPairs);
    		cationPiInteractions.add(cationPiInteraction);
    	}
    }


    private void find3ThresholdContacts(
        Residue nucleicAcidResidue,
        Vector ringAtomNames,
        Residue proteinResidue,
        String[] cationicResInfo,
        AtomPair[] atomPairs) {
        // figure out the closest three interacting ring atoms to all of the 
        // the designated atoms on the cationic residue
        // if the 3 closest are all within some threshold, include it as 
        // a potential cation pi interaction
        // go through each of the atoms.
        for(int i=1;i<cationicResInfo.length && !areNoNull(atomPairs);i++){
        	Arrays.fill(atomPairs,null);
        	
        	Atom cationAtom =
        		proteinResidue.getAtom(cationicResInfo[i]);
        	
        	if(cationAtom == null){
        		// TODO figure out if this can happen
				System.err.println("WARNING: Expected cation atom " + cationicResInfo[i]
                                    + " for " + proteinResidue.getResName());
        		continue;
        	}
        	
        	// the calculated distance can happen
        	for (Iterator iter = ringAtomNames.iterator();
        		iter.hasNext();
        		) {
        		String ringAtomName = (String) iter.next();
        		// get the atom from the residue
        		Atom ringAtom = nucleicAcidResidue.getAtom(ringAtomName);
            	if(ringAtom == null){
            		System.out.println("WARNING: Expected ring atom " + ringAtomName
            		                   + " for " + nucleicAcidResidue.getResName());
            		// TODO figure out why this can happen
            		continue;
            	}
            	
                AtomPair atomPair =
                    new AtomPair(ringAtom, cationAtom);
        		
        		if(atomPair.getDistance() < maximumDistanceToRingAtom){
        			// is it closer than any of the other atoms
        			// already calculated and within the threshold
        			for (int j = 0; j < atomPairs.length; j++) {
                        AtomPair pair = atomPairs[j];
                        if (pair == null
                            || pair.getDistance()
                                > atomPair.getDistance()) {
                            // found one break the loop
                            atomPairs[j] = atomPair;
                            break;
                        }
                    }
        		}							
        	}
        }
    }
	
	/**
	 * Returns the center of the aromatic ring specified
	 */
	public Point3d getCenterOfRing(Residue residue, Vector ringMembers)
	{
		double totalX = 0;
		double totalY = 0;
		double totalZ = 0;
        
		Atom currentAtom;
        
		for(Enumeration e = ringMembers.elements();e.hasMoreElements();)
		{
			currentAtom = residue.getAtom((String)e.nextElement());
			if(currentAtom!=null)
			{
				totalX += currentAtom.getX();
				totalY += currentAtom.getY();
				totalZ += currentAtom.getZ();
			}
		}
        
		Point3d center =
			new Point3d(
				totalX / ringMembers.size(),
				totalY / ringMembers.size(),
				totalZ / ringMembers.size());
        
		return center;
	}
	
	public boolean areNoNull(Object[] objects){
		for (int i = 0; i < objects.length; i++) {
            if(objects[i] == null){
            	return false;
            }
        }
        return true;
	}
	
	public Vector getCationPIInteractions(){
		if(!foundCationPiInteractions){
			findCationPiInteractions();
		}
		return cationPiInteractions;
	}

	public void getRings()
	{
		try
		{
            String fileName =
                EntangleProperties.getProperties().getProperty(
                    "entangle.aromaticRingsFile");
            File aromaticRingsFile =
                new File(
                    System.getProperty("user.dir") + File.separator + fileName);
            AromaticRingDOMParser parser =
                new AromaticRingDOMParser(aromaticRingsFile);
			rings = parser.getAromaticRings();
		}
		catch(Exception e)
		{
			e.printStackTrace(System.out);
		}
	}

}
