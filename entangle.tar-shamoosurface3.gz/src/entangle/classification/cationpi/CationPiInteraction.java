/*
 * Created on May 30, 2003
 */
package entangle.classification.cationpi;

import entangle.datastructures.Atom;
import entangle.datastructures.AtomPair;
import entangle.datastructures.Residue;

/**
 * Used to represent a caption pi interaction and the relevant parameters used
 * to determine it.
 * 
 * @author Jim Allers
 */
public class CationPiInteraction {
	private Atom cation;
	private Residue aromaticResidue;
	
	private double distanceToCenterOfRing;
	
	private AtomPair[] distancesToPiAtoms = new AtomPair[3];
	
	public CationPiInteraction(Atom cation,Residue aromaticResidue,
	                            double distanceToCenterOfRing,
	                            AtomPair[] distanceToPiAtoms){
		this.cation = cation;
		this.aromaticResidue = aromaticResidue;
		this.distanceToCenterOfRing = distanceToCenterOfRing;
		this.distancesToPiAtoms = distanceToPiAtoms;
	}
	
	public Atom getCationAtom(){
		return cation;
	}
	
	public Residue getAromaticResidue(){
		return aromaticResidue;
	}
	
	public double getCationToRingCenterDistance(){
		return distanceToCenterOfRing;
	}
	
	/**
	 * @return the array of atom names and distances to those atoms
	 * These atoms must be alternating around the ring.
	 * The macromolecule A atom is a pi atom.
	 * The macromolecule B atom is the cation atom
	 */
	public AtomPair[] getDistancesToPiAtoms(){
		return distancesToPiAtoms;
	}
}
