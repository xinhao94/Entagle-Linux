/*
 * Created on Jun 2, 2003
 */
package entangle.classification.cationpi;

import entangle.datastructures.AtomPair;
import entangle.datastructures.SimpleAtom;
import entangle.datastructures.SimpleAtomPair;
import entangle.utils.Transformable;
import entangle.utils.XMLEnabled;
import entangle.utils.math.XYZMatrix;

/**
 * @author Jim Allers
 *
 */
public class SimpleCPInteraction implements Transformable,XMLEnabled{	
	double cationToCenterDistance; // the distance between the two centers of the aromatic rings
	
	SimpleAtomPair[] atomPairs;
	SimpleAtom cation;
	
	public SimpleCPInteraction(CationPiInteraction cationPiInteraction){
		cationToCenterDistance = cationPiInteraction.getCationToRingCenterDistance();
		atomPairs = new SimpleAtomPair[cationPiInteraction.getDistancesToPiAtoms().length];
		for (int i = 0; i < cationPiInteraction.getDistancesToPiAtoms().length; i++) {
            AtomPair ap = cationPiInteraction.getDistancesToPiAtoms()[i];
            atomPairs[i] = new SimpleAtomPair(ap);
        }
        cation = cationPiInteraction.getCationAtom().simpleCopy();
	}
	
	public void transform(XYZMatrix t, double r1, double r2, double r3){
		cation.transform(t,r1,r2,r3);
	}
	
	public String buildXML(){
		String atomXML = "        <CationPiInteraction>";
		atomXML += 	   "\n            <CationToCenterOfRing>" + cationToCenterDistance + "</CationToCenterOfRing>";
		atomXML +=     "\n            <Cation>";
		atomXML +=     "\n                <atomName>" + cation.name + "</atomName>";
		atomXML +=     "\n                <resName>" + cation.resName + "</resName>";
		atomXML +=     "\n                <x>" + cation.x + "</x>";
		atomXML +=     "\n                <y>" + cation.y + "</y>";
		atomXML +=     "\n                <z>" + cation.z + "</z>";
		atomXML +=     "\n            </Cation>";
		atomXML +=     "\n        </CationPiInteraction>";
		
		return   atomXML;
	}
	
	public String buildHTML(){
		return "<tr><td>" + cationToCenterDistance + "</td><td>" +
							cation.name + "</td><td>" +  
							cation.resName + "</td><td>" + 
							cation.x + "</td><td>" + 
							cation.y + "</td><td>" + 
							cation.z + "</td></tr>";
	}
	/**
	 * @return
	 */
	public SimpleAtom getCation() {
		return cation;
	}

}
