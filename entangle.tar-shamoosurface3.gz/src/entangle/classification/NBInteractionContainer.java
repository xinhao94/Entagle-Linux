/*
 * NonCovalentInteractionContainer.java
 *
 * Created on September 9, 2000, 11:55 PM
 */

package entangle.classification;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import entangle.classification.cationpi.CationPiInteraction;
import entangle.classification.electrostatic.ElectrostaticInteraction;
import entangle.classification.hbonds.HydrogenBond;
import entangle.classification.hydrophobic.HydrophobicInteraction;
import entangle.classification.stacking.StackingInteraction;
import entangle.classification.vanderwaals.VanderWaalsInteraction;
import entangle.datastructures.Atom;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.PDBInformation;
import entangle.datastructures.Residue;

/**
 * N(on)B(onding)InteractionContainer holds the interactions between two
 * macromolecules.
 * It also contains interacting groups which contain interactions as well
 * It is necessary to set the interacting groups before adding interactions to 
 * the container. 
 * @author  Jim Allers
 * @version 
 */
 
public class NBInteractionContainer extends Object
{
	Macromolecule macromoleculeA;
	Macromolecule macromoleculeB;
	PDBInformation pdbInformation;
	
    public double maximumAcceptorToHydrogenDistance;
	public double maximumDistanceForElectrostaticInteraction;
	public double maximumDistanceForHydrogenBond;
	public double maximumDistanceForHydrophobicInteraction;
	public double maximumInteractionDistance;
	public double maximumStackingAngle;
	public double maximumStackingDistance;
	public double maximumVanderWaalsDistance;
	public double minimumD_H_A_Angle;
	public double minimumH_A_AA_Angle;
	
	// interactions and interacting residues
   	Vector hydrogenBonds;
    Vector electrostaticInteractions;
    Vector stackingInteractions;
    Vector hydrophobicInteractions;
    Vector vanderWaalsInteractions;
    Vector cationPiInteractions;
    
    Hashtable macromoleculeAInteractingResidues;
   	Hashtable macromoleculeBInteractingResidues;
  	Hashtable interactingGroupsTable; 
    // keyed by the rna residue sequence number
    // which is macromoleculeB 
        
        
	/** Creates new NonCovalentInteractionContainer */	
	final public static int HYDROGEN_BOND 				= 69;
    final public static int ELECTROSTATIC_INTERACTION 	= 70;
    final public static int STACKING_INTERACTION 		= 71;
	final public static int HYDROPHOBIC_INTERACTION 	= 72;
	final public static int VANDERWAALS_INTERACTION 	= 73;
	final public static int CATIONPI_INTERACTION        = 74;
	
	
	
    public NBInteractionContainer(
        Macromolecule macromoleculeA,
        Macromolecule macromoleculeB,
        PDBInformation pdbInformation) {
        this.macromoleculeA = macromoleculeA;
        this.macromoleculeB = macromoleculeB;
        this.pdbInformation = pdbInformation;
    }
	
	
	
	public void setInteractingGroups(Hashtable interactingGroupsTable)
	{
		this.interactingGroupsTable = interactingGroupsTable;
	}
	
	
	public void setMacromoleculeAInteractingResidues(Hashtable macromoleculeAInteractingResidues)
	{
		this.macromoleculeAInteractingResidues = macromoleculeAInteractingResidues;
	}
	
	
	public Hashtable getMacromoleculeAInteractingResidues()
	{
		return macromoleculeAInteractingResidues;
	}
	
	
	public void setMacromoleculeBInteractingResidues(Hashtable macromoleculeBInteractingResidues)
	{
		this.macromoleculeBInteractingResidues = macromoleculeBInteractingResidues;
	}
	
	
	public Hashtable getMacromoleculeBInteractingResidues()
	{
		return macromoleculeBInteractingResidues;
	}
	
	
	
	/**
	 * Entangle's convention is to have macromolecule A be a protein
	 */
	public void setMacromoleculeA(Macromolecule protein)
	{
		this.macromoleculeA = protein;
	}

	public Macromolecule getMacromoleculeA()
	{
		return macromoleculeA;
	}


	/**
     * Entangle's convention is to have macromolecule B be a nucleic acid 
	 */
	public void setMacromoleculeB(Macromolecule rna)
	{
		this.macromoleculeB = rna;
	}

	public Macromolecule getMacromoleculeB()
	{
		return macromoleculeB;
	}



	public void setPDBInformation(PDBInformation pdbInformation)
	{
		this.pdbInformation = pdbInformation;
	}
	
	public PDBInformation getPDBInformation()
	{
		return pdbInformation;
    }



	public void setHydrogenBonds(Vector hydrogenBonds)
	{
		this.hydrogenBonds = hydrogenBonds;
		
		if(interactingGroupsTable!=null)
		{
			for(Iterator iterator = hydrogenBonds.iterator(); iterator.hasNext();)
			{
				addInteraction((HydrogenBond)iterator.next());
			}
		}
	}
	
	
	
	public void addInteraction(Object interaction)
	{
		Residue macromoleculeBResidue = null;
		
		int interactionType = 0;
		
		if(interaction instanceof HydrogenBond)
			interactionType = HYDROGEN_BOND;
		if(interaction instanceof HydrophobicInteraction)
			interactionType = HYDROPHOBIC_INTERACTION;
		if(interaction instanceof VanderWaalsInteraction)
			interactionType = VANDERWAALS_INTERACTION;
		if(interaction instanceof StackingInteraction)
			interactionType = STACKING_INTERACTION;
		if(interaction instanceof ElectrostaticInteraction)
			interactionType = ELECTROSTATIC_INTERACTION;
		if(interaction instanceof CationPiInteraction){
			interactionType = CATIONPI_INTERACTION;
		}
			
		switch(interactionType)
		{
			case HYDROGEN_BOND:
				HydrogenBond hydrogenBond = (HydrogenBond)interaction;
				macromoleculeBResidue = whichResidue(hydrogenBond.getDonor(), hydrogenBond.getAcceptor());
				break;
			
			case HYDROPHOBIC_INTERACTION:
				HydrophobicInteraction hydrophobicInteraction = (HydrophobicInteraction)interaction;
				macromoleculeBResidue = whichResidue(hydrophobicInteraction.getNonPolarAtomA(), hydrophobicInteraction.getNonPolarAtomB());
				break;
			
			case VANDERWAALS_INTERACTION:
				VanderWaalsInteraction vanderWaalsInteraction = (VanderWaalsInteraction)interaction;
				macromoleculeBResidue = whichResidue(vanderWaalsInteraction.getAtomA(), vanderWaalsInteraction.getAtomB());
				break;
				
			case STACKING_INTERACTION:
				StackingInteraction stackingInteraction = (StackingInteraction)interaction;
				Residue ra = stackingInteraction.getResidueA();
				Residue rb = stackingInteraction.getResidueB();
				if(macromoleculeB.containsResidue(ra))
				{
					macromoleculeBResidue = ra;
				}
				else
				{
					macromoleculeBResidue = rb;
				}
				break;
				
			case ELECTROSTATIC_INTERACTION:
				ElectrostaticInteraction electrostaticInteraction = (ElectrostaticInteraction)interaction;
				macromoleculeBResidue = whichResidue(
						electrostaticInteraction.getNegativeAtom(),
						electrostaticInteraction.getPositiveAtom());
				break;
			
			case CATIONPI_INTERACTION:
				CationPiInteraction cationPiInteraction = (CationPiInteraction)interaction;
				macromoleculeBResidue = cationPiInteraction.getAromaticResidue();
				break;
			default:
		}
		
		
		Integer resSeqInteger = new Integer(macromoleculeBResidue.getResidueSequenceNumber());
		InteractingGroup interactingGroup = (InteractingGroup)interactingGroupsTable.get(resSeqInteger);
		
		switch(interactionType)
		{
			case HYDROGEN_BOND:
				interactingGroup.addHydrogenBond((HydrogenBond)interaction);
				break;
				
			case HYDROPHOBIC_INTERACTION:
				interactingGroup.addHydrophobicInteraction((HydrophobicInteraction)interaction);
				break;
				
			case VANDERWAALS_INTERACTION:
				interactingGroup.addVanderWaalsInteraction((VanderWaalsInteraction)interaction);
				break;
				
			case STACKING_INTERACTION:
				interactingGroup.addStackingInteraction((StackingInteraction)interaction);
				break;
				
			case ELECTROSTATIC_INTERACTION:
				interactingGroup.addElectrostaticInteraction((ElectrostaticInteraction)interaction);
				break;
			
			case CATIONPI_INTERACTION:
				interactingGroup.addCationPiInteraction((CationPiInteraction)interaction);
			default:
		}
	}
	
	
	
	/**
	* This method determines which of the atoms is in a residue that
	* is in Macromolecule B
	*/ 
	private Residue whichResidue(Atom atomA, Atom atomB)
	{
		Residue residue = null;
		
		if(macromoleculeB.containsResidue(atomA.getParentResidue()))
			residue = atomA.getParentResidue();
			
		if(macromoleculeB.containsResidue(atomB.getParentResidue()))
			residue = atomB.getParentResidue();
			
		return residue;
	}
		
		
		
	public Vector getHydrogenBonds()
	{
		return hydrogenBonds;
	}
	
	
	public void setElectrostaticInteractions(Vector electrostaticInteractions)
	{
		this.electrostaticInteractions = electrostaticInteractions;
		
		if(interactingGroupsTable!=null)
		{
			for(Iterator iterator = electrostaticInteractions.iterator(); iterator.hasNext();)
			{
				addInteraction((ElectrostaticInteraction)iterator.next());
			}
		}
	}
	
	
	public Vector getElectrostaticInteractions()
	{
		return electrostaticInteractions;
	}
	
	
	public void setStackingInteractions(Vector stackingInteractions)
	{
		this.stackingInteractions = stackingInteractions;
		
		if(interactingGroupsTable!=null)
		{
			for(Iterator iterator = stackingInteractions.iterator(); iterator.hasNext();)
			{
				addInteraction((StackingInteraction)iterator.next());
			}
		}
	}
	
	
	public Vector getStackingInteractions()
	{
		return stackingInteractions;
	}
	
	
	public void setHydrophobicInteractions(Vector hydrophobicInteractions)
	{
		this.hydrophobicInteractions = hydrophobicInteractions;
		if(interactingGroupsTable!=null)
		{
			for(Iterator iterator = hydrophobicInteractions.iterator(); iterator.hasNext();)
			{
				addInteraction((HydrophobicInteraction)iterator.next());
			}
		}
	}
	
	
	public Vector getHydrophobicInteractions()
	{
		return hydrophobicInteractions;
	}
	
	
	public void setVanderWaalsInteractions(Vector vanderWaalsInteractions)
	{
		this.vanderWaalsInteractions = vanderWaalsInteractions;
		if(interactingGroupsTable!=null)
		{
			for(Iterator iterator = vanderWaalsInteractions.iterator(); iterator.hasNext();)
			{
				addInteraction((VanderWaalsInteraction)iterator.next());
			}
		}
	}
	
	
	public Vector getVanderWaalsInteractions()
	{
		return vanderWaalsInteractions;
	}
	
	public void setCationPiInteractions(Vector cationPiInteractions){
		this.cationPiInteractions = cationPiInteractions;
		if(interactingGroupsTable != null){
			for(Iterator iterator = cationPiInteractions.iterator();iterator.hasNext();){
				addInteraction(iterator.next());
			}
		}
	}
	
	public Vector getCationPiInteractions(){
		return cationPiInteractions;
	}
	
	/**
	 * validateInteractingGroups goes through all interacting groups and removes 
	 * those interactingGroups that do not have any interactions in them and hence should not
	 * have been interacting groups in the first place, which suggests better
	 * implementation is necessary for the interaction finding methods
	 */
	public void validateInteractingGroups()
	{
		Hashtable duplicate = (Hashtable)interactingGroupsTable.clone();
		
		for(Enumeration e = duplicate.elements(); e.hasMoreElements();)
		{
			InteractingGroup tempGroup = (InteractingGroup)e.nextElement();
			
			if(!tempGroup.containsAnInteraction())
			{
				interactingGroupsTable.remove(new Integer(tempGroup.getNucleicAcidResidue().getResidueSequenceNumber()));
			}
		}
	}
	
	
	public String toString()
	{
		String str = "non bonding interactions between " + macromoleculeA.getChainIdentifier() + " and " 
				+ macromoleculeB.getChainIdentifier() + " of " + pdbInformation.getPDBName();
		return str;
	}
	
	
	public Hashtable getInteractingGroups()
	{
		return interactingGroupsTable;
    }
	
	
	public boolean isInteractingResidue(Residue residue)
	{
        return isInteractingResidue(residue.getResidueSequenceNumber());
   	}
    
    
	public InteractingGroup getInteractingGroup(Residue nucleicAcidResidue)
	{
		Integer resSeqInteger = new Integer(nucleicAcidResidue.getResidueSequenceNumber());
		return (InteractingGroup)interactingGroupsTable.get(resSeqInteger);
	}
	
	
   	public boolean isInteractingResidue(int resSeq)
   	{
        boolean isInteractingResidue = false;
        Integer resSeqInteger = new Integer(resSeq);
        
        if(macromoleculeAInteractingResidues.containsKey(resSeqInteger)||
                macromoleculeBInteractingResidues.containsKey(resSeqInteger))
        {
            isInteractingResidue = true;        
        }
        
        return isInteractingResidue;
  	}
}