package entangle.classification.stacking;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import entangle.datastructures.ResidueStructure;


/**
* FindRing takes in a ResidueStructure that how the atoms are connected together and determines
* which atoms of the residue are connected in a residue
*/
public class RingFinder
{
    ArrayList ringMembers;
    List rings;
    ResidueStructure residueStructure;
    
    
    public RingFinder(ResidueStructure residueStructure)
    {
        this.residueStructure = residueStructure;
        
        ArrayList beginningArrayList = new ArrayList();
        rings = Collections.synchronizedList(new ArrayList());
        String resName = residueStructure.getResName();
        
        if(resName.equals("A")||resName.equals("G"))
            findRing(beginningArrayList,"N9","C1*");

        if(resName.equals("C")||resName.equals("T")||resName.equals("U"))
            findRing(beginningArrayList,"N1","C1*");

        if(!resName.equals("A")&&!resName.equals("G")&&!resName.equals("U")
                        &&!resName.equals("C")&&!resName.equals("T")&&!resName.equals("GLY")&&!resName.equals("PRO"))
        {
            findRing(beginningArrayList,"CB","CA");
        }
                
        ringMembers = new ArrayList();
        
        if(rings.size()>0)
        {
            System.out.println("Going after the rings");
            ringMembers = createFinalRingMembers();
        }
    }
        
    /**
     * The intent of this was to combine aromatic rings in the larger aromatic rings since they are coplanar
     * combines rings if they share at least two ring members
     */
    public ArrayList createFinalRingMembers()
    {
        System.out.println("Creating the big ring");
        
        ArrayList connectedRings = new ArrayList();
        
        Iterator ringIterator = rings.iterator();
        connectedRings.add((List)ringIterator.next());
        
        while(ringIterator.hasNext())
        {
            List tempRing = (List)ringIterator.next();
            
            for(Iterator innerRingIterator = rings.iterator(); innerRingIterator.hasNext();)
            {
                ArrayList sharedMembers = whereDoRingsConnect((List)innerRingIterator.next(),tempRing);
               if(sharedMembers.size()>=2&&sharedMembers.size()!=tempRing.size())
                      connectedRings.add(tempRing);
            }
        }
        
        // combine the ring members of connected ring
        ArrayList ringMembers = new ArrayList();
        
        for(Iterator connectedRingIterator = connectedRings.iterator(); connectedRingIterator.hasNext();)
        {
            for(Iterator ringMemberIterator = ((List)connectedRingIterator.next()).iterator(); ringMemberIterator.hasNext();)
            {
                String tempAtomName = (String)ringMemberIterator.next();
                
                if(!ringMembers.contains(tempAtomName))
                      ringMembers.add(tempAtomName);
            }
        }
        
        return ringMembers;
    }
        
        
        
    /**
     * Create a list of names where the rings connect
     */
    public ArrayList whereDoRingsConnect(List ring1,List ring2)
    {
        ArrayList sharedMembers = new ArrayList();
        
        for(Iterator ringMemberIterator = ring1.iterator();ringMemberIterator.hasNext();)
        {
            String tempAtomName = (String)ringMemberIterator.next();
            
            if(ring2.contains(tempAtomName))
                   sharedMembers.add(tempAtomName);
        }//ends for
        
        return sharedMembers;
    }
        
        
    /**
     * move through the structure beginning with the specified currentAtomName and if this method
     * eventually returns to an atom already contained within the list that is not the last member,
     * a ring has been found. Now whether it is an aromatic ring is another story
     */
    public void findRing(ArrayList ringMemberList,String currentAtomName,String lastAtomName)
    {
        ringMemberList.add(currentAtomName);
        displayCurrentArray(ringMemberList);
        Vector bondedAtomNames = residueStructure.getBondedAtomNames(currentAtomName);
        
        for(Enumeration e = bondedAtomNames.elements(); e.hasMoreElements();)
        {
            String nextAtomName = (String)e.nextElement();
            
            //System.out.println("Should I add " + nextAtomName);
            
            if(!nextAtomName.equals(lastAtomName))
            {
                if(ringMemberList.contains(nextAtomName))
                {
                    //System.out.println("Got a ring");
                    ringMemberList.add(nextAtomName);
                    rings.add(Collections.synchronizedList(ringMemberList));
                }
                else
                {
                    ArrayList newRingMemberList = new ArrayList(ringMemberList);
                    findRing(newRingMemberList,nextAtomName,currentAtomName);
                }
            }
        }
    }
        
    
    
    
    public void displayCurrentArray(ArrayList list)
    {
        System.out.println("------------------------------------");
        
        for(Iterator iterator = list.iterator(); iterator.hasNext();)
        {
            System.out.println(iterator.next());
        }
    }
        
        
        
    public void writeRingMembersToFile()
    {
        try
        {
            FileWriter fw = new FileWriter(new File(System.getProperty("user.dir") + File.separator + "data" + 
                                        File.separator + "aromaticRings" + File.separator + residueStructure.getResName()));
            PrintWriter pw = new PrintWriter(fw);
            
            for(Iterator iterator = ringMembers.iterator(); iterator.hasNext();)
            {
                String tempString = (String)iterator.next();
                System.out.println(tempString);
                pw.println(tempString);
                pw.flush();
            }
            
            pw.close();
        }
        catch(IOException e)
        {
            System.out.println(e);
            e.printStackTrace(System.out);
        }
    }
}