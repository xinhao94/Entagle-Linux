package entangle.classification.stacking;

import java.io.File;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import entangle.classification.InteractingGroup;
import entangle.datastructures.Atom;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.Residue;
import entangle.utils.EntangleProperties;
import entangle.utils.io.AromaticRingDOMParser;
import entangle.utils.math.AngleTransformer;
import entangle.utils.math.Plane;



public class StackingInteractionFinder
{
    Macromolecule protein;
    Macromolecule nucleicAcid;
    Hashtable interactingGroups;
    
    Vector stackingInteractions;
    
    double maximumStackingDistance = 5.0;
    double maximumStackingAngle = 30.0;
    double minimumStaggeredAngle = Math.PI/6.0;
    
    Hashtable rings; // The big aromatic rings inside of the residues keyed by their residue name

    public StackingInteractionFinder(
        Macromolecule protein,
        Macromolecule nucleicAcid,
        Hashtable interactingGroups)
    {
        this.protein = protein;
        this.nucleicAcid = nucleicAcid;
        this.interactingGroups = interactingGroups;
        
        stackingInteractions = new Vector();
        
        getRings();
    }
        
    public void setMaximumStackingDistance(double maximumStackingDistance)
    {
		this.maximumStackingDistance = maximumStackingDistance;
    }


    public void setMaximumStackingAngle(double maximumStackingAngle)
    {
		this.maximumStackingAngle = maximumStackingAngle;
    }
    
    
    public void setMinimumStaggeredAngle(double minimumStaggeredAngle)
    {
		this.minimumStaggeredAngle = minimumStaggeredAngle;
    }
    
    
    /**
     * Returns a vector of StackingInteractions that occur between the protein and the nucleicAcid
     */
    public Vector getStackingInteractions()
    {
	findStackingInteractions();
        return stackingInteractions;
    }



    /**
     * This method goes through all of the interacting groups and determines if any of them contain a stacking interaction
     * These stacking interactions are then depositing into a vector of StackingInteractions
     */
    public void findStackingInteractions()
    {
        InteractingGroup currentInteractingGroup;
        
        // move through the interacting groups and find out which interacting groups contain a stacking interaction
        for(Enumeration e = interactingGroups.elements();e.hasMoreElements();)
        {
            currentInteractingGroup = (InteractingGroup)e.nextElement();
            Residue currentNucleicAcidResidue =
                currentInteractingGroup.getNucleicAcidResidue();
            Hashtable interactingProteinResidues =
                currentInteractingGroup.getInteractingProteinResidues();
            
            // go through the hashtable of interacting protein residues and determine if
            // the nucleic acid residue and the protein residue are involved 
	    	// in a stacking interaction
            for(Enumeration e2 = interactingProteinResidues.elements(); e2.hasMoreElements();)
            {
                StackingInteraction tempStackingInteraction =
                	getStackingInteraction(currentNucleicAcidResidue,(Residue)e2.nextElement());
                if(tempStackingInteraction!=null)
                	stackingInteractions.add(tempStackingInteraction);
            }
        }
    }


    /**
     * Returns null if the residues do not have the geometry for the stacking interaction, 
     * otherwise, a StackingInteraction is returned
     */
    public StackingInteraction getStackingInteraction(Residue r1, Residue r2)
    {
        StackingInteraction stackingInteraction = null;
        
        Vector r1RingMembers = (Vector)rings.get(r1.getResName());
        Vector r2RingMembers = (Vector)rings.get(r2.getResName());
        
        if(r1RingMembers!=null && r2RingMembers!=null)
        {
            Plane r1Plane = getAromaticPlane(r1,r1RingMembers);
            Plane r2Plane = getAromaticPlane(r2,r2RingMembers);
            
            if(r1Plane!=null&&r2Plane!=null)
            {
                Point3d r1RingCenter = getCenterOfRing(r1,r1RingMembers);
                Point3d r2RingCenter = getCenterOfRing(r2,r2RingMembers);
                
                double centerToCenterDistance = r1RingCenter.distance(r2RingCenter);
                double dihedralAngle = r1Plane.getDihedralAngle(r2Plane);
                
                // the dihedral angle has to be between Math.PI/2.0
                // other angles have to do with the arbitrariness of the  
                // 
				if(dihedralAngle>(Math.PI/2.0)&&dihedralAngle<Math.PI) 
					dihedralAngle = Math.PI - dihedralAngle;
					
				if(dihedralAngle>(Math.PI)&&dihedralAngle<(3.0*Math.PI/2.0))
					dihedralAngle = dihedralAngle - Math.PI;
					
				if(dihedralAngle>(3.0*Math.PI/2.0)&&dihedralAngle<(2.0*Math.PI))
					dihedralAngle = 2.0*Math.PI - dihedralAngle;
					
				dihedralAngle = AngleTransformer.radiansToDegrees(dihedralAngle);
                
                // the angle that gives information about the alignment of the two residues
                double staggeredAngle =
                    r1Plane.getNormal().angle(
                        new Vector3d(
                            r2RingCenter.x - r1RingCenter.x,
                            r2RingCenter.y - r1RingCenter.y,
                            r2RingCenter.z - r1RingCenter.z));
		
				if(staggeredAngle>(Math.PI/2.0))
					staggeredAngle = Math.PI - staggeredAngle;
				
				staggeredAngle = AngleTransformer.radiansToDegrees(staggeredAngle);
                
                if (centerToCenterDistance < maximumStackingDistance
                    && dihedralAngle < maximumStackingAngle
                    && staggeredAngle > minimumStaggeredAngle) {
                    stackingInteraction =
                        new StackingInteraction(
                            r1,
                            r1RingCenter,
                            r2,
                            r2RingCenter,
                            dihedralAngle,
                            staggeredAngle,
                            centerToCenterDistance);
                }
					
            }
        }
        
        return stackingInteraction;
    }
    
    
    
    /**
     * Returns the plane of the aromatic ring for the specified residue and specified ring
     */
    public Plane getAromaticPlane(Residue residue, Vector ringMembers)
    {
        int numberOfAtomsObtained = 0;
        
        Atom firstAtom = null;
        Atom secondAtom = null;
        Atom thirdAtom = null;
        
        for(Enumeration e = ringMembers.elements();(e.hasMoreElements()&& numberOfAtomsObtained<3);)
        {
            String tempAtomName = (String)e.nextElement();
            
            if(residue.containsAtom(tempAtomName))
            {
                switch(numberOfAtomsObtained)
                {
                    case(0): firstAtom = residue.getAtom(tempAtomName);
                    			numberOfAtomsObtained++;
                    			break;
                    case(1): secondAtom = residue.getAtom(tempAtomName);
                    			numberOfAtomsObtained++;
                    			break;
                    case(2): thirdAtom = residue.getAtom(tempAtomName);
                    			numberOfAtomsObtained++;
                    			break;
                    default:
                }
            }
        }
        
        Plane plane = null;
        
        if(firstAtom!=null && secondAtom!=null && thirdAtom!=null)
        {
            Point3d firstPoint = new Point3d(firstAtom.x,firstAtom.y,firstAtom.z);
            Point3d secondPoint = new Point3d(secondAtom.x,secondAtom.y,secondAtom.z);
            Point3d thirdPoint = new Point3d(thirdAtom.x,thirdAtom.y,thirdAtom.z);
            
            plane = new Plane(firstPoint,secondPoint,thirdPoint);
        }
        
        return plane;
    }




    /**
     * Returns the center of the aromatic ring specified
     */
    public Point3d getCenterOfRing(Residue residue, Vector ringMembers)
    {
        double totalX = 0;
        double totalY = 0;
        double totalZ = 0;
        
        Atom currentAtom;
        
        for(Enumeration e = ringMembers.elements();e.hasMoreElements();)
        {
            currentAtom = residue.getAtom((String)e.nextElement());
            if(currentAtom!=null)
            {
                totalX += currentAtom.getX();
                totalY += currentAtom.getY();
                totalZ += currentAtom.getZ();
            }
        }
        
        Point3d center =
            new Point3d(
                totalX / ringMembers.size(),
                totalY / ringMembers.size(),
                totalZ / ringMembers.size());
        
        return center;
    }



    public void getRings()
    {
		try
		{
            String fileName =
                EntangleProperties.getProperties().getProperty(
                    "entangle.aromaticRingsFile");
            File aromaticRingsFile =
                new File(
                    System.getProperty("user.dir") + File.separator + fileName);
            AromaticRingDOMParser parser =
                new AromaticRingDOMParser(aromaticRingsFile);
            rings = parser.getAromaticRings();
		}
		catch(Exception e)
		{
			e.printStackTrace(System.out);
		}
    }
}
