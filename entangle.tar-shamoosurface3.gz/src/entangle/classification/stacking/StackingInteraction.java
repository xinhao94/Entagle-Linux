/**
 * This class represents a stacking interaction between two residues
 * in a protein-nucleic acid interface
 */
 
package entangle.classification.stacking;

import javax.vecmath.Point3d;

import entangle.datastructures.Residue;


public class StackingInteraction
{
    Residue rA;
    Residue rB;
    
    double centerToCenterDistance; // the distance between the two centers of the aromatic rings
    Point3d centerOfAromaticRingA;
    Point3d centerOfAromaticRingB;
    double degreeOfStaggeredness; // the angle in radians of the staggeredness of the entry
                                  // this measure only makes sense for aromatic rings with mostly parallel planes
    double dihedralAngle; // the dihedral angle between the two planes 
    
    static final double STAGGERED = Math.PI/2.0;
    
    
    
    
    public StackingInteraction(Residue rA, Point3d centerOfAromaticRingA,Residue rB,
                               Point3d centerOfAromaticRingB,double dihedralAngle,double degreeOfStaggeredness,
                               double centerToCenterDistance)
    {
		this.rA = rA;
		this.rB = rB;
        this.centerOfAromaticRingA = centerOfAromaticRingA;
        this.centerOfAromaticRingB = centerOfAromaticRingB;
        this.dihedralAngle = dihedralAngle;
        this.degreeOfStaggeredness = degreeOfStaggeredness;
        this.centerToCenterDistance = centerToCenterDistance;
    }
    
    
    public SimpleSInteraction simpleCopy(){
    	return new SimpleSInteraction(this);
    }



    public Residue getResidueA()
    {
		return rA;
    }
    
    
    public Point3d getCenterOfAromaticRingA()
    {
            return centerOfAromaticRingA;
    }
    
    
    public Residue getResidueB()
    {
		return rB;
    }
    
    
    public Point3d getCenterOfAromaticRingB()
    {
            return centerOfAromaticRingB;
    }
    
    
    public double getDegreeOfStaggeredness()
    {
            return degreeOfStaggeredness;
    }
    
    
    public double getDihedralAngle()
    {
            return dihedralAngle;
    }
    
    
    public double getCenterToCenterDistance()
    {
            return centerToCenterDistance;
    }
    
    
    public String toString()
    {
        String string = "Residue A: " + rA.toString() + "Residue B: " + rB.toString();
        return string;
    }
}