/**
 * This class represents a stacking interaction between two residues
 * in a protein-nucleic acid interface
 */
 
package entangle.classification.stacking;

import entangle.utils.Transformable;
import entangle.utils.XMLEnabled;
import entangle.utils.math.XYZMatrix;
import entangle.datastructures.SimplePResidue;
import entangle.datastructures.SimpleRNAResidue;

public class SimpleSInteraction implements Transformable, XMLEnabled{
    public SimpleRNAResidue rA;
    public SimplePResidue rB;
    
    double centerToCenterDistance; // the distance between the two centers of the aromatic rings
    XYZMatrix centerOfAromaticRingA;
    XYZMatrix centerOfAromaticRingB;
    double degreeOfStaggeredness; // the angle in radians of the staggeredness of the entry
                                  // this measure only makes sense for aromatic rings with mostly parallel planes
    double dihedralAngle; // the dihedral angle between the two planes 
    
    
    public SimpleSInteraction(StackingInteraction si)
    {
	rA = si.rA.simpleRNACopy();
	rB = si.rB.simplePCopy();
		
        centerOfAromaticRingA = new XYZMatrix(si.centerOfAromaticRingA.x, 
        				      si.centerOfAromaticRingA.y, 
        				      si.centerOfAromaticRingA.z);
        centerOfAromaticRingB = new XYZMatrix(si.centerOfAromaticRingB.x, 
        				      si.centerOfAromaticRingB.y, 
        				      si.centerOfAromaticRingB.z);
        
        dihedralAngle = si.dihedralAngle;
        degreeOfStaggeredness = si.degreeOfStaggeredness;
        centerToCenterDistance = si.centerToCenterDistance;
    }
    
    
    public void transform(XYZMatrix t, double r1, double r2, double r3){
	centerOfAromaticRingA.transform(t,r1,r2,r3);
	centerOfAromaticRingB.transform(t,r1,r2,r3);
	rA.transform(t,r1,r2,r3);
	rB.transform(t,r1,r2,r3);
    }
	
    public String buildXML(){
      	String atomXML = "        <StackingInteraction>";
		atomXML += 	   "\n            <CenterToCenterDistance>" + centerToCenterDistance + "</CenterToCenterDistance>";
		atomXML +=     "\n            <DegreeOfStaggeredness>" + degreeOfStaggeredness + "</DegreeOfStaggeredness>";
		atomXML +=     "\n            <DihedralAngle>" + dihedralAngle + "</DihedralAngle>";
		atomXML +=     "\n            <CenterOfRingA>";
		atomXML +=     "\n                <x>" + centerOfAromaticRingA.getX() + "</x>";
		atomXML +=     "\n                <y>" + centerOfAromaticRingA.getY() + "</y>";
		atomXML +=     "\n                <z>" + centerOfAromaticRingA.getZ() + "</z>";
		atomXML +=     "\n            </CenterOfRingA>";
		atomXML +=     "\n            <CenterOfRingB>";
		atomXML +=     "\n                <x>" + centerOfAromaticRingB.getX() + "</x>";
		atomXML +=     "\n                <y>" + centerOfAromaticRingB.getY() + "</y>";
		atomXML +=     "\n                <z>" + centerOfAromaticRingB.getZ() + "</z>";
		atomXML +=     "\n            </CenterOfRingB>";				
		atomXML +=     "\n        </StackingInteraction>";
		
       	return   atomXML;
    }
	
    public String buildHTML(){
	return "<tr><td>" + centerToCenterDistance + "</td><td>" + 
	       degreeOfStaggeredness + "</td><td>" + 
	       dihedralAngle + "</td><td>" + 
	       centerOfAromaticRingA.getX() + "</td><td>" + 
	       centerOfAromaticRingA.getY() + "</td><td>" + 
	       centerOfAromaticRingA.getZ() + "</td><td>" + 
	       centerOfAromaticRingB.getX() + "</td><td>" + 
	       centerOfAromaticRingB.getY() + "</td><td>" + 
	       centerOfAromaticRingB.getZ() + "</td></tr>";
   }
}

