package entangle.classification.hydrophobic;

import entangle.datastructures.SimpleAtom;
import entangle.utils.Transformable;
import entangle.utils.XMLEnabled;
import entangle.utils.math.XYZMatrix;

/**
 * Represents a hydrophobic interaction between two non-polar atoms, 
 * simply distance and polarity
 * @author  Lowell Meyer
 * @version 
 */
public class SimpleHInteraction implements Transformable, XMLEnabled{
	SimpleAtom nonPolarAtomA;
	SimpleAtom nonPolarAtomB;
	
	/** Creates new HydrophobicInteraction */
	public SimpleHInteraction(HydrophobicInteraction hi)
	{
		nonPolarAtomA = hi.nonPolarAtomA.simpleCopy();
		nonPolarAtomB = hi.nonPolarAtomB.simpleCopy();
	}
	
	public void transform(XYZMatrix t, double r1, double r2, double r3){
		nonPolarAtomA.transform(t,r1,r2,r3);
		nonPolarAtomB.transform(t,r1,r2,r3);
	}
	
	public String buildXML(){
		String atomXML = "        <ElectrostaticInteraction>";
		
		atomXML += ("\n" + nonPolarAtomA.buildXML());
		atomXML += ("\n" + nonPolarAtomB.buildXML());
				
		atomXML += "\n        </ElectrostaticInteraction>";
		
		return   atomXML;
	}
	
	public String buildHTML(){
		return "<tr>" + nonPolarAtomA.buildHTML() + nonPolarAtomB.buildHTML() + "</tr>\n";
	}
}