/*
 * HydrophobicInteraction.java
 *
 * Created on September 5, 2000, 11:55 AM
 */

package entangle.classification.hydrophobic;

import entangle.datastructures.Atom;

/**
 * Represents a hydrophobic interaction between two non-polar atoms, 
 * simply distance and polarity
 * @author  Jim Allers
 * @version 
 */
public class HydrophobicInteraction extends Object 
{
	Atom nonPolarAtomA;
	Atom nonPolarAtomB;
	
	public double distance;
	
	
	
	/** Creates new HydrophobicInteraction */
	public HydrophobicInteraction(Atom nonPolarAtomA, Atom nonPolarAtomB, double distance)
	{
		this.nonPolarAtomA = nonPolarAtomA;
		this.nonPolarAtomB = nonPolarAtomB;
		this.distance = distance;
	}

	public SimpleHInteraction simpleCopy(){
		return new SimpleHInteraction(this);
	}



	public Atom getNonPolarAtomA()
	{
		return nonPolarAtomA;
	}


	public Atom getNonPolarAtomB()
	{
		return nonPolarAtomB;
	}


	public void setNonPolarAtomA(Atom atom)
	{
		nonPolarAtomA = atom;
	}
	
	
	public void setNonPolarAtomB(Atom atom)
	{
		nonPolarAtomB = atom;
	}
	
	
	public void setDistance(double distance)
	{
		this.distance = distance;
	}
        
        
    public String toString()
    {
        String string = "Atom A: " + nonPolarAtomA + " Atom B: " + nonPolarAtomB;
        return string;
    }
}