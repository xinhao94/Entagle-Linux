/*
 * HydrophobicInteractionFinder.java
 *
 * Created on September 5, 2000, 11:55 AM
 */

package entangle.classification.hydrophobic;

import java.util.Iterator;
import java.util.Vector;

import entangle.datastructures.Atom;
import entangle.datastructures.AtomPair;


/**
 * Looks for contacts between non-polar atoms
 * @author  Jim Allers
 * @version 
 */
public class HydrophobicInteractionFinder extends Object 
{
	Vector nonPolarAtomTypes;
	Vector closeAtomPairs;
	Vector hydrophobicInteractions;
	
	boolean foundHydrophobicInteractions;
	
	double maximumDistanceForHydrophobicInteraction = 5.0;
	
	
	
	public HydrophobicInteractionFinder(Vector closeAtomPairs) 
	{
		this.closeAtomPairs = closeAtomPairs;
		hydrophobicInteractions = new Vector();
		nonPolarAtomTypes = new Vector();
		nonPolarAtomTypes.add("S");
		nonPolarAtomTypes.add("C");
	}
	
	
	
	public void setMaximumDistanceForHydrophobicInteraction(double distance)
	{
		maximumDistanceForHydrophobicInteraction = distance;
	}
	
	
	public void findHydrophobicInteractions()
	{
		System.out.println("Going after hydrophobic interactions");
		System.out.println("Maximum distance: " + maximumDistanceForHydrophobicInteraction);
		
		Vector duplicateCloseAtomPairs = (Vector)closeAtomPairs.clone();
		
		for(Iterator iterator = duplicateCloseAtomPairs.iterator(); iterator.hasNext();)
		{
			AtomPair tempAtomPair = (AtomPair)iterator.next();
			Atom atomA = tempAtomPair.getMacromoleculeAAtom();
			Atom atomB = tempAtomPair.getMacromoleculeBAtom();
			
			double distance = tempAtomPair.getDistance();
			
			if(distance<maximumDistanceForHydrophobicInteraction)
			{
				if(nonPolarAtomTypes.contains(atomA.getAtomType())&& nonPolarAtomTypes.contains(atomB.getAtomType()))
				{
					hydrophobicInteractions.add(new HydrophobicInteraction(atomA, atomB, distance));
					closeAtomPairs.remove(tempAtomPair);
				}
			}
		}
	}
	
	
	public Vector getHydrophobicInteractions()
	{
		if(!foundHydrophobicInteractions)
		{
			findHydrophobicInteractions();
			foundHydrophobicInteractions = true;
		}
		
		return hydrophobicInteractions;
	}
}