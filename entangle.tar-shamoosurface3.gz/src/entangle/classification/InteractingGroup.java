/*
 * An InteractingGroup organizes the interacting residues as those that interact with
 * the nucleic acid residue
 */

package entangle.classification;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import entangle.classification.cationpi.CationPiInteraction;
import entangle.classification.electrostatic.ElectrostaticInteraction;
import entangle.classification.hbonds.HydrogenBond;
import entangle.classification.hydrophobic.HydrophobicInteraction;
import entangle.classification.stacking.StackingInteraction;
import entangle.classification.vanderwaals.VanderWaalsInteraction;
import entangle.datastructures.Residue;

public class InteractingGroup {
    Residue nucleicAcidResidue;
    Hashtable interactingProteinResidues;
    // keyed by their residue sequence number
    // (Integer)
    Vector hydrogenBonds;
    Vector hydrophobicInteractions;
    Vector vanderWaalsInteractions;
    Vector electrostaticInteractions;
    Vector stackingInteractions;
	Vector cationPiInteractions;
	
    public InteractingGroup(
        Residue nucleicResidue,
        Hashtable proteinResidues) {
        nucleicAcidResidue = nucleicResidue;
        interactingProteinResidues = proteinResidues;

        hydrogenBonds = new Vector();
        hydrophobicInteractions = new Vector();
        vanderWaalsInteractions = new Vector();
        electrostaticInteractions = new Vector();
        stackingInteractions = new Vector();
        cationPiInteractions = new Vector();
    }

    /**
     * Returns a copy of this interacting group, but with only the geometric
     * information about the data... i.e. without all the overhead.
     * 
     * Used for multiple PDB generalization analysis. 
     * 
     * -LRM
     */
    public SimpleInteractingGroup simpleCopy() {
        return new SimpleInteractingGroup(this);
    }

    public boolean containsAnInteraction() {
        boolean containsAnInteraction = false;

        if (hydrogenBonds.size() != 0
            || hydrophobicInteractions.size() != 0
            || vanderWaalsInteractions.size() != 0
            || electrostaticInteractions.size() != 0
            || stackingInteractions.size() != 0
            || cationPiInteractions.size() != 0) {
            containsAnInteraction = true;
        }

        return containsAnInteraction;
    }

    /**
     * This goes through all of the interacting protein residues and 
     * confirms whether the protein residues interact with the nucleic acid,
     * under the criteria specified for finding interactions
     * 
     */
    public void validateInteractingProteinResidues() {
        for (Enumeration e = interactingProteinResidues.elements();
            e.hasMoreElements();
            ) {
            int resSeq = ((Residue) e.nextElement()).getResidueSequenceNumber();
            int resSeq1;
            int resSeq2;
            boolean doesNotInteract = true;

            // CHECKS HYDROGEN BONDS
            for (Iterator hydrogenBondIterator = hydrogenBonds.iterator();
                hydrogenBondIterator.hasNext();
                ) {
                HydrogenBond tempHydrogenBond =
                    (HydrogenBond) hydrogenBondIterator.next();
                resSeq1 = tempHydrogenBond.getAcceptor().getResSeq();
                resSeq2 = tempHydrogenBond.getDonor().getResSeq();

                if (resSeq1 == resSeq || resSeq2 == resSeq)
                    doesNotInteract = false;
            }

            // CHECKS HYDROPHOBIC INTERACTIONS
            for (Iterator hydrophobicInteractionIterator =
                hydrophobicInteractions.iterator();
                hydrophobicInteractionIterator.hasNext();
                ) {
                HydrophobicInteraction hydrophobicInteraction =
                    (HydrophobicInteraction) hydrophobicInteractionIterator
                        .next();

                resSeq1 = hydrophobicInteraction.getNonPolarAtomA().getResSeq();
                resSeq2 = hydrophobicInteraction.getNonPolarAtomB().getResSeq();

                if (resSeq1 == resSeq || resSeq2 == resSeq)
                    doesNotInteract = false;
            }

            //CHECKS VANDERWAALS INTERACTIONS
            for (Iterator vanderWaalsInteractionIterator =
                vanderWaalsInteractions.iterator();
                vanderWaalsInteractionIterator.hasNext();
                ) {
                VanderWaalsInteraction vanderWaalsInteraction =
                    (VanderWaalsInteraction) vanderWaalsInteractionIterator
                        .next();

                resSeq1 = vanderWaalsInteraction.getAtomA().getResSeq();
                resSeq2 = vanderWaalsInteraction.getAtomB().getResSeq();

                if (resSeq1 == resSeq || resSeq2 == resSeq)
                    doesNotInteract = false;
            }

            // CHECKS STACKING INTERACTIONS
            for (Iterator stackingInteractionIterator =
                stackingInteractions.iterator();
                stackingInteractionIterator.hasNext();
                ) {
                StackingInteraction stackingInteraction =
                    (StackingInteraction) stackingInteractionIterator.next();

                resSeq1 =
                    stackingInteraction
                        .getResidueA()
                        .getResidueSequenceNumber();
                resSeq2 =
                    stackingInteraction
                        .getResidueB()
                        .getResidueSequenceNumber();

                if (resSeq1 == resSeq || resSeq2 == resSeq)
                    doesNotInteract = false;
            }
			
			// CHECKS CATION PI INTERACTIOSN
			for (Iterator iter = cationPiInteractions.iterator(); iter.hasNext();) {
                CationPiInteraction cationPiInteraction = (CationPiInteraction) iter.next();
                if (cationPiInteraction.getCationAtom().getResSeq() == resSeq
                    || cationPiInteraction
                        .getAromaticResidue()
                        .getResidueSequenceNumber()
                        == resSeq) {
                    doesNotInteract = false;
                }
            }
			
            if (doesNotInteract)
                interactingProteinResidues.remove(new Integer(resSeq));
        } //ends for
    }

    public void addHydrogenBond(HydrogenBond hydrogenBond) {
        hydrogenBonds.add(hydrogenBond);
    }

    public Vector getHydrogenBonds() {
        return hydrogenBonds;
    }

    public void addHydrophobicInteraction(HydrophobicInteraction hydrophobicInteraction) {
        hydrophobicInteractions.add(hydrophobicInteraction);
    }

    public Vector getHydrophobicInteractions() {
        return hydrophobicInteractions;
    }

    public void addVanderWaalsInteraction(VanderWaalsInteraction vanderWaalsInteraction) {
        vanderWaalsInteractions.add(vanderWaalsInteraction);
    }

    public Vector getVanderWaalsInteractions() {
        return vanderWaalsInteractions;
    }

    public void addElectrostaticInteraction(ElectrostaticInteraction electrostaticInteraction) {
        electrostaticInteractions.add(electrostaticInteraction);
    }

    public Vector getElectrostaticInteractions() {
        return electrostaticInteractions;
    }

    public void addStackingInteraction(StackingInteraction stackingInteraction) {
        stackingInteractions.add(stackingInteraction);
    }

    public Vector getStackingInteractions() {
        return stackingInteractions;
    }

    public Residue getNucleicAcidResidue() {
        return nucleicAcidResidue;
    }
	
	public void addCationPiInteraction(CationPiInteraction cationPiInteraction){
		cationPiInteractions.add(cationPiInteraction);
	}
	
	public Vector getCationPiInteractions(){
		return cationPiInteractions;
	}
	
    /**
     * Returns Hashtable of protein residues that interact with the nucleic acid residue of this interacting group
     * the protein residues are keyed by their residue sequence number
     */
    public Hashtable getInteractingProteinResidues() {
        return interactingProteinResidues;
    }

    public boolean containsInteractingResidue(Residue residue) {
        return interactingProteinResidues.contains(residue);
    }

    public String toString() {
        String str = nucleicAcidResidue.toString();
        return str;
    }
}