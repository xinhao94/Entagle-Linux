/*
 * VanderWaalsInteractionFinder.java
 *
 * Created on September 5, 2000, 11:56 AM
 */

package entangle.classification.vanderwaals;

import java.util.Iterator;
import java.util.Vector;

import entangle.datastructures.Atom;
import entangle.datastructures.AtomPair;


/**
 *
 * @author  Jim Allers
 * @version 
 */
public class VanderWaalsInteractionFinder
{
	Vector vanderWaalsInteractions;
	Vector closeAtomPairs;
	
	private double maximumVanderWaalsDistance = .8;
	boolean foundVanderWaalsInteractions = false;
	
	
	
    /** Creates new VanderWaalsInteractionFinder */
	public VanderWaalsInteractionFinder(Vector closeAtomPairs) 
	{
	       this.closeAtomPairs = closeAtomPairs;
	}
	
	
	
	
	public void setMaximumVanderWaalsDistance(double distance)
	{
		maximumVanderWaalsDistance = distance;
	}
	
	
	public double getMaximumVanderWaalsDistance()
	{
		return maximumVanderWaalsDistance;
	}
	
	
	public void findVanderWaalsInteractions()
	{
		vanderWaalsInteractions = new Vector();
		Vector duplicateContacts = (Vector)closeAtomPairs.clone();
		
		for(Iterator iterator = duplicateContacts.iterator(); iterator.hasNext();)
		{
			AtomPair tempAtomPair = (AtomPair)iterator.next();
			Atom atomA = tempAtomPair.getMacromoleculeAAtom();
			Atom atomB = tempAtomPair.getMacromoleculeBAtom();
			
			double atomAVanderWaalsRadius = atomA.getVanderWaalsRadius();
			double atomBVanderWaalsRadius = atomB.getVanderWaalsRadius();
			double distance = tempAtomPair.getDistance();
			double effectiveDistance = distance - atomAVanderWaalsRadius - atomBVanderWaalsRadius;
			
			if(effectiveDistance<maximumVanderWaalsDistance)
			{
				VanderWaalsInteraction vanderWaalsInteraction = new VanderWaalsInteraction(atomA,
							atomAVanderWaalsRadius, atomB, atomBVanderWaalsRadius, distance, effectiveDistance);
				vanderWaalsInteractions.add(vanderWaalsInteraction);
			}
		}
	}
	
	
	
	public Vector getVanderWaalsInteractions()
	{
		if(!foundVanderWaalsInteractions)
		{
			findVanderWaalsInteractions();
			foundVanderWaalsInteractions = true;
		}
		
		return vanderWaalsInteractions;
	}
}