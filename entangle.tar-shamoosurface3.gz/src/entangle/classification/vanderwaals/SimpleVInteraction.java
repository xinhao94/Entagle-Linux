/*
 * VanderWaalsInteraction.java
 *
 * Created on September 5, 2000, 11:56 AM
 */

package entangle.classification.vanderwaals;

import entangle.datastructures.SimpleAtom;
import entangle.utils.Transformable;
import entangle.utils.XMLEnabled;
import entangle.utils.math.XYZMatrix;

/**
 * Any type two atoms are at the right distance apart to optimize 
 * the Van der Waals interaction between the two atoms
 * @author  Jim Allers
 * @version 
 */
public class SimpleVInteraction implements Transformable, XMLEnabled{
	public SimpleAtom atomA;
	public SimpleAtom atomB;
	
	public double atomAVanderWaalsRadius;
	public double atomBVanderWaalsRadius;
	public double distanceBetweenAtoms;
	public double effectiveDistance;
	
    public SimpleVInteraction(VanderWaalsInteraction vi)
	{
		atomA = vi.getAtomA().simpleCopy();
		atomB = vi.getAtomB().simpleCopy();
		
		atomAVanderWaalsRadius = vi.atomAVanderWaalsRadius;
		atomBVanderWaalsRadius = vi.atomBVanderWaalsRadius;
		distanceBetweenAtoms = vi.distanceBetweenAtoms;
		effectiveDistance = vi.effectiveDistance;
	}
	
	
	public void transform(XYZMatrix t, double r1, double r2, double r3){
		atomA.transform(t,r1,r2,r3);
		atomB.transform(t,r1,r2,r3);
	}
	
	public String buildXML(){
		String atomXML = "        <ElectrostaticInteraction>";
		
		atomXML += ("\n" + atomA.buildXML());
		atomXML += ("\n" + atomB.buildXML());
		
		atomXML += "\n        </ElectrostaticInteraction>";
		
		return   atomXML;
	}
	
	public String buildHTML(){
		return "<tr>" + atomA.buildHTML() + atomB.buildHTML() + "</tr>\n";
	}
}