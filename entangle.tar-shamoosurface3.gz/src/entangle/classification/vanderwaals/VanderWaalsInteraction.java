/*
 * VanderWaalsInteraction.java
 *
 * Created on September 5, 2000, 11:56 AM
 */

package entangle.classification.vanderwaals;

import entangle.datastructures.Atom;


/**
 * Any type two atoms are at the right distance apart to optimize 
 * the Van der Waals interaction between the two atoms
 * @author  Jim Allers
 * @version 
 */
public class VanderWaalsInteraction extends Object 
{
	private Atom atomA;
	public double atomAVanderWaalsRadius;
	private Atom atomB;
	public double atomBVanderWaalsRadius;
	public double distanceBetweenAtoms;
	public double effectiveDistance;
	
	
	
    /** Creates new VanderWaalsInteraction */
	public VanderWaalsInteraction(Atom atomA, double atomAVanderWaalsRadius, Atom atomB, double atomBVanderWaalsRadius,
	                              double distanceBetweenAtoms, double effectiveDistance)
	{
		this.atomA = atomA;
		this.atomB = atomB;
		this.atomAVanderWaalsRadius = atomAVanderWaalsRadius;
		this.atomBVanderWaalsRadius = atomBVanderWaalsRadius;
		this.distanceBetweenAtoms = distanceBetweenAtoms;
		this.effectiveDistance = effectiveDistance;
	}
	
	public SimpleVInteraction simpleCopy(){
		return new SimpleVInteraction(this);
	}




	public void setAtomA(Atom atom)
	{
		atomA = atom;
	}
	
	
	public void setAtomB(Atom atom)
	{
		atomB = atom;
	}
	
	
	public Atom getAtomA()
	{
		return atomA;
	}
	
	
	public Atom getAtomB()
	{
		return atomB;
	}
    
    
    public String toString()
    {
        String string = "Atom A: " + atomA + " Atom B: " + atomB;
        return string;
    }
}