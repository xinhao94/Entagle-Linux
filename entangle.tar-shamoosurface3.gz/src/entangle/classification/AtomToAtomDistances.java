/*
 * 1.2 code
 * Last Modified: 07/21/2000 - 08:01:05
 * Author: Jim Allers (jima@rice.edu)
 */
package entangle.classification;

import java.util.Enumeration;
import java.util.Vector;

import entangle.datastructures.Atom;
import entangle.datastructures.AtomPair;
import entangle.datastructures.Macromolecule;
import entangle.datastructures.Residue;

/**
 * This class simply takes in a macromoleculeA and an macromoleculeB and computes the distances between
 * each macromoleculeA atom and each macromoleculeB atom. This class is based on the assumption that 
 * the significant interactions will take place at an atom-to-atom distances less than
 * 5 angstroms.
 */
public class AtomToAtomDistances
{
    Vector atomPairsWithinMaximumDistance; // stores pairs of atoms 
                                           // and the distances between them
    Vector interactingRnaResidues; // residues that interact with macromoleculeA
    Vector interactingProteinResidues; // residues that interact with macromoleculeB
    Vector hydrogenBonds; // stores pairs of atoms that may be hydrogen bonds
    
    double maximumDistance = 7.0; // maximum distance between atoms that will
                                  // be considered as an interatomic contacts
                                  
    Macromolecule macromoleculeA;
    Macromolecule macromoleculeB;
   
   
   
    //CONSTRUCTOR////////////
    public AtomToAtomDistances(Macromolecule macromoleculeA,Macromolecule macromoleculeB)
    {
	    this.macromoleculeA = macromoleculeA;
	    this.macromoleculeB = macromoleculeB;
    }// ends constructor
 
 
 
    public void setMaximumInteractionDistance(double maximumDistance)
    {
	    this.maximumDistance = maximumDistance;
    }


    /**
     * getAtomDistances() uses the specified MacromoleculeA and macromoleculeB and breaks it up
     * into atom-atom pairs which contain a MacromoleculeA atom, macromoleculeB atom, and the
     * distance between the two, only atom pairs that have a distance
     * between them of less than the maximum distance are collected into a vector
     */
    private void getAtomDistances()
    {
	    atomPairsWithinMaximumDistance = new Vector();
        
        Residue tempMacromoleculeAResidue;
	    Residue tempMacromoleculeBResidue;
        
        // go through each residue and check each for intermolecular contacts
        for(Enumeration macromoleculeAResidues = macromoleculeA.getResidues().keys();
	                                                 macromoleculeAResidues.hasMoreElements();)
	    {
	        tempMacromoleculeAResidue = macromoleculeA.getResidue((Integer)macromoleculeAResidues.nextElement());
            
            // check this residue against every residue in A
	        for(Enumeration macromoleculeBResidues = macromoleculeB.getResidueKeys();
	                                              macromoleculeBResidues.hasMoreElements();)
	        {
	            tempMacromoleculeBResidue = macromoleculeB.getResidue((Integer)macromoleculeBResidues.nextElement());
	            getAtomsWithinMaximumDistance(tempMacromoleculeAResidue,tempMacromoleculeBResidue, atomPairsWithinMaximumDistance);
	        }
        }
    }//ends getAtomDistances
    
    
    /**
     *
     *
     */
    private void getAtomsWithinMaximumDistance(Residue macromoleculeAResidue, Residue macromoleculeBResidue, Vector atomPairs)
    {
	    Atom tempMacromoleculeAAtom; 
	    Atom tempMacromoleculeBAtom;
	    double distance;
	    
	    for(Enumeration e1 = macromoleculeAResidue.getAtomKeys();e1.hasMoreElements();)
	    {
	        tempMacromoleculeAAtom = macromoleculeAResidue.getAtom((String)e1.nextElement());
	        
	        for(Enumeration e2 = macromoleculeBResidue.getAtomKeys();e2.hasMoreElements();)
	        {
		        tempMacromoleculeBAtom = macromoleculeBResidue.getAtom((String)e2.nextElement());
		        distance = tempMacromoleculeAAtom.getDistance(tempMacromoleculeBAtom);
		        if(distance < maximumDistance)
		        {
		            AtomPair tempAtomPair = new AtomPair(tempMacromoleculeAAtom,tempMacromoleculeBAtom, distance);
		            atomPairsWithinMaximumDistance.addElement(tempAtomPair);
		        }
	        }
	    }
    }
    
    public Vector getCloseAtomPairs()
    {
	    getAtomDistances();
	    return atomPairsWithinMaximumDistance;
    }
}












