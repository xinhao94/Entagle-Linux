import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import entangle.utils.io.AtomRecord;

/*
 * Created on Jun 3, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author unknown
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SimplePDBGenerator {
	
	public static void main(String[] args){
		File inputFile = new File(args[0]);
		
		File outputFile = new File(args[1]);
		
		try {
			outputFile.createNewFile();
			PrintWriter pw = new PrintWriter(new FileWriter(outputFile));
			
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
			String line = null;
			
			int atomNumber = 1;
			int residueNumber = 0;
			String lastResidue = "";
			
			while((line = reader.readLine()) != null){
				String[] strings = line.split(",");
				if(strings.length >=9 && (strings[0].length() > 0)){
					if(!lastResidue.equals("") && !lastResidue.equals(strings[3])){
						residueNumber++;
					}
					AtomRecord atomRecord =
						new AtomRecord(
							strings[1],
							strings[2],
							atomNumber,
							strings[3],
							'A',
							residueNumber,
							Double.parseDouble(strings[6]),
							Double.parseDouble(strings[7]),
							Double.parseDouble(strings[8]));
					lastResidue = strings[3];
					atomNumber++;
					pw.println(atomRecord.generatePDBString());
				}
			}
			
			reader.close();
			pw.println("END");
			pw.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
